package id.nuviobridge

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*

class ActionEditActivity : Activity() {

    private lateinit var pal: Pal
    private lateinit var nameField: EditText
    private lateinit var tplField: EditText
    private lateinit var iconBoxes: List<FrameLayout>
    private var editId: String? = null
    private var icon = 5

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        pal = Ui.pal(this)
        editId = intent.getStringExtra("id")
        val existing = Actions.load(this).firstOrNull { it.id == editId }
        icon = existing?.icon ?: 5

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(px(16), px(20), px(16), px(24))
            setBackgroundColor(pal.bg)
        }
        root.addView(TextView(this).apply {
            text = if (existing == null) "Aksi baru" else "Edit aksi"
            textSize = 22f
            setTextColor(pal.text)
            typeface = Typeface.DEFAULT_BOLD
        })

        // ---------- NAMA ----------
        root.add(section("NAMA"), 20)
        val nameCard = card()
        nameField = EditText(this).apply {
            hint = "Nama aksi, mis. Viki"
            setHintTextColor(pal.muted)
            setTextColor(pal.text)
            setSingleLine()
            setText(existing?.name.orEmpty())
        }
        nameCard.add(nameField, 0)
        root.add(nameCard, 8)

        // ---------- IKON ----------
        root.add(section("IKON"), 20)
        val iconCard = card()
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        iconBoxes = (0 until Actions.ICON_COUNT).map { i ->
            FrameLayout(this).apply {
                addView(ActionIconView(this@ActionEditActivity, i, pal.text),
                    FrameLayout.LayoutParams(px(32), px(32), Gravity.CENTER))
                setOnClickListener { icon = i; refreshIcons() }
                row.addView(this, LinearLayout.LayoutParams(0, px(52), 1f).apply {
                    if (i > 0) leftMargin = px(4)
                })
            }
        }
        iconCard.addView(row)
        root.add(iconCard, 8)
        refreshIcons()

        // ---------- TEMPLATE ----------
        root.add(section("TEMPLATE URL"), 20)
        val tplCard = card()
        tplField = EditText(this).apply {
            hint = "mis. https://www.youtube.com/results?search_query={title}+{year}"
            setHintTextColor(pal.muted)
            setTextColor(pal.text)
            setText(existing?.template.orEmpty())
        }
        tplCard.add(tplField, 0)
        tplCard.add(note("Skema bebas (https://, appname://). Placeholder di bawah diganti otomatis saat dibuka."), 8)
        root.add(tplCard, 8)

        // ---------- PLACEHOLDER ----------
        root.add(section("PLACEHOLDER (ketuk untuk menyisipkan)"), 20)
        val phCard = card()
        Actions.PLACEHOLDERS.chunked(2).forEachIndexed { r, pair ->
            val line = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            pair.forEachIndexed { i, ph ->
                line.addView(button(ph.first + "\n" + ph.second, false) { insertToken(ph.first) },
                    LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                        if (i > 0) leftMargin = px(4)
                    })
            }
            phCard.add(line, if (r == 0) 0 else 6)
        }
        phCard.add(note("{imdbId}, {tvdbId}, dan {tmdbId} hanya dipakai saat datanya ada. Kalau tidak ada, aksi disembunyikan dari daftar."), 8)
        root.add(phCard, 8)

        // ---------- AKSI ----------
        root.add(button("Simpan", true) { save() }, 24)
        if (existing != null) {
            root.add(button("Hapus aksi", false) { confirmDelete() }.apply {
                background = Ui.rounded(this@ActionEditActivity, Ui.COLOR_BAD, 10)
                setTextColor(Color.WHITE)
            }, 8)
        }
        root.add(button("Batal", false) { finish() }, 8)

        setContentView(ScrollView(this).apply {
            setBackgroundColor(pal.bg)
            addView(root, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        })
        Ui.applyScale(root, Ui.scaleValue(this))
    }

    private fun refreshIcons() {
        iconBoxes.forEachIndexed { i, box ->
            box.background = Ui.rounded(this, if (i == icon) pal.primary else pal.second, 10)
        }
    }

    private fun insertToken(token: String) {
        val pos = tplField.selectionStart.coerceAtLeast(0)
        tplField.text.insert(pos, token)
        tplField.requestFocus()
        tplField.setSelection(pos + token.length)
    }

    private fun save() {
        val name = nameField.text.toString().trim()
        val tpl = tplField.text.toString().trim()
        if (name.isEmpty()) { toast("Nama tidak boleh kosong"); return }
        if (tpl.isEmpty()) { toast("Template tidak boleh kosong"); return }
        val list = Actions.load(this)
        val id = editId
        if (id != null) {
            val idx = list.indexOfFirst { it.id == id }
            if (idx >= 0) list[idx] = list[idx].copy(name = name, icon = icon, template = tpl)
        } else {
            if (Actions.customCount(list) >= Actions.MAX_CUSTOM) {
                toast("Maksimal ${Actions.MAX_CUSTOM} aksi custom")
                return
            }
            list.add(Action("custom-" + System.currentTimeMillis(), name, icon, tpl, true, null))
        }
        Actions.save(this, list)
        toast("Aksi tersimpan")
        finish()
    }

    private fun confirmDelete() {
        AlertDialog.Builder(this)
            .setTitle("Hapus aksi?")
            .setMessage("Aksi ini akan dihapus dari daftar. Tindakan ini tidak dapat dibatalkan.")
            .setPositiveButton("Ya, hapus") { _, _ ->
                val list = Actions.load(this)
                list.removeAll { it.id == editId }
                Actions.save(this, list)
                finish()
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    // ---------- helper ----------
    private fun px(n: Int) = Ui.px(this, n)
    private fun card() = Ui.card(this, pal)
    private fun section(t: String) = Ui.section(this, pal, t)
    private fun note(t: String) = TextView(this).apply {
        text = t
        textSize = 12f
        setTextColor(pal.muted)
    }
    private fun button(caption: String, primary: Boolean, onClick: () -> Unit) =
        Ui.button(this, pal, caption, primary, onClick)
    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()
    private fun LinearLayout.add(v: View, topDp: Int = 8) = Ui.addTop(this, v, topDp)
}
