package id.nuviobridge

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*

class ActionEditActivity : Activity() {

    private lateinit var pal: Pal
    private lateinit var nameField: EditText
    private lateinit var tplField: EditText
    private var saveBtn: Button? = null
    private var origName = ""
    private var origTpl = ""
    private var origIcon = 0
    private lateinit var iconHolder: FrameLayout
    private var editId: String? = null
    private var icon = Actions.ICON_LINK

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        pal = Ui.pal(this)
        editId = intent.getStringExtra("id")
        val existing = Actions.load(this).firstOrNull { it.id == editId }
        icon = existing?.icon ?: Actions.ICON_LINK
        origName = existing?.name.orEmpty()
        origTpl = existing?.template.orEmpty()
        origIcon = icon

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(px(16), px(20), px(16), px(24))
            setBackgroundColor(pal.bg)
        }
        root.addView(TextView(this).apply {
            text = if (existing == null) "Aksi Baru" else "Edit Aksi"
            textSize = 22f
            setTextColor(pal.text)
            typeface = Typeface.DEFAULT_BOLD
        })

        // ---------- NAMA ----------
        root.add(section("NAMA"), 16)
        val nameCard = card()
        nameField = EditText(this).apply {
            hint = "Nama aksi, mis. Viki"
            setHintTextColor(pal.muted)
            setTextColor(pal.text)
            setSingleLine()
            setText(existing?.name.orEmpty())
        }
        nameCard.add(nameField, 0)
        root.add(nameCard, 6)

        // ---------- IKON ----------
        root.add(section("IKON"), 16)
        val iconCard = card()
        iconHolder = FrameLayout(this)
        iconCard.addView(iconHolder)
        iconCard.addView(note("Ketuk ikon untuk memilih dari grid."), LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = px(6) })
        root.add(iconCard, 6)
        refreshIcon()

        // ---------- TEMPLATE ----------
        root.add(section("TEMPLATE URL"), 16)
        val tplCard = card()
        tplField = EditText(this).apply {
            hint = "mis. https://www.youtube.com/results?search_query={title}+{year}"
            setHintTextColor(pal.muted)
            setTextColor(pal.text)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            minLines = 2
            maxLines = 5
            setText(existing?.template.orEmpty())
        }
        tplCard.add(tplField, 0)
        tplCard.add(note("Skema bebas (https://, appname://). Placeholder diganti otomatis saat dibuka."), 6)
        root.add(tplCard, 6)

        // ---------- PLACEHOLDER ----------
        root.add(section("PLACEHOLDER (ketuk untuk menyisipkan)"), 16)
        val phCard = card()
        Actions.PLACEHOLDERS.chunked(2).forEachIndexed { r, pair ->
            val line = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            pair.forEachIndexed { i, ph ->
                line.addView(chip(ph.first, ph.second) { insertToken(ph.first) },
                    LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                        if (i > 0) leftMargin = px(4)
                    })
            }
            phCard.add(line, if (r == 0) 0 else 4)
        }
        phCard.add(note("{imdbId}, {tvdbId}, {tmdbId} hanya dipakai saat datanya ada. Jika tidak ada, aksi disembunyikan."), 6)
        root.add(phCard, 6)

        // ---------- TOMBOL ----------
        saveBtn = button("Simpan", true) { save() }
        root.add(saveBtn!!, 20)
        val watch = object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: android.text.Editable?) { refreshSave() }
        }
        nameField.addTextChangedListener(watch)
        tplField.addTextChangedListener(watch)
        refreshSave()
        if (existing != null) {
            root.add(Ui.dangerButton(this, "Hapus Aksi") { confirmDelete() }, 8)
        }
        root.add(button("Batal", false) { finish() }, 8)

        setContentView(ScrollView(this).apply {
            setBackgroundColor(pal.bg)
            addView(root, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        })
        Ui.applyScale(root, Ui.scaleValue(this))
    }

    /** Simpan aktif hanya saat siap: aksi baru perlu nama dan template, aksi edit perlu ada perubahan. */
    private fun refreshSave() {
        val btn = saveBtn ?: return
        val name = nameField.text.toString().trim()
        val tpl = tplField.text.toString().trim()
        val ok = if (editId == null) name.isNotEmpty() && tpl.isNotEmpty()
                 else name != origName || tpl != origTpl || icon != origIcon
        btn.isEnabled = ok
        btn.alpha = if (ok) 1f else 0.4f
    }

    private fun refreshIcon() {
        refreshSave()
        iconHolder.removeAllViews()
        val btn = Ui.iconButton(this, pal, icon) {
            Ui.iconPicker(this, pal, icon) { picked ->
                icon = picked
                refreshIcon()
            }.show()
        }
        iconHolder.addView(btn, FrameLayout.LayoutParams(px(56), px(56)))
    }

    /** Chip kecil: token dan artinya dalam satu baris. */
    private fun chip(token: String, desc: String, onClick: () -> Unit): Button = Button(this).apply {
        text = "$token  $desc"
        textSize = 12f
        isAllCaps = false
        setSingleLine()
        setPadding(px(6), 0, px(6), 0)
        minHeight = px(36)
        minimumHeight = px(36)
        setTextColor(pal.text)
        background = Ui.rounded(this@ActionEditActivity, pal.second, 8)
        setOnClickListener { onClick() }
    }

    private fun insertToken(token: String) {
        val pos = tplField.selectionStart.coerceAtLeast(0)
        tplField.text.insert(pos, token)
        tplField.requestFocus()
        tplField.setSelection(pos + token.length)
    }

    private fun save() {
        val name = nameField.text.toString().trim()
        val tpl = tplField.text.toString().trim()
        if (name.isEmpty()) { toast("Nama tidak boleh kosong"); return }
        if (tpl.isEmpty()) { toast("Template tidak boleh kosong"); return }
        val list = Actions.load(this)
        val id = editId
        if (id != null) {
            val idx = list.indexOfFirst { it.id == id }
            if (idx >= 0) list[idx] = list[idx].copy(name = name, icon = icon, template = tpl)
        } else {
            if (Actions.customCount(list) >= Actions.MAX_CUSTOM) {
                toast("Maksimal ${Actions.MAX_CUSTOM} aksi custom")
                return
            }
            list.add(Action("custom-" + System.currentTimeMillis(), name, icon, tpl, true, null))
        }
        Actions.save(this, list)
        toast("Aksi tersimpan")
        finish()
    }

    private fun confirmDelete() {
        Ui.dialog(this)
            .setTitle("Hapus Aksi?")
            .setMessage("Aksi ini akan dihapus dari daftar. Tindakan ini tidak dapat dibatalkan.")
            .setPositiveButton("Ya, Hapus") { _, _ ->
                val list = Actions.load(this)
                list.removeAll { it.id == editId }
                Actions.save(this, list)
                finish()
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    // ---------- helper ----------
    private fun px(n: Int) = Ui.px(this, n)
    private fun card() = Ui.card(this, pal)
    private fun section(t: String) = Ui.section(this, pal, t)
    private fun note(t: String) = TextView(this).apply {
        text = t
        textSize = 12f
        setTextColor(pal.muted)
    }
    private fun button(caption: String, primary: Boolean, onClick: () -> Unit) =
        Ui.button(this, pal, caption, primary, onClick)
    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()
    private fun LinearLayout.add(v: View, topDp: Int = 8) = Ui.addTop(this, v, topDp)
}
