package id.nuviobridge

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.net.Uri
import android.view.View
import org.json.JSONArray
import org.json.JSONObject

/** Aksi share. builtin = "nuvio" | "google" untuk bawaan, null untuk aksi custom. */
data class Action(
    val id: String,
    val name: String,
    val icon: Int,
    val template: String,
    val enabled: Boolean,
    val builtin: String?
)

/** Data judul yang dipakai untuk membangun URL aksi. */
class Target(
    val titles: List<String>,
    val year: Int?,
    val type: String?,      // "movie" | "tv" | null
    val country: String?,   // kode (KR) atau nama (South Korea)
    val tmdbId: Int?,
    val imdbId: String?,
    val tvdbId: Int?
)

object Actions {
    private const val KEY = "actions"
    const val MAX_CUSTOM = 10
    const val ICON_COUNT = 6

    private val COUNTRY_NAMES = mapOf(
        "KR" to "South Korea", "JP" to "Japan", "CN" to "China", "TW" to "Taiwan",
        "HK" to "Hong Kong", "TH" to "Thailand", "PH" to "Philippines", "ID" to "Indonesia",
        "US" to "United States", "GB" to "United Kingdom", "MY" to "Malaysia", "SG" to "Singapore"
    )

    /** Placeholder yang tersedia, untuk ditampilkan di editor. */
    val PLACEHOLDERS = listOf(
        "{title}" to "judul utama",
        "{year}" to "tahun",
        "{type}" to "movie / series",
        "{tmdbType}" to "movie / tv",
        "{kind}" to "film / drama",
        "{country}" to "negara",
        "{query}" to "kueri lengkap",
        "{tmdbId}" to "ID TMDB",
        "{imdbId}" to "ID IMDb",
        "{tvdbId}" to "ID TVDB"
    )

    fun defaults(): MutableList<Action> = mutableListOf(
        Action("nuvio", "Nuvio", 0, "", true, "nuvio"),
        Action("google", "Google", 1, "", true, "google")
    )

    fun load(ctx: Context): MutableList<Action> {
        val raw = ctx.getSharedPreferences(Ui.PREFS, Context.MODE_PRIVATE).getString(KEY, null)
            ?: return defaults()
        val list = mutableListOf<Action>()
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                list.add(
                    Action(
                        id = o.getString("id"),
                        name = o.getString("name"),
                        icon = o.optInt("icon", 5),
                        template = o.optString("template", ""),
                        enabled = o.optBoolean("enabled", true),
                        builtin = if (o.has("builtin")) o.getString("builtin") else null
                    )
                )
            }
        } catch (e: Exception) {
            return defaults()
        }
        // Nuvio dan Google selalu ada
        if (list.none { it.builtin == "nuvio" }) list.add(0, defaults()[0])
        if (list.none { it.builtin == "google" }) list.add(defaults()[1])
        return list
    }

    fun save(ctx: Context, list: List<Action>) {
        val arr = JSONArray()
        for (a in list) {
            arr.put(JSONObject().apply {
                put("id", a.id)
                put("name", a.name)
                put("icon", a.icon)
                put("template", a.template)
                put("enabled", a.enabled)
                if (a.builtin != null) put("builtin", a.builtin)
            })
        }
        ctx.getSharedPreferences(Ui.PREFS, Context.MODE_PRIVATE).edit().putString(KEY, arr.toString()).apply()
    }

    fun reset(ctx: Context) {
        ctx.getSharedPreferences(Ui.PREFS, Context.MODE_PRIVATE).edit().remove(KEY).apply()
    }

    fun customCount(list: List<Action>) = list.count { it.builtin == null }

    fun countryName(c: String?): String {
        if (c.isNullOrBlank()) return ""
        return COUNTRY_NAMES[c.uppercase()] ?: c
    }

    /** Aksi custom hanya tersedia kalau semua ID yang dipakai templatenya sudah ada. */
    fun available(a: Action, t: Target): Boolean = when (a.builtin) {
        "nuvio" -> t.imdbId != null && t.tmdbId != null
        "google" -> true
        else -> (!a.template.contains("{imdbId}") || t.imdbId != null) &&
            (!a.template.contains("{tvdbId}") || t.tvdbId != null) &&
            (!a.template.contains("{tmdbId}") || t.tmdbId != null)
    }

    /** Mengisi placeholder template custom. Nilai diurai agar aman di URL. */
    fun fill(template: String, t: Target): String {
        val title = t.titles.firstOrNull { it.isNotBlank() }.orEmpty()
        val yearText = t.year?.toString().orEmpty()
        val kind = when (t.type) {
            "tv" -> "drama"
            "movie" -> "film"
            else -> ""
        }
        val typeWord = when (t.type) {
            "tv" -> "series"
            "movie" -> "movie"
            else -> ""
        }
        val country = countryName(t.country)
        val query = listOf(title, yearText, kind, country).filter { it.isNotEmpty() }.joinToString(" ")
        val values = linkedMapOf(
            "{query}" to query,
            "{title}" to title,
            "{year}" to yearText,
            "{type}" to typeWord,
            "{tmdbType}" to t.type.orEmpty(),
            "{kind}" to kind,
            "{country}" to country,
            "{tmdbId}" to (t.tmdbId?.toString().orEmpty()),
            "{imdbId}" to t.imdbId.orEmpty(),
            "{tvdbId}" to (t.tvdbId?.toString().orEmpty())
        )
        var out = template
        for ((k, v) in values) out = out.replace(k, Uri.encode(v))
        return if (out.contains("://")) out else "https://$out"
    }
}

/** Ikon aksi yang digambar langsung: 0 play, 1 cari, 2 film, 3 TV, 4 bintang, 5 tautan. */
class ActionIconView(ctx: Context, private val icon: Int, private val color: Int) : View(ctx) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        this.color = this@ActionIconView.color
        style = Paint.Style.STROKE
        strokeWidth = ctx.resources.displayMetrics.density * 2f
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        this.color = this@ActionIconView.color
        style = Paint.Style.FILL
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val s = Math.min(w, h)
        val ox = (w - s) / 2f
        val oy = (h - s) / 2f
        fun x(f: Float) = ox + f * s
        fun y(f: Float) = oy + f * s
        when (icon) {
            0 -> {
                c.drawCircle(x(0.5f), y(0.5f), 0.46f * s, paint)
                val p = Path().apply {
                    moveTo(x(0.42f), y(0.32f))
                    lineTo(x(0.42f), y(0.68f))
                    lineTo(x(0.70f), y(0.5f))
                    close()
                }
                c.drawPath(p, fill)
            }
            1 -> {
                c.drawCircle(x(0.44f), y(0.44f), 0.30f * s, paint)
                c.drawLine(x(0.66f), y(0.66f), x(0.88f), y(0.88f), paint)
            }
            2 -> {
                c.drawRoundRect(RectF(x(0.1f), y(0.2f), x(0.9f), y(0.8f)), 0.05f * s, 0.05f * s, paint)
                c.drawLine(x(0.25f), y(0.2f), x(0.25f), y(0.8f), paint)
                c.drawLine(x(0.75f), y(0.2f), x(0.75f), y(0.8f), paint)
            }
            3 -> {
                c.drawRoundRect(RectF(x(0.1f), y(0.2f), x(0.9f), y(0.7f)), 0.05f * s, 0.05f * s, paint)
                c.drawLine(x(0.3f), y(0.85f), x(0.7f), y(0.85f), paint)
            }
            4 -> {
                val p = Path()
                for (i in 0 until 10) {
                    val angle = -Math.PI / 2 + i * Math.PI / 5
                    val r = if (i % 2 == 0) 0.46f else 0.2f
                    val px = x(0.5f) + r * s * Math.cos(angle).toFloat()
                    val py = y(0.5f) + r * s * Math.sin(angle).toFloat()
                    if (i == 0) p.moveTo(px, py) else p.lineTo(px, py)
                }
                p.close()
                c.drawPath(p, paint)
            }
            else -> {
                c.drawRoundRect(RectF(x(0.1f), y(0.36f), x(0.6f), y(0.64f)), 0.14f * s, 0.14f * s, paint)
                c.drawRoundRect(RectF(x(0.4f), y(0.36f), x(0.9f), y(0.64f)), 0.14f * s, 0.14f * s, paint)
            }
        }
    }
}
