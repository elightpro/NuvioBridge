package id.nuviobridge

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.net.Uri
import android.view.View
import org.json.JSONArray
import org.json.JSONObject

/** Aksi share. builtin = "nuvio" | "google" untuk bawaan, null untuk aksi custom. */
data class Action(
    val id: String,
    val name: String,
    val icon: Int,
    val template: String,
    val enabled: Boolean,
    val builtin: String?
)

/** Data judul yang dipakai untuk membangun URL aksi. */
class Target(
    val titles: List<String>,
    val year: Int?,
    val type: String?,      // "movie" | "tv" | null
    val country: String?,   // kode (KR) atau nama (South Korea)
    val tmdbId: Int?,
    val imdbId: String?,
    val tvdbId: Int?
)

object Actions {
    private const val KEY = "actions"
    const val ICON_PLAY = 0
    const val ICON_SEARCH = 1
    const val ICON_GLOBE = 2
    const val ICON_LINK = 3
    const val MAX_CUSTOM = 20
    const val ICON_COUNT = 66
    /** Indeks ikon: 0-19 simbol; 20-45 huruf A-Z; 46-51 kombinasi (Vi, Vd, Pv, D+, iQ, WT); 52-57 streaming; 58-60 angka dan kombinasi; 61-63 play; 64 TV; 65 Box. */

    private val COUNTRY_NAMES = mapOf(
        "KR" to "South Korea", "JP" to "Japan", "CN" to "China", "TW" to "Taiwan",
        "HK" to "Hong Kong", "TH" to "Thailand", "PH" to "Philippines", "ID" to "Indonesia",
        "US" to "United States", "GB" to "United Kingdom", "MY" to "Malaysia", "SG" to "Singapore"
    )

    /** Placeholder yang tersedia, untuk ditampilkan di editor. */
    val PLACEHOLDERS = listOf(
        "{title}" to "judul utama",
        "{year}" to "tahun",
        "{type}" to "movie / series",
        "{tmdbType}" to "movie / tv",
        "{kind}" to "film / drama",
        "{country}" to "negara",
        "{query}" to "kueri lengkap",
        "{tmdbId}" to "ID TMDB",
        "{imdbId}" to "ID IMDb",
        "{tvdbId}" to "ID TVDB"
    )

    fun defaults(): MutableList<Action> = mutableListOf(
        Action("nuvio", "Nuvio", ICON_PLAY, "", true, "nuvio"),
        Action("google", "Google", ICON_GLOBE, "", true, "google")
    )

    fun load(ctx: Context): MutableList<Action> {
        val raw = ctx.getSharedPreferences(Ui.PREFS, Context.MODE_PRIVATE).getString(KEY, null)
            ?: return defaults()
        val list = mutableListOf<Action>()
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                list.add(
                    Action(
                        id = o.getString("id"),
                        name = o.getString("name"),
                        icon = o.optInt("icon", ICON_LINK),
                        template = o.optString("template", ""),
                        enabled = o.optBoolean("enabled", true),
                        builtin = if (o.has("builtin")) o.getString("builtin") else null
                    )
                )
            }
        } catch (e: Exception) {
            return defaults()
        }
        // Nuvio dan Google selalu ada
        if (list.none { it.builtin == "nuvio" }) list.add(0, defaults()[0])
        if (list.none { it.builtin == "google" }) list.add(defaults()[1])
        return migrateIcons(ctx, list)
    }

    /** Sekali saja: indeks ikon versi lama dipetakan ke set ikon baru (filled). */
    private fun migrateIcons(ctx: Context, list: MutableList<Action>): MutableList<Action> {
        val prefs = ctx.getSharedPreferences(Ui.PREFS, Context.MODE_PRIVATE)
        if (prefs.getBoolean("icon_v2", false)) return list
        val map = mapOf(0 to 0, 1 to 1, 2 to 10, 3 to 11, 4 to 5, 5 to 3)
        for (i in list.indices) {
            val a = list[i]
            if (a.builtin == "nuvio") list[i] = a.copy(icon = ICON_PLAY)
            else if (a.builtin == "google") list[i] = a.copy(icon = ICON_GLOBE)
            else list[i] = a.copy(icon = map[a.icon] ?: ICON_LINK)
        }
        save(ctx, list)
        prefs.edit().putBoolean("icon_v2", true).apply()
        return list
    }

    fun save(ctx: Context, list: List<Action>) {
        val arr = JSONArray()
        for (a in list) {
            arr.put(JSONObject().apply {
                put("id", a.id)
                put("name", a.name)
                put("icon", a.icon)
                put("template", a.template)
                put("enabled", a.enabled)
                if (a.builtin != null) put("builtin", a.builtin)
            })
        }
        ctx.getSharedPreferences(Ui.PREFS, Context.MODE_PRIVATE).edit().putString(KEY, arr.toString()).apply()
    }

    fun reset(ctx: Context) {
        ctx.getSharedPreferences(Ui.PREFS, Context.MODE_PRIVATE).edit().remove(KEY).apply()
    }

    fun customCount(list: List<Action>) = list.count { it.builtin == null }

    fun countryName(c: String?): String {
        if (c.isNullOrBlank()) return ""
        return COUNTRY_NAMES[c.uppercase()] ?: c
    }

    /** Aksi custom hanya tersedia kalau semua ID yang dipakai templatenya sudah ada. */
    fun available(a: Action, t: Target): Boolean = when (a.builtin) {
        "nuvio" -> t.imdbId != null && t.tmdbId != null
        "google" -> true
        else -> (!a.template.contains("{imdbId}") || t.imdbId != null) &&
            (!a.template.contains("{tvdbId}") || t.tvdbId != null) &&
            (!a.template.contains("{tmdbId}") || t.tmdbId != null)
    }

    /** Mengisi placeholder template custom. Nilai diurai agar aman di URL. */
    fun fill(template: String, t: Target): String {
        val title = t.titles.firstOrNull { it.isNotBlank() }.orEmpty()
        val yearText = t.year?.toString().orEmpty()
        val kind = when (t.type) {
            "tv" -> "drama"
            "movie" -> "film"
            else -> ""
        }
        val typeWord = when (t.type) {
            "tv" -> "series"
            "movie" -> "movie"
            else -> ""
        }
        val country = countryName(t.country)
        val query = listOf(title, yearText, kind, country).filter { it.isNotEmpty() }.joinToString(" ")
        val values = linkedMapOf(
            "{query}" to query,
            "{title}" to title,
            "{year}" to yearText,
            "{type}" to typeWord,
            "{tmdbType}" to t.type.orEmpty(),
            "{kind}" to kind,
            "{country}" to country,
            "{tmdbId}" to (t.tmdbId?.toString().orEmpty()),
            "{imdbId}" to t.imdbId.orEmpty(),
            "{tvdbId}" to (t.tvdbId?.toString().orEmpty())
        )
        var out = template
        for ((k, v) in values) out = out.replace(k, Uri.encode(v))
        return if (out.contains("://")) out else "https://$out"
    }
}

/** Ikon aksi (filled, dihaluskan), digambar langsung. Indeks 0..65, lihat Actions.ICON_COUNT. */
class ActionIconView(ctx: Context, private val icon: Int, private val color: Int) : View(ctx) {
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        this.color = this@ActionIconView.color
        style = Paint.Style.FILL
    }
    private val cut = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        this.color = Color.WHITE
        style = Paint.Style.FILL
    }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        this.color = this@ActionIconView.color
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val cutLine = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        this.color = Color.WHITE
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val letterPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        this.color = Color.WHITE
        typeface = android.graphics.Typeface.DEFAULT_BOLD
        textAlign = Paint.Align.CENTER
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val s = Math.min(w, h)
        val ox = (w - s) / 2f
        val oy = (h - s) / 2f
        fun x(f: Float) = ox + f * s
        fun y(f: Float) = oy + f * s
        fun rect(l: Float, t: Float, r: Float, b: Float, rad: Float = 0.08f) {
            c.drawRoundRect(RectF(x(l), y(t), x(r), y(b)), rad * s, rad * s, fill)
        }
        fun poly(vararg pts: Float, paint: Paint = fill) {
            val p = Path()
            var i = 0
            while (i < pts.size) {
                if (i == 0) p.moveTo(x(pts[i]), y(pts[i + 1])) else p.lineTo(x(pts[i]), y(pts[i + 1]))
                i += 2
            }
            p.close()
            c.drawPath(p, paint)
        }
        fun letter(t: String, sizeFactor: Float) {
            c.drawRoundRect(RectF(x(0.06f), y(0.06f), x(0.94f), y(0.94f)), 0.2f * s, 0.2f * s, fill)
            letterPaint.textSize = sizeFactor * s
            c.drawText(t, x(0.5f), y(0.5f) - (letterPaint.descent() + letterPaint.ascent()) / 2f, letterPaint)
        }
        fun arcs(radii: List<Float>, startDeg: Float, sweep: Float, cx: Float, cy: Float) {
            for (r in radii) {
                c.drawArc(RectF(x(cx - r), y(cy - r), x(cx + r), y(cy + r)), startDeg, sweep, false, line)
            }
        }
        when (icon) {
            0 -> poly(0.3f, 0.2f, 0.3f, 0.8f, 0.8f, 0.5f)
            1 -> {
                line.strokeWidth = 0.12f * s
                c.drawCircle(x(0.42f), y(0.42f), 0.27f * s, line)
                c.drawLine(x(0.63f), y(0.63f), x(0.88f), y(0.88f), line)
            }
            2 -> {
                c.drawCircle(x(0.5f), y(0.5f), 0.44f * s, fill)
                cutLine.strokeWidth = 0.05f * s
                c.drawOval(RectF(x(0.28f), y(0.06f), x(0.72f), y(0.94f)), cutLine)
                c.drawLine(x(0.06f), y(0.5f), x(0.94f), y(0.5f), cutLine)
            }
            3 -> {
                line.strokeWidth = 0.15f * s
                c.drawRoundRect(RectF(x(0.08f), y(0.34f), x(0.56f), y(0.66f)), 0.16f * s, 0.16f * s, line)
                c.drawRoundRect(RectF(x(0.44f), y(0.34f), x(0.92f), y(0.66f)), 0.16f * s, 0.16f * s, line)
            }
            4 -> {
                c.drawCircle(x(0.5f), y(0.5f), 0.46f * s, fill)
                poly(0.5f, 0.18f, 0.6f, 0.42f, 0.84f, 0.44f, 0.65f, 0.6f, 0.72f, 0.84f,
                    0.5f, 0.7f, 0.28f, 0.84f, 0.35f, 0.6f, 0.16f, 0.44f, 0.4f, 0.42f, paint = cut)
            }
            5 -> poly(0.5f, 0.05f, 0.61f, 0.38f, 0.95f, 0.38f, 0.67f, 0.6f, 0.78f, 0.95f,
                0.5f, 0.73f, 0.22f, 0.95f, 0.33f, 0.6f, 0.05f, 0.38f, 0.39f, 0.38f)
            6 -> {
                val p = Path()
                p.moveTo(x(0.5f), y(0.88f))
                p.cubicTo(x(0.05f), y(0.55f), x(0.05f), y(0.15f), x(0.27f), y(0.15f))
                p.cubicTo(x(0.38f), y(0.15f), x(0.47f), y(0.22f), x(0.5f), y(0.3f))
                p.cubicTo(x(0.53f), y(0.22f), x(0.62f), y(0.15f), x(0.73f), y(0.15f))
                p.cubicTo(x(0.95f), y(0.15f), x(0.95f), y(0.55f), x(0.5f), y(0.88f))
                p.close()
                c.drawPath(p, fill)
            }
            7 -> poly(0.22f, 0.1f, 0.78f, 0.1f, 0.78f, 0.9f, 0.5f, 0.68f, 0.22f, 0.9f)
            8 -> {
                poly(0.1f, 0.12f, 0.55f, 0.12f, 0.9f, 0.5f, 0.55f, 0.88f, 0.1f, 0.43f)
                c.drawCircle(x(0.3f), y(0.3f), 0.07f * s, cut)
            }
            9 -> {
                c.drawCircle(x(0.5f), y(0.5f), 0.44f * s, fill)
                cutLine.strokeWidth = 0.07f * s
                c.drawLine(x(0.5f), y(0.25f), x(0.5f), y(0.66f), cutLine)
                c.drawLine(x(0.32f), y(0.5f), x(0.5f), y(0.68f), cutLine)
                c.drawLine(x(0.5f), y(0.68f), x(0.68f), y(0.5f), cutLine)
            }
            10 -> {
                rect(0.1f, 0.18f, 0.9f, 0.82f, 0.05f)
                for (k in 0..3) {
                    val yy = 0.24f + k * 0.17f
                    c.drawRect(x(0.14f), y(yy), x(0.22f), y(yy + 0.09f), cut)
                    c.drawRect(x(0.78f), y(yy), x(0.86f), y(yy + 0.09f), cut)
                }
            }
            11 -> {
                rect(0.08f, 0.18f, 0.92f, 0.7f, 0.08f)
                line.strokeWidth = 0.09f * s
                c.drawLine(x(0.3f), y(0.86f), x(0.7f), y(0.86f), line)
            }
            12 -> {
                rect(0.1f, 0.4f, 0.9f, 0.85f, 0.06f)
                rect(0.1f, 0.2f, 0.9f, 0.36f, 0.04f)
            }
            13 -> {
                rect(0.08f, 0.16f, 0.92f, 0.7f, 0.08f)
                rect(0.44f, 0.7f, 0.56f, 0.82f, 0.0f)
                rect(0.28f, 0.82f, 0.72f, 0.88f, 0.04f)
            }
            14 -> {
                // musik: kepala nada, batang, dan bendera melengkung
                c.drawCircle(x(0.3f), y(0.7f), 0.17f * s, fill)
                line.strokeWidth = 0.11f * s
                c.drawLine(x(0.47f), y(0.7f), x(0.47f), y(0.2f), line)
                val p = Path()
                p.moveTo(x(0.47f), y(0.2f))
                p.cubicTo(x(0.6f), y(0.26f), x(0.72f), y(0.32f), x(0.8f), y(0.4f))
                c.drawPath(p, line)
            }
            15 -> {
                // headphone: busur atas dan dua bantalan
                line.strokeWidth = 0.1f * s
                c.drawArc(RectF(x(0.14f), y(0.14f), x(0.86f), y(0.86f)), 180f, 180f, false, line)
                rect(0.1f, 0.5f, 0.28f, 0.86f, 0.08f)
                rect(0.72f, 0.5f, 0.9f, 0.86f, 0.08f)
            }
            16 -> {
                rect(0.12f, 0.14f, 0.88f, 0.86f, 0.05f)
                cutLine.strokeWidth = 0.05f * s
                c.drawLine(x(0.5f), y(0.14f), x(0.5f), y(0.86f), cutLine)
            }
            17 -> {
                rect(0.12f, 0.2f, 0.88f, 0.88f, 0.06f)
                cutLine.strokeWidth = 0.06f * s
                c.drawLine(x(0.12f), y(0.42f), x(0.88f), y(0.42f), cutLine)
            }
            18 -> {
                c.drawCircle(x(0.5f), y(0.5f), 0.44f * s, fill)
                c.drawCircle(x(0.5f), y(0.3f), 0.06f * s, cut)
                cutLine.strokeWidth = 0.1f * s
                c.drawLine(x(0.5f), y(0.45f), x(0.5f), y(0.72f), cutLine)
            }
            19 -> poly(0.5f, 0.05f, 0.6f, 0.4f, 0.95f, 0.5f, 0.6f, 0.6f, 0.5f, 0.95f,
                0.4f, 0.6f, 0.05f, 0.5f, 0.4f, 0.4f)
            52 -> {
                // cast: layar dengan gelombang di pojok kiri bawah
                line.strokeWidth = 0.1f * s
                c.drawRoundRect(RectF(x(0.08f), y(0.2f), x(0.92f), y(0.8f)), 0.12f * s, 0.12f * s, line)
                arcs(listOf(0.14f, 0.26f), 270f, 90f, 0.14f, 0.8f)
                c.drawCircle(x(0.14f), y(0.8f), 0.06f * s, fill)
            }
            53 -> {
                // antena siaran
                line.strokeWidth = 0.1f * s
                c.drawLine(x(0.5f), y(0.46f), x(0.5f), y(0.9f), line)
                c.drawCircle(x(0.5f), y(0.4f), 0.1f * s, fill)
                arcs(listOf(0.26f, 0.42f), 225f, 90f, 0.5f, 0.4f)
                arcs(listOf(0.26f, 0.42f), 315f, 90f, 0.5f, 0.4f)
            }
            54 -> {
                // remote
                rect(0.3f, 0.06f, 0.7f, 0.94f, 0.14f)
                c.drawCircle(x(0.5f), y(0.24f), 0.08f * s, cut)
                c.drawCircle(x(0.5f), y(0.5f), 0.12f * s, cut)
                c.drawCircle(x(0.42f), y(0.72f), 0.04f * s, cut)
                c.drawCircle(x(0.58f), y(0.72f), 0.04f * s, cut)
                c.drawCircle(x(0.5f), y(0.84f), 0.04f * s, cut)
            }
            55 -> {
                // popcorn
                c.drawCircle(x(0.28f), y(0.34f), 0.17f * s, fill)
                c.drawCircle(x(0.5f), y(0.26f), 0.2f * s, fill)
                c.drawCircle(x(0.72f), y(0.34f), 0.17f * s, fill)
                val p = Path()
                p.moveTo(x(0.2f), y(0.46f))
                p.lineTo(x(0.8f), y(0.46f))
                p.lineTo(x(0.7f), y(0.9f))
                p.quadTo(x(0.5f), y(0.96f), x(0.3f), y(0.9f))
                p.close()
                c.drawPath(p, fill)
            }
            56 -> {
                // tiket
                rect(0.06f, 0.26f, 0.94f, 0.74f, 0.12f)
                c.drawCircle(x(0.06f), y(0.5f), 0.09f * s, cut)
                c.drawCircle(x(0.94f), y(0.5f), 0.09f * s, cut)
                cutLine.strokeWidth = 0.04f * s
                c.drawLine(x(0.7f), y(0.34f), x(0.7f), y(0.66f), cutLine)
            }
            57 -> {
                // sinyal streaming
                c.drawCircle(x(0.2f), y(0.8f), 0.12f * s, fill)
                line.strokeWidth = 0.1f * s
                arcs(listOf(0.32f, 0.52f, 0.72f), 270f, 90f, 0.2f, 0.8f)
            }
            in 20..45 -> letter(('A' + (icon - 20)).toString(), 0.62f)
            46 -> letter("Vi", 0.44f)
            47 -> letter("Vd", 0.44f)
            48 -> letter("Pv", 0.44f)
            49 -> letter("D+", 0.44f)
            50 -> letter("iQ", 0.44f)
            51 -> letter("WT", 0.44f)
            58 -> letter("21", 0.44f)
            59 -> letter("K+", 0.44f)
            60 -> letter("Op", 0.44f)
            61 -> {
                c.drawCircle(x(0.5f), y(0.5f), 0.46f * s, fill)
                poly(0.42f, 0.3f, 0.42f, 0.7f, 0.72f, 0.5f, paint = cut)
            }
            62 -> {
                poly(0.5f, 0.06f, 0.94f, 0.5f, 0.5f, 0.94f, 0.06f, 0.5f, paint = fill)
                poly(0.42f, 0.32f, 0.42f, 0.68f, 0.66f, 0.5f, paint = cut)
            }
            63 -> {
                rect(0.06f, 0.06f, 0.94f, 0.94f, 0.2f)
                poly(0.4f, 0.32f, 0.4f, 0.68f, 0.68f, 0.5f, paint = cut)
            }
            64 -> letter("TV", 0.42f)
            65 -> letter("Box", 0.34f)
            else -> {}
        }
    }
}
