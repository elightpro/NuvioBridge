package id.nuviobridge

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * Cache hasil otomatis (bukan pilihan manual).
 * - "mdl:<id>"  : judul yang dipastikan otomatis, berlaku 7 hari.
 * - "ids:<k>"   : IMDb/TVDB dari TMDB. Berlaku 7 hari kalau IMDb ada, 1 hari kalau belum ada.
 * API key tidak disimpan di sini.
 */
object DecisionCache {
    private const val KEY = "cache"
    private const val DAY = 24L * 60 * 60 * 1000
    private const val WEEK = 7 * DAY
    private const val MAX = 200

    fun mdlId(url: String): String? =
        Regex("mydramalist\\.com/(\\d+)").find(url)?.groupValues?.get(1)

    private fun load(ctx: Context): JSONObject = try {
        JSONObject(ctx.getSharedPreferences(Ui.PREFS, Context.MODE_PRIVATE).getString(KEY, "{}") ?: "{}")
    } catch (e: Exception) {
        JSONObject()
    }

    /** Menyimpan cache sambil membuang entri yang sudah kedaluwarsa. */
    private fun store(ctx: Context, o: JSONObject) {
        val now = System.currentTimeMillis()
        val out = JSONObject()
        var n = 0
        for (k in o.keys().asSequence().toList()) {
            val e = o.optJSONObject(k) ?: continue
            val alive = e.optLong("expires", 0L) > now || e.optLong("idsExpires", 0L) > now
            if (alive && n < MAX) {
                out.put(k, e)
                n++
            }
        }
        ctx.getSharedPreferences(Ui.PREFS, Context.MODE_PRIVATE).edit().putString(KEY, out.toString()).apply()
    }

    fun getCandidate(ctx: Context, id: String): Candidate? {
        val e = load(ctx).optJSONObject("mdl:$id") ?: return null
        if (e.optLong("expires", 0L) <= System.currentTimeMillis()) return null
        val countries = mutableListOf<String>()
        val arr = e.optJSONArray("countries")
        if (arr != null) for (i in 0 until arr.length()) countries.add(arr.getString(i))
        return Candidate(
            type = e.optString("type"),
            tmdbId = e.optInt("tmdbId"),
            title = e.optString("title"),
            originalTitle = e.optString("orig"),
            year = e.optInt("year", 0).takeIf { it > 0 },
            lang = e.optString("lang").ifEmpty { null },
            countries = countries,
            poster = e.optString("poster").ifEmpty { null }
        )
    }

    fun putCandidate(ctx: Context, id: String, c: Candidate) {
        val o = load(ctx)
        o.put("mdl:$id", JSONObject().apply {
            put("type", c.type)
            put("tmdbId", c.tmdbId)
            put("title", c.title)
            put("orig", c.originalTitle)
            put("year", c.year ?: 0)
            put("lang", c.lang ?: "")
            put("poster", c.poster ?: "")
            put("countries", JSONArray(c.countries))
            put("expires", System.currentTimeMillis() + WEEK)
        })
        store(ctx, o)
    }

    /** IMDb dan TVDB untuk judul TMDB, kalau masih berlaku. */
    fun getIds(ctx: Context, tmdbKey: String): Pair<String?, Int?>? {
        val e = load(ctx).optJSONObject("ids:$tmdbKey") ?: return null
        if (e.optLong("idsExpires", 0L) <= System.currentTimeMillis()) return null
        return Pair(e.optString("imdb").ifEmpty { null }, e.optInt("tvdb", 0).takeIf { it > 0 })
    }

    fun putIds(ctx: Context, tmdbKey: String, imdb: String?, tvdb: Int?) {
        val o = load(ctx)
        val ttl = if (imdb != null) WEEK else DAY
        o.put("ids:$tmdbKey", JSONObject().apply {
            put("imdb", imdb ?: "")
            put("tvdb", tvdb ?: 0)
            put("idsExpires", System.currentTimeMillis() + ttl)
        })
        store(ctx, o)
    }

    fun clear(ctx: Context) {
        ctx.getSharedPreferences(Ui.PREFS, Context.MODE_PRIVATE).edit().remove(KEY).apply()
    }
}
