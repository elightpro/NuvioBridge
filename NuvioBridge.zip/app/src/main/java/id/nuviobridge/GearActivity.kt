package id.nuviobridge

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*

class GearActivity : Activity() {

    private lateinit var pal: Pal
    private lateinit var root: LinearLayout
    private lateinit var devSection: LinearLayout
    private lateinit var bar: ProgressBar
    private lateinit var status: TextView
    private lateinit var results: LinearLayout
    private lateinit var gtplField: EditText
    private lateinit var gtplStatus: TextView
    private lateinit var gtplError: TextView
    private lateinit var actionsBox: LinearLayout
    private val logs = StringBuilder()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        pal = Ui.pal(this)
        val p = getSharedPreferences(Ui.PREFS, MODE_PRIVATE)

        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(px(16), px(20), px(16), px(24))
            setBackgroundColor(pal.bg)
        }

        devSection = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
        }

        // Judul: tap 5 kali untuk membuka mode pengembang
        var taps = 0
        val title = TextView(this).apply {
            text = "Pengaturan lanjutan"
            textSize = 22f
            setTextColor(pal.text)
            typeface = Typeface.DEFAULT_BOLD
        }
        title.setOnClickListener {
            taps++
            if (taps >= 5 && devSection.visibility == View.GONE) {
                devSection.visibility = View.VISIBLE
                toast("Mode pengembang aktif")
            }
        }
        root.addView(title)
        root.addView(note("Konfigurasi dan aksi share."))

        // ---------- TES LINK MDL (terbuka) ----------
        val tes = card()
        val test = EditText(this).apply {
            hint = "tempel link MyDramaList"
            setHintTextColor(pal.muted)
            setTextColor(pal.text)
            setSingleLine()
        }
        tes.add(test, 0)
        tes.add(button("Tes buka Nuvio", true) {
            startActivity(Intent(this, ShareActivity::class.java).apply {
                action = Intent.ACTION_SEND
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, test.text.toString())
            })
        }, 8)
        root.add(Ui.collapsible(this, pal, "TES LINK MDL", true, tes), 0)

        // ---------- AKSI SAAT SHARE (terbuka) ----------
        val acard = card()
        acard.add(note("Aksi aktif muncul di mode All Actions."), 0)
        actionsBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        acard.add(actionsBox, 8)
        acard.add(button("+ Tambah aksi", true) { addAction() }, 10)
        root.add(Ui.collapsible(this, pal, "AKSI SAAT SHARE", true, acard), 0)
        renderActions()

        // ---------- KONFIGURASI GOOGLE (tertutup) ----------
        val gcard = card()
        gtplStatus = TextView(this).apply { textSize = 12f; setTextColor(pal.muted) }
        gcard.add(Ui.labelRow(this, pal, "Template Google", gtplStatus), 0)
        gtplField = EditText(this).apply {
            setText(Ui.gtpl(this@GearActivity))
            setTextColor(pal.text)
            inputType = InputType.TYPE_TEXT_VARIATION_URI or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            minLines = 1
            maxLines = 3
        }
        gcard.add(gtplField, 4)
        gtplError = TextView(this).apply { textSize = 12f; setTextColor(Ui.COLOR_BAD) }
        gcard.add(gtplError, 4)
        gcard.add(note("{query} {title} {year} {type} {country} {tmdbId}"), 6)
        gcard.add(button("Pakai template standar", false) {
            gtplField.setText(Ui.DEFAULT_GTPL)
            gtplError.text = ""
        }, 10)
        gcard.add(button("Simpan", true) { saveGtpl() }, 8)
        root.add(Ui.collapsible(this, pal, "KONFIGURASI GOOGLE", false, gcard), 0)
        refreshGtplStatus()

        // ---------- PERILAKU (tertutup) ----------
        val pcard = card()
        val prow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        prow.addView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(TextView(this@GearActivity).apply {
                text = "Pertahankan dialog aksi"
                textSize = 15f
                setTextColor(pal.text)
                typeface = Typeface.DEFAULT_BOLD
            })
            addView(note("Dialog muncul lagi sekali saat kembali ke MDLvia."))
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        prow.addView(Switch(this).apply {
            isChecked = p.getBoolean("keep_sheet", false)
            setOnCheckedChangeListener { _, on -> p.edit().putBoolean("keep_sheet", on).apply() }
        })
        pcard.add(prow, 0)
        root.add(Ui.collapsible(this, pal, "PERILAKU", false, pcard), 0)

        // ---------- TAMPILAN (tertutup) ----------
        val scard = card()
        scard.add(note("Ukuran teks"), 0)
        scard.add(Ui.segmentRow(this, pal, listOf("Kecil", "Sedang", "Besar"), { scaleIndex() }) { i ->
            val f = scaleFactors[i]
            p.edit().putString("scale", f.toString()).apply()
            Ui.applyScale(root, f)
        }, 8)
        root.add(Ui.collapsible(this, pal, "TAMPILAN", false, scard), 0)

        // ---------- MODE PENGEMBANG (tersembunyi) ----------
        devSection.add(Ui.section(this, pal, "PENGEMBANG"), 24)
        val devTes = card()
        devTes.add(Ui.section(this, pal, "TES CEPAT NUVIO"), 0)
        devTes.add(LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(button("Tes serial", false) { openNuvio(MainActivity.SERIES_TEST) },
                LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { rightMargin = px(4) })
            addView(button("Tes film", false) { openNuvio(MainActivity.MOVIE_TEST) },
                LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { leftMargin = px(4) })
        }, 8)
        devSection.add(devTes, 8)

        val cacheCard = card()
        cacheCard.add(note("Hasil judul yang disimpan. Hapus kalau ada hasil yang salah."), 0)
        cacheCard.add(button("Hapus cache", false) {
            DecisionCache.clear(this)
            toast("Cache dihapus")
        }, 8)
        devSection.add(Ui.section(this, pal, "CACHE"), 20)
        devSection.add(cacheCard, 8)

        val reg = card()
        bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            isIndeterminate = true
            indeterminateTintList = android.content.res.ColorStateList.valueOf(pal.primary)
            visibility = View.GONE
        }
        status = TextView(this).apply {
            text = "Belum dijalankan."
            textSize = 13f
            setTextColor(pal.muted)
        }
        results = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        reg.add(button("Jalankan 3 uji regresi", true) { runRegression() }, 0)
        reg.add(bar, 8)
        reg.add(status, 8)
        reg.add(button("Salin log lengkap", false) {
            if (logs.isEmpty()) { toast("Belum ada hasil"); return@button }
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("hasil", logs.toString()))
            toast("Disalin")
        }, 8)
        reg.add(button("Hapus hasil", false) {
            results.removeAllViews()
            logs.setLength(0)
            status.text = "Hasil dihapus."
        }, 8)
        reg.add(results, 8)
        devSection.add(Ui.section(this, pal, "UJI REGRESI"), 20)
        devSection.add(reg, 8)
        root.add(devSection, 8)

        // ---------- RESET (berbahaya) ----------
        root.add(Ui.dangerButton(this, "Reset pengaturan") { confirmReset() }, 28)

        setContentView(ScrollView(this).apply {
            setBackgroundColor(pal.bg)
            addView(root, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        })
        Ui.applyScale(root, Ui.scaleValue(this))
    }

    override fun onResume() {
        super.onResume()
        if (::actionsBox.isInitialized) renderActions()
    }

    private val scaleFactors = listOf(0.9f, 1.0f, 1.2f)

    private fun scaleIndex(): Int {
        val v = Ui.scaleValue(this)
        return when {
            v < 0.95f -> 0
            v > 1.1f -> 2
            else -> 1
        }
    }

    // ---------- AKSI ----------

    private fun renderActions() {
        actionsBox.removeAllViews()
        val list = Actions.load(this)
        list.forEachIndexed { i, a ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, px(8), 0, px(8))
            }
            row.addView(Ui.iconButton(this, pal, a.icon) {
                Ui.iconPicker(this, pal, a.icon) { picked ->
                    updateAction(a.id) { it.copy(icon = picked) }
                    renderActions()
                }.show()
            }, LinearLayout.LayoutParams(px(40), px(40)).apply { rightMargin = px(10) })
            val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            info.addView(TextView(this).apply {
                text = a.name
                textSize = 15f
                setTextColor(pal.text)
                typeface = Typeface.DEFAULT_BOLD
            })
            info.addView(TextView(this).apply {
                text = if (a.builtin != null) "Bawaan" else a.template
                textSize = 11f
                setTextColor(pal.muted)
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
            })
            row.addView(info, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(Switch(this).apply {
                isChecked = a.enabled
                setOnCheckedChangeListener { _, on -> updateAction(a.id) { it.copy(enabled = on) } }
            })
            if (i > 0) row.addView(Ui.miniButton(this, pal, "▲") { moveAction(i, -1) }, miniParams())
            if (i < list.size - 1) row.addView(Ui.miniButton(this, pal, "▼") { moveAction(i, 1) }, miniParams())
            if (a.builtin == null) {
                row.addView(Ui.miniButton(this, pal, "✎") {
                    startActivity(Intent(this, ActionEditActivity::class.java).apply { putExtra("id", a.id) })
                }, miniParams())
            }
            actionsBox.addView(row)
            if (i < list.size - 1) {
                actionsBox.addView(View(this), LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, px(1)))
            }
        }
        Ui.applyScale(actionsBox, Ui.scaleValue(this))
    }

    private fun miniParams() = LinearLayout.LayoutParams(px(36), px(36)).apply { leftMargin = px(4) }

    private fun updateAction(id: String, f: (Action) -> Action) {
        val list = Actions.load(this)
        val idx = list.indexOfFirst { it.id == id }
        if (idx >= 0) {
            list[idx] = f(list[idx])
            Actions.save(this, list)
        }
    }

    private fun moveAction(index: Int, delta: Int) {
        val list = Actions.load(this)
        val target = index + delta
        if (index !in list.indices || target !in list.indices) return
        val tmp = list[index]
        list[index] = list[target]
        list[target] = tmp
        Actions.save(this, list)
        renderActions()
    }

    private fun addAction() {
        if (Actions.customCount(Actions.load(this)) >= Actions.MAX_CUSTOM) {
            toast("Maksimal ${Actions.MAX_CUSTOM} aksi custom")
            return
        }
        startActivity(Intent(this, ActionEditActivity::class.java))
    }

    // ---------- TEMPLATE GOOGLE ----------

    private fun saveGtpl() {
        val t = gtplField.text.toString().trim()
        val err = if (t.isEmpty()) "Template tidak boleh kosong" else ""
        gtplError.text = err
        if (err.isNotEmpty()) {
            toast(err)
            return
        }
        getSharedPreferences(Ui.PREFS, MODE_PRIVATE).edit().putString("gtpl", t).apply()
        refreshGtplStatus()
        toast("Template Google tersimpan")
    }

    private fun refreshGtplStatus() {
        val has = getSharedPreferences(Ui.PREFS, MODE_PRIVATE).getString("gtpl", "")?.isNotBlank() == true
        gtplStatus.text = if (has) "✓ Tersimpan" else "Standar"
    }

    // ---------- RESET ----------

    private fun confirmReset() {
        Ui.dialog(this)
            .setTitle("Reset pengaturan?")
            .setMessage("API key, template, aksi, dan tujuan share akan dikembalikan ke standar. Tindakan ini tidak dapat dibatalkan.")
            .setPositiveButton("Ya, reset") { _, _ ->
                getSharedPreferences(Ui.PREFS, MODE_PRIVATE).edit()
                    .remove("key")
                    .putString("tpl", Deeplink.DEFAULT)
                    .putString("gtpl", Ui.DEFAULT_GTPL)
                    .putString("mode", "nuvio")
                    .putBoolean("keep_sheet", false)
                    .apply()
                Actions.reset(this)
                gtplField.setText(Ui.DEFAULT_GTPL)
                gtplError.text = ""
                refreshGtplStatus()
                renderActions()
                toast("Pengaturan direset. Kembali ke layar utama untuk melihat.")
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    // ---------- TES & UJI ----------

    private fun openNuvio(link: String) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(link)))
        } catch (e: ActivityNotFoundException) {
            toast("Nuvio tidak terpasang")
        }
    }

    private fun runRegression() {
        val p = getSharedPreferences(Ui.PREFS, MODE_PRIVATE)
        val key = (p.getString("key", "") ?: "").trim()
        val tpl = (p.getString("tpl", "") ?: "").trim().ifBlank { Deeplink.DEFAULT }
        if (key.isEmpty()) { toast("Isi TMDB API key di layar utama dulu"); return }
        val total = RegressionCases.ALL.size
        results.removeAllViews()
        logs.setLength(0)
        bar.visibility = View.VISIBLE
        status.text = "Menjalankan uji 1 dari $total: ${RegressionCases.ALL[0].name}..."
        Thread {
            val tmdb = Tmdb(key)
            RegressionCases.ALL.forEachIndexed { i, rc ->
                runOnUiThread { status.text = "Menjalankan uji ${i + 1} dari $total: ${rc.name}..." }
                val log = mutableListOf<String>()
                val report = try {
                    Resolver(tmdb, PageFetcher(this)).resolve(rc.url, log)
                } catch (e: Exception) {
                    Report(null, Decision.Fail("Exception: $e"), log)
                }
                val text = RegressionCases.render(rc, report, tmdb, tpl)
                logs.append(text).append("\n\n")
                runOnUiThread {
                    val card = caseCard(text)
                    Ui.applyScale(card, Ui.scaleValue(this))
                    Ui.addTop(results, card, 8)
                    status.text = "Selesai ${i + 1} dari $total"
                }
            }
            runOnUiThread {
                bar.visibility = View.GONE
                status.text = "Selesai. Salin log untuk menyalin semua."
            }
        }.start()
    }

    /** Kartu hasil per kasus. Verdict dan ringkasan diambil dari teks hasil (logika tidak berubah). */
    private fun caseCard(full: String): View {
        val lines = full.lines()
        val name = lines.firstOrNull { it.startsWith("== ") }?.removePrefix("== ")?.removeSuffix(" ==") ?: "Uji"
        val raw = lines.firstOrNull { it.startsWith("HASIL: ") }?.removePrefix("HASIL: ") ?: "?"
        val (badge, color) = when {
            raw.startsWith("PASS") -> "PASS" to Ui.COLOR_OK
            raw.startsWith("FAIL") -> "FAIL" to Ui.COLOR_BAD
            raw.startsWith("AMBIGU") -> "AMBIGU" to Ui.COLOR_WARN
            else -> "MANUAL" to Ui.COLOR_WARN
        }
        val summary = lines.filter {
            it.startsWith("MDL: ") || it.startsWith("KEPUTUSAN: ") || it.startsWith("LINK: ")
        }

        val c = card()
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        head.addView(TextView(this).apply {
            text = name
            textSize = 15f
            setTextColor(pal.text)
            typeface = Typeface.DEFAULT_BOLD
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        head.addView(TextView(this).apply {
            text = badge
            textSize = 12f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(px(8), px(3), px(8), px(3))
            background = Ui.rounded(this@GearActivity, color, 6)
        })
        c.add(head, 0)
        c.add(TextView(this).apply {
            text = summary.joinToString("\n")
            textSize = 13f
            setTextColor(pal.text)
        }, 8)
        val details = TextView(this).apply {
            text = full
            typeface = Typeface.MONOSPACE
            textSize = 11f
            setTextColor(pal.muted)
            setTextIsSelectable(true)
            visibility = View.GONE
        }
        c.add(details, 8)
        c.add(button("Lihat log", false) {
            details.visibility = if (details.visibility == View.GONE) View.VISIBLE else View.GONE
        }, 8)
        return c
    }

    // ---------- helper ----------
    private fun px(n: Int) = Ui.px(this, n)
    private fun card() = Ui.card(this, pal)
    private fun note(t: String) = TextView(this).apply {
        text = t
        textSize = 12f
        setTextColor(pal.muted)
    }
    private fun button(caption: String, primary: Boolean, onClick: () -> Unit) =
        Ui.button(this, pal, caption, primary, onClick)
    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()
    private fun LinearLayout.add(v: View, topDp: Int = 8) = Ui.addTop(this, v, topDp)
}
