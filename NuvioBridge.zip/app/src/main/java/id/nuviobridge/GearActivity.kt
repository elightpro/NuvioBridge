package id.nuviobridge

import android.app.Activity
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*

class GearActivity : Activity() {

    private lateinit var pal: Pal
    private lateinit var root: LinearLayout
    private lateinit var bar: ProgressBar
    private lateinit var status: TextView
    private lateinit var results: LinearLayout
    private lateinit var historyBox: LinearLayout
    private lateinit var scaleLabel: TextView
    private val logs = StringBuilder()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        pal = Ui.pal(this)
        val p = getSharedPreferences(Ui.PREFS, MODE_PRIVATE)

        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(px(16), px(20), px(16), px(24))
            setBackgroundColor(pal.bg)
        }

        root.addView(TextView(this).apply {
            text = "Pengaturan lanjutan"
            textSize = 22f
            setTextColor(pal.text)
            typeface = Typeface.DEFAULT_BOLD
        })
        root.addView(TextView(this).apply {
            text = "Alat uji dan data lokal. Tekan tombol kembali untuk kembali ke layar utama."
            textSize = 13f
            setTextColor(pal.muted)
        })

        // ---------- UJI REGRESI ----------
        root.add(section("UJI REGRESI"), 20)
        val reg = card()
        bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            isIndeterminate = true
            visibility = View.GONE
        }
        status = TextView(this).apply {
            text = "Belum dijalankan."
            textSize = 13f
            setTextColor(pal.muted)
        }
        results = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        reg.add(button("Jalankan 3 uji regresi", true) { runRegression() }, 0)
        reg.add(bar, 8)
        reg.add(status, 8)
        reg.add(button("Salin log lengkap", false) {
            if (logs.isEmpty()) { toast("Belum ada hasil"); return@button }
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("hasil", logs.toString()))
            toast("Disalin")
        }, 8)
        reg.add(results, 8)
        root.add(reg, 8)

        // ---------- DATA ----------
        root.add(section("DATA"), 20)
        val data = card()
        data.add(button("Hapus hasil uji", false) {
            results.removeAllViews()
            logs.setLength(0)
            status.text = "Hasil uji dihapus."
        }, 0)
        root.add(data, 8)

        // ---------- RIWAYAT ----------
        root.add(section("RIWAYAT JUDUL TERAKHIR"), 20)
        val hist = card()
        historyBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        hist.add(historyBox, 0)
        root.add(hist, 8)
        renderHistory()

        // ---------- TAMPILAN ----------
        root.add(section("TAMPILAN"), 20)
        val scaleCard = card()
        scaleLabel = TextView(this).apply {
            text = "Ukuran teks saat ini: ${scaleName(Ui.scaleValue(this@GearActivity))}"
            textSize = 13f
            setTextColor(pal.muted)
        }
        scaleCard.add(scaleLabel, 0)
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("Kecil" to 0.9f, "Sedang" to 1.0f, "Besar" to 1.2f).forEachIndexed { i, pair ->
            val name = pair.first
            val factor = pair.second
            row.addView(button(name, false) {
                p.edit().putString("scale", factor.toString()).apply()
                Ui.applyScale(root, factor)
                scaleLabel.text = "Ukuran teks saat ini: $name"
            }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                if (i > 0) leftMargin = px(4)
            })
        }
        scaleCard.add(row, 8)
        root.add(scaleCard, 8)

        // ---------- TENTANG ----------
        root.add(section("TENTANG"), 20)
        val about = card()
        about.add(TextView(this).apply {
            text = "MDLvia versi ${appVersion()}"
            textSize = 15f
            setTextColor(pal.text)
            typeface = Typeface.DEFAULT_BOLD
        }, 0)
        about.add(TextView(this).apply {
            text = "Membuka halaman judul MyDramaList langsung di Nuvio."
            textSize = 13f
            setTextColor(pal.muted)
        }, 4)
        about.add(button("Buka repo proyek", false) {
            try {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://github.com/elightpro/NuvioBridge")))
            } catch (e: ActivityNotFoundException) {
                toast("Tidak ada browser")
            }
        }, 8)
        root.add(about, 8)

        // ---------- RESET ----------
        root.add(button("Reset pengaturan", false) { confirmReset() }.apply {
            background = Ui.rounded(this@GearActivity, Ui.COLOR_BAD, 10)
            setTextColor(Color.WHITE)
        }, 28)

        setContentView(ScrollView(this).apply {
            setBackgroundColor(pal.bg)
            addView(root, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        })
        Ui.applyScale(root, Ui.scaleValue(this))
    }

    private fun confirmReset() {
        AlertDialog.Builder(this)
            .setTitle("Reset pengaturan?")
            .setMessage("API key dan template deep link akan dihapus dari HP ini. Tindakan ini tidak dapat dibatalkan.")
            .setPositiveButton("Ya, reset") { _, _ ->
                getSharedPreferences(Ui.PREFS, MODE_PRIVATE).edit()
                    .remove("key")
                    .putString("tpl", Deeplink.DEFAULT)
                    .apply()
                toast("Pengaturan direset. Kembali ke layar utama untuk melihat.")
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun renderHistory() {
        historyBox.removeAllViews()
        val items = Ui.history(this)
        if (items.isEmpty()) {
            historyBox.addView(TextView(this).apply {
                text = "Belum ada judul yang dibuka."
                textSize = 13f
                setTextColor(pal.muted)
            })
        } else {
            for (line in items) {
                val parts = line.split("|", limit = 2)
                val stamp = parts.getOrElse(0) { "" }
                val title = parts.getOrElse(1) { line }
                historyBox.addView(TextView(this).apply {
                    text = "$title\n$stamp"
                    textSize = 14f
                    setTextColor(pal.text)
                    setPadding(0, px(6), 0, px(6))
                })
            }
        }
        Ui.applyScale(historyBox, Ui.scaleValue(this))
    }

    private fun runRegression() {
        val p = getSharedPreferences(Ui.PREFS, MODE_PRIVATE)
        val key = (p.getString("key", "") ?: "").trim()
        val tpl = (p.getString("tpl", "") ?: "").trim().ifBlank { Deeplink.DEFAULT }
        if (key.isEmpty()) { toast("Isi TMDB API key di layar utama dulu"); return }
        val total = RegressionCases.ALL.size
        results.removeAllViews()
        logs.setLength(0)
        bar.visibility = View.VISIBLE
        status.text = "Menjalankan uji 1 dari $total: ${RegressionCases.ALL[0].name}..."
        Thread {
            val tmdb = Tmdb(key)
            RegressionCases.ALL.forEachIndexed { i, rc ->
                runOnUiThread { status.text = "Menjalankan uji ${i + 1} dari $total: ${rc.name}..." }
                val log = mutableListOf<String>()
                val report = try {
                    Resolver(tmdb, PageFetcher(this)).resolve(rc.url, log)
                } catch (e: Exception) {
                    Report(null, Decision.Fail("Exception: $e"), log)
                }
                val text = RegressionCases.render(rc, report, tmdb, tpl)
                logs.append(text).append("\n\n")
                runOnUiThread {
                    val card = caseCard(text)
                    Ui.applyScale(card, Ui.scaleValue(this))
                    Ui.addTop(results, card, 8)
                    status.text = "Selesai ${i + 1} dari $total"
                }
            }
            runOnUiThread {
                bar.visibility = View.GONE
                status.text = "Selesai. Tekan \"Salin log lengkap\" untuk menyalin semua."
            }
        }.start()
    }

    /** Kartu hasil per kasus. Verdict dan ringkasan diambil dari teks hasil (logika tidak berubah). */
    private fun caseCard(full: String): View {
        val lines = full.lines()
        val name = lines.firstOrNull { it.startsWith("== ") }?.removePrefix("== ")?.removeSuffix(" ==") ?: "Uji"
        val raw = lines.firstOrNull { it.startsWith("HASIL: ") }?.removePrefix("HASIL: ") ?: "?"
        val (badge, color) = when {
            raw.startsWith("PASS") -> "PASS" to Ui.COLOR_OK
            raw.startsWith("FAIL") -> "FAIL" to Ui.COLOR_BAD
            raw.startsWith("AMBIGU") -> "AMBIGU" to Ui.COLOR_WARN
            else -> "MANUAL" to Ui.COLOR_WARN
        }
        val summary = lines.filter {
            it.startsWith("MDL: ") || it.startsWith("KEPUTUSAN: ") || it.startsWith("LINK: ")
        }

        val c = card()
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        head.addView(TextView(this).apply {
            text = name
            textSize = 15f
            setTextColor(pal.text)
            typeface = Typeface.DEFAULT_BOLD
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        head.addView(TextView(this).apply {
            text = badge
            textSize = 12f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(px(8), px(3), px(8), px(3))
            background = Ui.rounded(this@GearActivity, color, 6)
        })
        c.add(head, 0)
        c.add(TextView(this).apply {
            text = summary.joinToString("\n")
            textSize = 13f
            setTextColor(pal.text)
        }, 8)
        val details = TextView(this).apply {
            text = full
            typeface = Typeface.MONOSPACE
            textSize = 11f
            setTextColor(pal.muted)
            setTextIsSelectable(true)
            visibility = View.GONE
        }
        c.add(details, 8)
        c.add(button("Lihat log", false) {
            details.visibility = if (details.visibility == View.GONE) View.VISIBLE else View.GONE
        }, 8)
        return c
    }

    private fun scaleName(v: Float) = when {
        v < 0.95f -> "Kecil"
        v > 1.1f -> "Besar"
        else -> "Sedang"
    }

    private fun appVersion(): String = try {
        packageManager.getPackageInfo(packageName, 0).versionName ?: ""
    } catch (e: Exception) {
        ""
    }

    // ---------- helper ----------
    private fun px(n: Int) = Ui.px(this, n)
    private fun card() = Ui.card(this, pal)
    private fun section(t: String) = Ui.section(this, pal, t)
    private fun button(caption: String, primary: Boolean, onClick: () -> Unit) =
        Ui.button(this, pal, caption, primary, onClick)
    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()
    private fun LinearLayout.add(v: View, topDp: Int = 8) = Ui.addTop(this, v, topDp)
}
