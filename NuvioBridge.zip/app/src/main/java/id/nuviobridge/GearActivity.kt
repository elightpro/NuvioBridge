package id.nuviobridge

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.text.Editable
import android.text.InputType
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*

class GearActivity : Activity() {

    private lateinit var pal: Pal
    private lateinit var root: LinearLayout
    private lateinit var devSection: LinearLayout
    private lateinit var bar: ProgressBar
    private lateinit var status: TextView
    private lateinit var results: LinearLayout
    private lateinit var actionsBox: LinearLayout
    private lateinit var scaleBox: LinearLayout
    private val logs = StringBuilder()
    private val scaleFactors = listOf(0.9f, 1.0f, 1.2f)

    /** Editor template: kolom, status, dan tombol Simpan yang aktif hanya saat berubah. */
    private inner class TemplateEditor(
        val prefKey: String,
        val defaultValue: String,
        val placeholderNote: String,
        val validate: (String) -> String?,
        val needsConfirm: (String) -> String?
    ) {
        lateinit var field: EditText
        lateinit var status: TextView
        lateinit var error: TextView
        lateinit var saveBtn: Button
        lateinit var defaultBtn: Button

        fun saved(): String = getSharedPreferences(Ui.PREFS, MODE_PRIVATE).getString(prefKey, null)
            ?.takeIf { it.isNotBlank() } ?: defaultValue

        fun stored(): Boolean = getSharedPreferences(Ui.PREFS, MODE_PRIVATE).getString(prefKey, "")?.isNotBlank() == true

        fun refresh() {
            val dirty = field.text.toString().trim() != saved()
            status.text = when {
                dirty -> "Belum Disimpan"
                stored() -> "Tersimpan"
                else -> "Default"
            }
            saveBtn.isEnabled = dirty
            saveBtn.alpha = if (dirty) 1f else 0.4f
        }

        fun store(t: String) {
            getSharedPreferences(Ui.PREFS, MODE_PRIVATE).edit().putString(prefKey, t).apply()
            error.text = ""
            refresh()
            toast("Tersimpan")
        }

        fun save() {
            val t = field.text.toString().trim()
            val err = validate(t)
            error.text = err ?: ""
            if (err != null) {
                toast(err)
                return
            }
            val warn = needsConfirm(t)
            if (warn != null) {
                Ui.dialog(this@GearActivity)
                    .setTitle("Template Tanpa Placeholder")
                    .setMessage(warn)
                    .setPositiveButton("Tetap Simpan") { _, _ -> store(t) }
                    .setNegativeButton("Batal", null)
                    .show()
            } else {
                store(t)
            }
        }

        fun useDefault() {
            field.setText(defaultValue)
            error.text = ""
            refresh()
        }

        /** Susun kartu: label, kolom, catatan, dan dua tombol satu baris. */
        fun card(label: String): LinearLayout {
            val c = card()
            status = TextView(this@GearActivity).apply { textSize = 12f; setTextColor(pal.muted) }
            c.add(Ui.labelRow(this@GearActivity, pal, label, status), 0)
            field = EditText(this@GearActivity).apply {
                setText(saved())
                setTextColor(pal.text)
                inputType = InputType.TYPE_TEXT_FLAG_MULTI_LINE
                minLines = 1
                maxLines = 3
            }
            field.addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, cnt: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, cnt: Int) {}
                override fun afterTextChanged(s: Editable?) { refresh() }
            })
            c.add(field, 4)
            error = TextView(this@GearActivity).apply { textSize = 12f; setTextColor(Ui.COLOR_BAD) }
            c.add(error, 4)
            c.add(note(placeholderNote), 6)
            val row = LinearLayout(this@GearActivity).apply { orientation = LinearLayout.HORIZONTAL }
            defaultBtn = button("Pakai Default", false) { useDefault() }
            saveBtn = button("Simpan", true) { save() }
            row.addView(defaultBtn, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { rightMargin = px(4) })
            row.addView(saveBtn, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { leftMargin = px(4) })
            c.add(row, 10)
            refresh()
            return c
        }
    }

    private lateinit var nuvioEditor: TemplateEditor
    private lateinit var googleEditor: TemplateEditor

    private fun hasPlaceholder(t: String) =
        listOf("{type}", "{imdb}", "{tmdb}", "{tmdbtype}").any { t.contains(it) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        pal = Ui.pal(this)
        val p = getSharedPreferences(Ui.PREFS, MODE_PRIVATE)

        nuvioEditor = TemplateEditor(
            prefKey = "tpl",
            defaultValue = Deeplink.DEFAULT,
            placeholderNote = "Placeholder: {type} {imdb} {tmdb} {tmdbtype}",
            validate = { t -> if (t.isEmpty()) "Template tidak boleh kosong" else null },
            needsConfirm = { t -> if (!hasPlaceholder(t)) "Template tidak memiliki placeholder, sehingga link yang dibuat tidak akan benar. Tetap simpan?" else null }
        )
        googleEditor = TemplateEditor(
            prefKey = "gtpl",
            defaultValue = Ui.DEFAULT_GTPL,
            placeholderNote = "Placeholder: {query} {title} {year} {type} {country} {tmdbId}",
            validate = { t -> if (t.isEmpty()) "Template tidak boleh kosong" else null },
            needsConfirm = { _ -> null }
        )

        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(px(16), px(20), px(16), px(24))
            setBackgroundColor(pal.bg)
        }

        devSection = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
        }

        // Judul: tap 5 kali untuk membuka mode pengembang
        var taps = 0
        val title = TextView(this).apply {
            text = "Pengaturan Lanjutan"
            textSize = 22f
            setTextColor(pal.text)
            typeface = Typeface.DEFAULT_BOLD
        }
        title.setOnClickListener {
            taps++
            if (taps >= 5 && devSection.visibility == View.GONE) {
                devSection.visibility = View.VISIBLE
                toast("Mode pengembang aktif")
            }
        }
        root.addView(title)
        root.addView(note("Konfigurasi dan aksi share."))

        // ---------- KONFIGURASI DEFAULT (paling atas, tertutup) ----------
        val defaults = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        defaults.add(nuvioEditor.card("Template Nuvio"), 0)
        defaults.add(googleEditor.card("Template Google"), 8)
        root.add(Ui.collapsible(this, pal, "KONFIGURASI DEFAULT", false, defaults), 0)

        // ---------- OPEN IN ACTIONS (terbuka) ----------
        val acard = card()
        acard.add(note("Aksi aktif muncul di mode All Actions."), 0)
        actionsBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        acard.add(actionsBox, 8)
        acard.add(button("Buat Aksi Baru", true) { addAction() }, 10)
        root.add(Ui.collapsible(this, pal, "OPEN IN ACTIONS", true, acard), 0)
        renderActions()

        // ---------- UJI COBA LINK (di bawah Open In Actions) ----------
        val seriesEx = "https://mydramalist.com/735043-life"
        val filmEx = "https://mydramalist.com/755475-godzilla-minus-one"
        val tes = card()
        val test = EditText(this).apply {
            hint = "tempel link MyDramaList"
            setHintTextColor(pal.muted)
            setTextColor(pal.text)
            setSingleLine()
        }
        val exRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        exRow.addView(button("Pakai Contoh Series", false) { test.setText(seriesEx) },
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { rightMargin = px(4) })
        exRow.addView(button("Pakai Contoh Movie", false) { test.setText(filmEx) },
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { leftMargin = px(4) })
        tes.add(exRow, 0)
        tes.add(test, 8)
        tes.add(button("Uji Coba Link", true) {
            startActivity(Intent(this, ShareActivity::class.java).apply {
                action = Intent.ACTION_SEND
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, test.text.toString())
            })
        }, 8)
        root.add(Ui.collapsible(this, pal, "TES LINK MDL", true, tes), 0)

        // ---------- PERILAKU (tertutup) ----------
        val pcard = card()
        val prow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        prow.addView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(TextView(this@GearActivity).apply {
                text = "Pertahankan Dialog Aksi"
                textSize = 15f
                setTextColor(pal.text)
                typeface = Typeface.DEFAULT_BOLD
            })
            addView(note("Dialog muncul lagi sekali saat kembali ke MDLvia."))
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        prow.addView(Switch(this).apply {
            isChecked = p.getBoolean("keep_sheet", true)
            setOnCheckedChangeListener { _, on -> p.edit().putBoolean("keep_sheet", on).apply() }
        })
        pcard.add(prow, 0)
        root.add(Ui.collapsible(this, pal, "PERILAKU", false, pcard), 0)

        // ---------- TAMPILAN (tertutup) ----------
        val scard = card()
        scard.add(note("Ukuran Teks"), 0)
        scaleBox = Ui.segmentRow(this, pal, listOf("Kecil", "Sedang", "Besar"), { scaleIndex() }) { i ->
            val f = scaleFactors[i]
            p.edit().putString("scale", f.toString()).apply()
            Ui.applyScale(root, f)
        }
        scard.add(scaleBox, 8)
        root.add(Ui.collapsible(this, pal, "TAMPILAN", false, scard), 0)

        // ---------- MODE PENGEMBANGAN (tersembunyi, tertutup saat dibuka) ----------
        val devInner = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        devInner.addView(note("Hanya untuk pengujian. Tidak mengubah pengaturan."))

        val devTes = card()
        devTes.add(LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(button("Tes Series", false) { openNuvio(MainActivity.SERIES_TEST) },
                LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { rightMargin = px(4) })
            addView(button("Tes Movie", false) { openNuvio(MainActivity.MOVIE_TEST) },
                LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { leftMargin = px(4) })
        }, 0)
        devInner.add(Ui.collapsible(this, pal, "TES CEPAT NUVIO", false, devTes), 8)

        val cacheCard = card()
        cacheCard.add(note("Hasil judul yang disimpan. Hapus kalau ada hasil yang salah."), 0)
        cacheCard.add(button("Hapus Cache", false) {
            DecisionCache.clear(this)
            toast("Cache dihapus")
        }, 8)
        devInner.add(Ui.collapsible(this, pal, "CACHE", false, cacheCard), 8)

        val reg = card()
        bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            isIndeterminate = true
            indeterminateTintList = android.content.res.ColorStateList.valueOf(pal.primary)
            visibility = View.GONE
        }
        status = TextView(this).apply {
            text = "Belum dijalankan."
            textSize = 13f
            setTextColor(pal.muted)
        }
        results = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        reg.add(button("Jalankan 3 Uji Regresi", true) { runRegression() }, 0)
        reg.add(bar, 8)
        reg.add(status, 8)
        reg.add(button("Salin Log Lengkap", false) {
            if (logs.isEmpty()) { toast("Belum ada hasil"); return@button }
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("hasil", logs.toString()))
            toast("Disalin")
        }, 8)
        reg.add(button("Hapus Hasil", false) {
            results.removeAllViews()
            logs.setLength(0)
            status.text = "Hasil dihapus."
        }, 8)
        reg.add(results, 8)
        devInner.add(Ui.collapsible(this, pal, "UJI REGRESI", false, reg), 8)

        devSection.add(Ui.collapsible(this, pal, "MODE PENGEMBANGAN", false, devInner), 24)
        root.add(devSection, 8)

        // ---------- RESET (berbahaya, huruf kapital semua) ----------
        root.add(Ui.dangerButton(this, "RESET PENGATURAN") { confirmReset() }, 28)

        setContentView(ScrollView(this).apply {
            setBackgroundColor(pal.bg)
            addView(root, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        })
        Ui.applyScale(root, Ui.scaleValue(this))
    }

    override fun onResume() {
        super.onResume()
        if (::actionsBox.isInitialized) renderActions()
        if (::nuvioEditor.isInitialized) {
            nuvioEditor.refresh()
            googleEditor.refresh()
        }
    }

    private fun scaleIndex(): Int {
        val v = Ui.scaleValue(this)
        return when {
            v < 0.95f -> 0
            v > 1.1f -> 2
            else -> 1
        }
    }

    // ---------- AKSI ----------

    private fun renderActions() {
        actionsBox.removeAllViews()
        val list = Actions.load(this)
        list.forEachIndexed { i, a ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, px(8), 0, px(8))
            }
            row.addView(Ui.iconButton(this, pal, a.icon) {
                Ui.iconPicker(this, pal, a.icon) { picked ->
                    updateAction(a.id) { it.copy(icon = picked) }
                    renderActions()
                }.show()
            }, LinearLayout.LayoutParams(px(40), px(40)).apply { rightMargin = px(10) })
            val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            info.addView(TextView(this).apply {
                text = a.name
                textSize = 15f
                setTextColor(pal.text)
                typeface = Typeface.DEFAULT_BOLD
            })
            info.addView(TextView(this).apply {
                text = if (a.builtin != null) "Default" else a.template
                textSize = 11f
                setTextColor(pal.muted)
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
            })
            row.addView(info, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(Switch(this).apply {
                isChecked = a.enabled
                setOnCheckedChangeListener { _, on -> updateAction(a.id) { it.copy(enabled = on) } }
            })
            if (i > 0) row.addView(Ui.chevronButton(this, pal, true) { moveAction(i, -1) }, chevParams())
            if (i < list.size - 1) row.addView(Ui.chevronButton(this, pal, false) { moveAction(i, 1) }, chevParams())
            if (a.builtin == null) {
                row.addView(Ui.miniButton(this, pal, "✎") {
                    startActivity(Intent(this, ActionEditActivity::class.java).apply { putExtra("id", a.id) })
                }, chevParams())
            }
            actionsBox.addView(row)
            if (i < list.size - 1) {
                actionsBox.addView(View(this), LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, px(1)))
            }
        }
        Ui.applyScale(actionsBox, Ui.scaleValue(this))
    }

    private fun chevParams() = LinearLayout.LayoutParams(px(36), px(36)).apply { leftMargin = px(4) }

    private fun updateAction(id: String, f: (Action) -> Action) {
        val list = Actions.load(this)
        val idx = list.indexOfFirst { it.id == id }
        if (idx >= 0) {
            list[idx] = f(list[idx])
            Actions.save(this, list)
        }
    }

    private fun moveAction(index: Int, delta: Int) {
        val list = Actions.load(this)
        val target = index + delta
        if (index !in list.indices || target !in list.indices) return
        val tmp = list[index]
        list[index] = list[target]
        list[target] = tmp
        Actions.save(this, list)
        renderActions()
    }

    private fun addAction() {
        if (Actions.customCount(Actions.load(this)) >= Actions.MAX_CUSTOM) {
            toast("Maksimal ${Actions.MAX_CUSTOM} aksi custom")
            return
        }
        startActivity(Intent(this, ActionEditActivity::class.java))
    }

    // ---------- RESET ----------

    private fun confirmReset() {
        Ui.dialog(this)
            .setTitle("Reset Pengaturan?")
            .setMessage("API key, template, aksi, dan mode akan dikembalikan ke default. Tindakan ini tidak dapat dibatalkan.")
            .setPositiveButton("Ya, Reset") { _, _ ->
                getSharedPreferences(Ui.PREFS, MODE_PRIVATE).edit()
                    .remove("key")
                    .putString("tpl", Deeplink.DEFAULT)
                    .putString("gtpl", Ui.DEFAULT_GTPL)
                    .putString("mode", "both")
                    .putBoolean("keep_sheet", true)
                    .apply()
                Actions.reset(this)
                nuvioEditor.useDefault()
                googleEditor.useDefault()
                renderActions()
                toast("Pengaturan direset. Kembali ke layar utama untuk melihat.")
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    // ---------- TES & UJI ----------

    private fun openNuvio(link: String) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(link)))
        } catch (e: ActivityNotFoundException) {
            toast("Nuvio tidak terpasang")
        }
    }

    private fun runRegression() {
        val p = getSharedPreferences(Ui.PREFS, MODE_PRIVATE)
        val key = (p.getString("key", "") ?: "").trim()
        val tpl = (p.getString("tpl", "") ?: "").trim().ifBlank { Deeplink.DEFAULT }
        if (key.isEmpty()) { toast("Isi TMDB API Key di layar utama dulu"); return }
        val total = RegressionCases.ALL.size
        results.removeAllViews()
        logs.setLength(0)
        bar.visibility = View.VISIBLE
        status.text = "Menjalankan uji 1 dari $total: ${RegressionCases.ALL[0].name}..."
        Thread {
            val tmdb = Tmdb(key)
            RegressionCases.ALL.forEachIndexed { i, rc ->
                runOnUiThread { status.text = "Menjalankan uji ${i + 1} dari $total: ${rc.name}..." }
                val log = mutableListOf<String>()
                val report = try {
                    Resolver(tmdb, PageFetcher(this)).resolve(rc.url, log)
                } catch (e: Exception) {
                    Report(null, Decision.Fail("Exception: $e"), log)
                }
                val text = RegressionCases.render(rc, report, tmdb, tpl)
                logs.append(text).append("\n\n")
                runOnUiThread {
                    val card = caseCard(text)
                    Ui.applyScale(card, Ui.scaleValue(this))
                    Ui.addTop(results, card, 8)
                    status.text = "Selesai ${i + 1} dari $total"
                }
            }
            runOnUiThread {
                bar.visibility = View.GONE
                status.text = "Selesai. Salin log untuk menyalin semua."
            }
        }.start()
    }

    /** Kartu hasil per kasus. Verdict dan ringkasan diambil dari teks hasil (logika tidak berubah). */
    private fun caseCard(full: String): View {
        val lines = full.lines()
        val name = lines.firstOrNull { it.startsWith("== ") }?.removePrefix("== ")?.removeSuffix(" ==") ?: "Uji"
        val raw = lines.firstOrNull { it.startsWith("HASIL: ") }?.removePrefix("HASIL: ") ?: "?"
        val (badge, color) = when {
            raw.startsWith("PASS") -> "PASS" to Ui.COLOR_OK
            raw.startsWith("FAIL") -> "FAIL" to Ui.COLOR_BAD
            raw.startsWith("AMBIGU") -> "AMBIGU" to Ui.COLOR_WARN
            else -> "MANUAL" to Ui.COLOR_WARN
        }
        val summary = lines.filter {
            it.startsWith("MDL: ") || it.startsWith("KEPUTUSAN: ") || it.startsWith("LINK: ")
        }

        val c = card()
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        head.addView(TextView(this).apply {
            text = name
            textSize = 15f
            setTextColor(pal.text)
            typeface = Typeface.DEFAULT_BOLD
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        head.addView(TextView(this).apply {
            text = badge
            textSize = 12f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(px(8), px(3), px(8), px(3))
            background = Ui.rounded(this@GearActivity, color, 6)
        })
        c.add(head, 0)
        c.add(TextView(this).apply {
            text = summary.joinToString("\n")
            textSize = 13f
            setTextColor(pal.text)
        }, 8)
        val details = TextView(this).apply {
            text = full
            typeface = Typeface.MONOSPACE
            textSize = 11f
            setTextColor(pal.muted)
            setTextIsSelectable(true)
            visibility = View.GONE
        }
        c.add(details, 8)
        c.add(button("Lihat Log", false) {
            details.visibility = if (details.visibility == View.GONE) View.VISIBLE else View.GONE
        }, 8)
        return c
    }

    // ---------- helper ----------
    private fun px(n: Int) = Ui.px(this, n)
    private fun card() = Ui.card(this, pal)
    private fun note(t: String) = TextView(this).apply {
        text = t
        textSize = 12f
        setTextColor(pal.muted)
    }
    private fun button(caption: String, primary: Boolean, onClick: () -> Unit) =
        Ui.button(this, pal, caption, primary, onClick)
    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()
    private fun LinearLayout.add(v: View, topDp: Int = 8) = Ui.addTop(this, v, topDp)
}
