package id.nuviobridge

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.text.InputType
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val p = getSharedPreferences("cfg", MODE_PRIVATE)
        val pad = (16 * resources.displayMetrics.density).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        fun label(t: String) = TextView(this).apply { text = t; setPadding(0, pad, 0, 0) }

        val key = EditText(this).apply {
            hint = "TMDB API key (v3) atau token v4"
            setText(p.getString("key", ""))
            setSingleLine()
        }
        val tpl = EditText(this).apply {
            hint = "contoh: nuvio://....{tmdb}"
            setText(p.getString("tpl", ""))
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
        }
        val info = TextView(this).apply {
            text = "Placeholder: {tmdb} ID TMDB, {imdb} ID IMDb (ttXXXX), " +
                "{type} movie/series, {tmdbtype} movie/tv.\n" +
                "Ambil deep link Nuvio yang sudah jalan, ganti ID-nya dengan placeholder."
        }
        val save = Button(this).apply {
            text = "Simpan"
            setOnClickListener {
                p.edit().putString("key", key.text.toString().trim())
                    .putString("tpl", tpl.text.toString().trim()).apply()
                Toast.makeText(context, "Tersimpan", Toast.LENGTH_SHORT).show()
            }
        }
        val test = EditText(this).apply {
            hint = "tempel link MDL / MDBList / IMDb untuk tes"
            setSingleLine()
        }
        val testBtn = Button(this).apply {
            text = "Tes"
            setOnClickListener {
                save.performClick()
                startActivity(Intent(context, ShareActivity::class.java).apply {
                    action = Intent.ACTION_SEND
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, test.text.toString())
                })
            }
        }

        root.addView(label("TMDB API key (untuk link MDL)"))
        root.addView(key)
        root.addView(label("Template deep link Nuvio"))
        root.addView(tpl)
        root.addView(info)
        root.addView(save)
        root.addView(label("Tes"))
        root.addView(test)
        root.addView(testBtn)

        setContentView(ScrollView(this).apply {
            addView(root, ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        })
    }
}
