package id.nuviobridge

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {

    private lateinit var out: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val p = getSharedPreferences("cfg", MODE_PRIVATE)
        val pad = (16 * resources.displayMetrics.density).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        fun label(t: String) = TextView(this).apply { text = t; setPadding(0, pad, 0, 0) }

        val key = EditText(this).apply {
            hint = "TMDB API key (v3) atau token v4"
            setText(p.getString("key", ""))
            setSingleLine()
        }
        val tpl = EditText(this).apply {
            setText((p.getString("tpl", "") ?: "").ifBlank { Deeplink.DEFAULT })
            setSingleLine()
        }
        val info = TextView(this).apply {
            text = "Placeholder: {type} movie/series, {imdb} ID IMDb, {tmdb} ID TMDB, {tmdbtype} movie/tv.\n" +
                "Aplikasi hanya menerima link MyDramaList."
        }
        fun saveAll() {
            p.edit().putString("key", key.text.toString().trim())
                .putString("tpl", tpl.text.toString().trim()).apply()
        }
        val save = Button(this).apply {
            text = "Simpan"
            setOnClickListener { saveAll(); Toast.makeText(context, "Tersimpan", Toast.LENGTH_SHORT).show() }
        }
        val test = EditText(this).apply { hint = "tempel link MyDramaList untuk tes"; setSingleLine() }
        val testBtn = Button(this).apply {
            text = "Tes (buka Nuvio)"
            setOnClickListener {
                saveAll()
                startActivity(Intent(context, ShareActivity::class.java).apply {
                    action = Intent.ACTION_SEND
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, test.text.toString())
                })
            }
        }
        val regBtn = Button(this).apply {
            text = "Uji regresi (3 URL MDL, tidak membuka Nuvio)"
            setOnClickListener { saveAll(); runRegression(key.text.toString().trim(), tpl.text.toString().trim()) }
        }
        val copyBtn = Button(this).apply {
            text = "Salin hasil"
            setOnClickListener {
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("hasil", out.text))
                Toast.makeText(context, "Disalin", Toast.LENGTH_SHORT).show()
            }
        }
        out = TextView(this).apply {
            typeface = Typeface.MONOSPACE
            textSize = 11f
            setTextIsSelectable(true)
        }

        root.addView(label("TMDB API key"))
        root.addView(key)
        root.addView(label("Template deep link Nuvio"))
        root.addView(tpl)
        root.addView(info)
        root.addView(save)
        root.addView(label("Tes satu link"))
        root.addView(test)
        root.addView(testBtn)
        root.addView(label("Regresi"))
        root.addView(regBtn)
        root.addView(copyBtn)
        root.addView(out)

        setContentView(ScrollView(this).apply {
            addView(root, ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        })
    }

    private fun runRegression(key: String, tpl: String) {
        if (key.isEmpty()) { Toast.makeText(this, "Isi TMDB API key dulu", Toast.LENGTH_SHORT).show(); return }
        val template = tpl.ifBlank { Deeplink.DEFAULT }
        out.text = "Menjalankan 3 kasus... (bisa 30-90 detik)\n"
        Thread {
            val sb = StringBuilder()
            val tmdb = Tmdb(key)
            for (rc in RegressionCases.ALL) {
                val log = mutableListOf<String>()
                val report = try {
                    Resolver(tmdb, PageFetcher(this)).resolve(rc.url, log)
                } catch (e: Exception) {
                    Report(null, Decision.Fail("Exception: $e"), log)
                }
                sb.append(RegressionCases.render(rc, report, tmdb, template)).append("\n\n")
                val partial = sb.toString()
                runOnUiThread { out.text = partial }
            }
            val all = sb.toString() + "SELESAI"
            runOnUiThread { out.text = all }
        }.start()
    }
}
