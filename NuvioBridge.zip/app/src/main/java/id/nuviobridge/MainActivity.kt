package id.nuviobridge

import android.app.Activity
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.text.method.HideReturnsTransformationMethod
import android.text.method.PasswordTransformationMethod
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {

    private lateinit var pal: Pal
    private lateinit var root: LinearLayout
    private lateinit var key: EditText
    private lateinit var tpl: EditText
    private lateinit var keyStatus: TextView
    private lateinit var tplStatus: TextView
    private val modeButtons = LinkedHashMap<String, Button>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        pal = Ui.pal(this)

        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(px(16), px(20), px(16), px(24))
            setBackgroundColor(pal.bg)
        }

        // ---------- HEADER: judul + ikon gear ----------
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        header.addView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(TextView(this@MainActivity).apply {
                text = "MDLvia"
                textSize = 24f
                setTextColor(pal.text)
                typeface = Typeface.DEFAULT_BOLD
            })
            addView(TextView(this@MainActivity).apply {
                text = "Buka judul MDL di Nuvio atau Google."
                textSize = 14f
                setTextColor(pal.muted)
            })
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val gear = gearIcon().apply { background = Ui.rounded(this@MainActivity, pal.card, 10) }
        gear.setOnClickListener { startActivity(Intent(this, GearActivity::class.java)) }
        header.addView(gear, LinearLayout.LayoutParams(px(44), px(44)))
        root.add(header, 0)

        // ---------- PENGATURAN ----------
        root.add(section("PENGATURAN"), 20)
        val settings = card()

        key = EditText(this).apply {
            hint = "Masukkan TMDB API key (v3) atau token (v4)"
            setHintTextColor(pal.muted)
            setTextColor(pal.text)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            transformationMethod = PasswordTransformationMethod.getInstance()
        }
        var keyVisible = false
        val toggle = button("Tampilkan kunci", false) {}
        toggle.setOnClickListener {
            keyVisible = !keyVisible
            key.transformationMethod = if (keyVisible) HideReturnsTransformationMethod.getInstance()
                                       else PasswordTransformationMethod.getInstance()
            toggle.text = if (keyVisible) "Sembunyikan kunci" else "Tampilkan kunci"
            key.setSelection(key.text.length)
        }

        tpl = EditText(this).apply {
            setTextColor(pal.text)
            setSingleLine()
        }
        keyStatus = TextView(this).apply { textSize = 12f; setTextColor(pal.muted) }
        tplStatus = TextView(this).apply { textSize = 12f; setTextColor(pal.muted) }

        settings.add(label("TMDB API key"), 0)
        settings.add(key, 4)
        settings.add(toggle, 4)
        settings.add(keyStatus, 4)
        settings.add(label("Template deep link Nuvio"), 12)
        settings.add(tpl, 4)
        settings.add(tplStatus, 4)
        settings.add(note("Placeholder: {type} {imdb} {tmdb} {tmdbtype}"), 6)
        settings.add(button("Pakai template standar", false) {
            tpl.setText(Deeplink.DEFAULT)
        }, 8)
        settings.add(button("Simpan", true) {
            val t = tpl.text.toString().trim()
            if (!hasPlaceholder(t)) {
                AlertDialog.Builder(this)
                    .setTitle("Template tanpa placeholder")
                    .setMessage("Template tidak memiliki placeholder, sehingga link yang dibuat tidak akan benar. Tetap simpan?")
                    .setPositiveButton("Tetap simpan") { _, _ -> saveAll(); toast("Tersimpan") }
                    .setNegativeButton("Batal", null)
                    .show()
            } else {
                saveAll()
                toast("Tersimpan")
            }
        }, 12)
        root.add(settings, 8)

        // ---------- TUJUAN SAAT SHARE ----------
        root.add(section("TUJUAN SAAT SHARE"), 20)
        val modeCard = card()
        modeCard.add(note("Pilih tujuan saat share dari MDL."), 0)
        for ((i, pair) in listOf("nuvio" to "Nuvio", "google" to "Google", "both" to "All Actions").withIndex()) {
            val b = button(pair.second, false) { setMode(pair.first) }
            modeButtons[pair.first] = b
            modeCard.add(b, if (i == 0) 8 else 6)
        }
        root.add(modeCard, 8)

        root.add(TextView(this).apply {
            text = "Versi ${appVersion()}"
            textSize = 12f
            setTextColor(pal.muted)
            gravity = Gravity.CENTER
        }, 24)

        setContentView(ScrollView(this).apply {
            setBackgroundColor(pal.bg)
            addView(root, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        })
        reloadFields()
        Ui.applyScale(root, Ui.scaleValue(this))
    }

    override fun onResume() {
        super.onResume()
        if (::root.isInitialized) {
            reloadFields()
            Ui.applyScale(root, Ui.scaleValue(this))
        }
    }

    /** Muat ulang dari penyimpanan, misalnya setelah kembali dari halaman gear. */
    private fun reloadFields() {
        val p = getSharedPreferences(Ui.PREFS, MODE_PRIVATE)
        key.setText(p.getString("key", ""))
        tpl.setText((p.getString("tpl", "") ?: "").ifBlank { Deeplink.DEFAULT })
        refreshKeyStatus()
        refreshTplStatus()
        refreshModes()
    }

    private fun saveAll() {
        getSharedPreferences(Ui.PREFS, MODE_PRIVATE).edit()
            .putString("key", key.text.toString().trim())
            .putString("tpl", tpl.text.toString().trim())
            .apply()
        refreshKeyStatus()
        refreshTplStatus()
    }

    private fun setMode(value: String) {
        getSharedPreferences(Ui.PREFS, MODE_PRIVATE).edit().putString("mode", value).apply()
        refreshModes()
    }

    private fun refreshModes() {
        val cur = Ui.mode(this)
        for ((value, b) in modeButtons) {
            val on = value == cur
            b.text = (if (on) "✓ " else "") + modeName(value)
            b.background = Ui.rounded(this, if (on) pal.primary else pal.second, 10)
            b.setTextColor(if (on) Color.WHITE else pal.text)
        }
    }

    private fun modeName(v: String) = when (v) {
        "google" -> "Google"
        "both" -> "All Actions"
        else -> "Nuvio"
    }

    private fun hasPlaceholder(t: String) =
        listOf("{type}", "{imdb}", "{tmdb}", "{tmdbtype}").any { t.contains(it) }

    private fun refreshKeyStatus() {
        val has = getSharedPreferences(Ui.PREFS, MODE_PRIVATE).getString("key", "")?.isNotBlank() == true
        keyStatus.text = if (has) "✓ API key tersimpan" else "Belum ada API key"
    }

    private fun refreshTplStatus() {
        val has = getSharedPreferences(Ui.PREFS, MODE_PRIVATE).getString("tpl", "")?.isNotBlank() == true
        tplStatus.text = if (has) "✓ Template tersimpan" else "Memakai template standar"
    }

    /** Ikon gear: roda bergigi dengan lubang di tengah, digambar langsung. */
    private fun gearIcon(): View = object : View(this) {
        private val gearPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = pal.text
            style = Paint.Style.FILL
        }
        private val holePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = pal.card
            style = Paint.Style.FILL
        }
        override fun onDraw(c: Canvas) {
            val size = Math.min(width, height).toFloat()
            val cx = width / 2f
            val cy = height / 2f
            val rOut = size * 0.42f
            val rIn = rOut * 0.80f
            val steps = 32
            val path = Path()
            for (i in 0 until steps) {
                val angle = 2 * Math.PI * i / steps - Math.PI / 2
                val r = if (i % 4 < 2) rOut else rIn
                val x = cx + r * Math.cos(angle).toFloat()
                val y = cy + r * Math.sin(angle).toFloat()
                if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            path.close()
            c.drawPath(path, gearPaint)
            c.drawCircle(cx, cy, rOut * 0.36f, holePaint)
        }
    }

    private fun appVersion(): String = try {
        packageManager.getPackageInfo(packageName, 0).versionName ?: ""
    } catch (e: Exception) {
        ""
    }

    // ---------- helper ----------
    private fun px(n: Int) = Ui.px(this, n)
    private fun card() = Ui.card(this, pal)
    private fun section(t: String) = Ui.section(this, pal, t)
    private fun label(t: String) = Ui.label(this, pal, t)
    private fun note(t: String) = TextView(this).apply {
        text = t
        textSize = 12f
        setTextColor(pal.muted)
    }
    private fun button(caption: String, primary: Boolean, onClick: () -> Unit) =
        Ui.button(this, pal, caption, primary, onClick)
    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()
    private fun LinearLayout.add(v: View, topDp: Int = 8) = Ui.addTop(this, v, topDp)

    companion object {
        const val SERIES_TEST = "nuvio://series/tt26471411"
        const val MOVIE_TEST = "nuvio://movie/tt23289160"
    }
}
