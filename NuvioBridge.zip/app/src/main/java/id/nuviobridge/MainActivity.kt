package id.nuviobridge

import android.app.Activity
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.text.method.HideReturnsTransformationMethod
import android.text.method.PasswordTransformationMethod
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {

    private data class Pal(val bg: Int, val card: Int, val text: Int, val muted: Int, val primary: Int, val second: Int)

    private var dp = 1f
    private lateinit var pal: Pal
    private lateinit var status: TextView
    private lateinit var keyStatus: TextView
    private lateinit var tplStatus: TextView
    private lateinit var bar: ProgressBar
    private lateinit var results: LinearLayout
    private val logs = StringBuilder()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        dp = resources.displayMetrics.density
        val night = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
            Configuration.UI_MODE_NIGHT_YES
        pal = if (night) Pal(
            bg = Color.parseColor("#0F1115"), card = Color.parseColor("#1A1D23"),
            text = Color.parseColor("#E8EAED"), muted = Color.parseColor("#9AA3AE"),
            primary = Color.parseColor("#2F6FD6"), second = Color.parseColor("#2A2F38")
        ) else Pal(
            bg = Color.parseColor("#F5F6F8"), card = Color.parseColor("#FFFFFF"),
            text = Color.parseColor("#1B1F24"), muted = Color.parseColor("#5F6B7A"),
            primary = Color.parseColor("#1565C0"), second = Color.parseColor("#E3E8EF")
        )

        val p = getSharedPreferences("cfg", MODE_PRIVATE)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(px(16), px(20), px(16), px(24))
            setBackgroundColor(pal.bg)
        }

        // ---------- HEADER: judul + ikon sliders ----------
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        header.addView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(TextView(this@MainActivity).apply {
                text = "MDLvia"
                textSize = 24f
                setTextColor(pal.text)
                typeface = Typeface.DEFAULT_BOLD
            })
            addView(TextView(this@MainActivity).apply {
                text = "Buka halaman judul MyDramaList langsung di Nuvio."
                textSize = 14f
                setTextColor(pal.muted)
            })
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

        // ---------- MENU (sliders), default tertutup ----------
        val menu = card()
        menu.visibility = View.GONE
        val sliders = slidersIcon().apply { background = rounded(pal.card, 10) }
        sliders.setOnClickListener {
            menu.visibility = if (menu.visibility == View.GONE) View.VISIBLE else View.GONE
        }
        header.addView(sliders, LinearLayout.LayoutParams(px(44), px(44)))
        root.add(header, 0)

        // bagian uji regresi (di paling bawah, dibuka lewat menu)
        val regSection = card()
        regSection.visibility = View.GONE
        bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            isIndeterminate = true
            visibility = View.GONE
        }
        status = TextView(this).apply {
            text = "Uji regresi belum dijalankan."
            textSize = 13f
            setTextColor(pal.muted)
        }
        results = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        root.add(section("PENGATURAN"), 20)
        val settings = card()

        val key = EditText(this).apply {
            hint = "Masukkan TMDB API key (v3) atau token (v4)"
            setHintTextColor(pal.muted)
            setText(p.getString("key", ""))
            setTextColor(pal.text)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            transformationMethod = PasswordTransformationMethod.getInstance()
        }
        var keyVisible = false
        val toggle = button("Tampilkan kunci", false) {}
        toggle.setOnClickListener {
            keyVisible = !keyVisible
            key.transformationMethod = if (keyVisible) HideReturnsTransformationMethod.getInstance()
                                       else PasswordTransformationMethod.getInstance()
            toggle.text = if (keyVisible) "Sembunyikan kunci" else "Tampilkan kunci"
            key.setSelection(key.text.length)
        }

        val tpl = EditText(this).apply {
            setText((p.getString("tpl", "") ?: "").ifBlank { Deeplink.DEFAULT })
            setTextColor(pal.text)
            setSingleLine()
        }

        fun saveAll() {
            p.edit()
                .putString("key", key.text.toString().trim())
                .putString("tpl", tpl.text.toString().trim())
                .apply()
            refreshKeyStatus()
            refreshTplStatus()
        }

        keyStatus = TextView(this).apply { textSize = 12f; setTextColor(pal.muted) }
        tplStatus = TextView(this).apply { textSize = 12f; setTextColor(pal.muted) }
        refreshKeyStatus()
        refreshTplStatus()

        settings.add(label("TMDB API key"), 0)
        settings.add(key, 4)
        settings.add(toggle, 4)
        settings.add(keyStatus, 4)
        settings.add(TextView(this).apply {
            text = "Kunci disimpan di HP ini saja, tidak dikirim ke mana pun."
            textSize = 12f
            setTextColor(pal.muted)
        }, 6)
        settings.add(label("Template deep link Nuvio"), 12)
        settings.add(tpl, 4)
        settings.add(tplStatus, 4)
        settings.add(TextView(this).apply {
            text = "Placeholder: {type} movie/series, {imdb} ID IMDb, {tmdb} ID TMDB, {tmdbtype} movie/tv."
            textSize = 12f
            setTextColor(pal.muted)
        }, 6)
        settings.add(button("Pakai template standar", false) {
            tpl.setText(Deeplink.DEFAULT)
        }, 8)
        settings.add(button("Simpan", true) {
            val t = tpl.text.toString().trim()
            if (!hasPlaceholder(t)) {
                AlertDialog.Builder(this)
                    .setTitle("Template tanpa placeholder")
                    .setMessage("Template tidak memiliki placeholder, sehingga link yang dibuat tidak akan benar. Tetap simpan?")
                    .setPositiveButton("Tetap simpan") { _, _ -> saveAll(); toast("Tersimpan") }
                    .setNegativeButton("Batal", null)
                    .show()
            } else {
                saveAll()
                toast("Tersimpan")
            }
        }, 12)
        root.add(settings, 8)

        // ---------- MENU ISI (di balik sliders) ----------
        menu.add(section("MENU"), 0)
        menu.add(button("Buka uji regresi", false) {
            regSection.visibility = if (regSection.visibility == View.GONE) View.VISIBLE else View.GONE
        }, 8)
        menu.add(button("Reset pengaturan", false) {
            AlertDialog.Builder(this)
                .setTitle("Reset pengaturan?")
                .setMessage("API key dan template deep link akan dihapus dari HP ini. Tindakan ini tidak dapat dibatalkan.")
                .setPositiveButton("Ya, reset") { _, _ ->
                    p.edit().remove("key").putString("tpl", Deeplink.DEFAULT).apply()
                    key.setText("")
                    tpl.setText(Deeplink.DEFAULT)
                    refreshKeyStatus()
                    refreshTplStatus()
                    toast("Pengaturan direset")
                }
                .setNegativeButton("Batal", null)
                .show()
        }.apply {
            background = rounded(COLOR_BAD, 10)
            setTextColor(Color.WHITE)
        }, 8)
        root.add(menu, 12)

        // ---------- TES ----------
        root.add(section("TES"), 20)
        val testCard = card()
        testCard.add(LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(button("Tes serial", true) { openNuvio(SERIES_TEST) },
                LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { rightMargin = px(4) })
            addView(button("Tes film", true) { openNuvio(MOVIE_TEST) },
                LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { leftMargin = px(4) })
        }, 0)
        val test = EditText(this).apply {
            hint = "tempel link MyDramaList"
            setHintTextColor(pal.muted)
            setTextColor(pal.text)
            setSingleLine()
        }
        testCard.add(test, 12)
        testCard.add(button("Tempel dari clipboard", false) {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val clip = cm.primaryClip
            if (clip != null && clip.itemCount > 0) {
                test.setText(clip.getItemAt(0).coerceToText(this).toString().trim())
            } else {
                toast("Clipboard kosong")
            }
        }, 8)
        testCard.add(button("Tes buka Nuvio", true) {
            saveAll()
            startActivity(Intent(this, ShareActivity::class.java).apply {
                action = Intent.ACTION_SEND
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, test.text.toString())
            })
        }, 8)
        root.add(testCard, 8)

        regSection.add(section("UJI REGRESI"), 0)
        regSection.add(button("Jalankan 3 uji regresi", true) {
            saveAll()
            runRegression(key.text.toString().trim(), tpl.text.toString().trim())
        }, 8)
        regSection.add(bar, 8)
        regSection.add(status, 8)
        regSection.add(button("Salin log lengkap", false) {
            if (logs.isEmpty()) { toast("Belum ada hasil"); return@button }
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("hasil", logs.toString()))
            toast("Disalin")
        }, 8)
        regSection.add(results, 8)
        root.add(regSection, 20)

        root.add(TextView(this).apply {
            text = "Versi ${appVersion()}"
            textSize = 12f
            setTextColor(pal.muted)
            gravity = Gravity.CENTER
        }, 24)

        setContentView(ScrollView(this).apply {
            setBackgroundColor(pal.bg)
            addView(root, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        })
    }

    private fun openNuvio(link: String) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(link)))
        } catch (e: ActivityNotFoundException) {
            toast("Nuvio tidak terpasang")
        }
    }

    private fun appVersion(): String = try {
        packageManager.getPackageInfo(packageName, 0).versionName ?: ""
    } catch (e: Exception) {
        ""
    }

    private fun hasPlaceholder(t: String) =
        listOf("{type}", "{imdb}", "{tmdb}", "{tmdbtype}").any { t.contains(it) }

    private fun refreshKeyStatus() {
        val has = getSharedPreferences("cfg", MODE_PRIVATE).getString("key", "")?.isNotBlank() == true
        keyStatus.text = if (has) "✓ API key tersimpan" else "Belum ada API key tersimpan"
    }

    private fun refreshTplStatus() {
        val has = getSharedPreferences("cfg", MODE_PRIVATE).getString("tpl", "")?.isNotBlank() == true
        tplStatus.text = if (has) "✓ Template tersimpan" else "Belum ada template tersimpan"
    }

    /** Ikon sliders: tiga garis dengan simpul, digambar langsung. */
    private fun slidersIcon(): View = object : View(this) {
        private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = pal.text
            strokeWidth = px(2).toFloat()
        }
        private val knobPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = pal.text
        }
        override fun onDraw(c: Canvas) {
            val w = width.toFloat()
            val h = height.toFloat()
            val ys = floatArrayOf(h * 0.28f, h * 0.5f, h * 0.72f)
            val kx = floatArrayOf(w * 0.32f, w * 0.68f, w * 0.5f)
            for (i in 0..2) {
                c.drawLine(w * 0.22f, ys[i], w * 0.78f, ys[i], linePaint)
                c.drawCircle(kx[i], ys[i], px(4).toFloat(), knobPaint)
            }
        }
    }

    private fun runRegression(key: String, tpl: String) {
        if (key.isEmpty()) { toast("Isi TMDB API key dulu"); return }
        val template = tpl.ifBlank { Deeplink.DEFAULT }
        val total = RegressionCases.ALL.size
        results.removeAllViews()
        logs.setLength(0)
        bar.visibility = View.VISIBLE
        status.text = "Menjalankan uji 1 dari $total: ${RegressionCases.ALL[0].name}..."
        Thread {
            val tmdb = Tmdb(key)
            RegressionCases.ALL.forEachIndexed { i, rc ->
                runOnUiThread { status.text = "Menjalankan uji ${i + 1} dari $total: ${rc.name}..." }
                val log = mutableListOf<String>()
                val report = try {
                    Resolver(tmdb, PageFetcher(this)).resolve(rc.url, log)
                } catch (e: Exception) {
                    Report(null, Decision.Fail("Exception: $e"), log)
                }
                val text = RegressionCases.render(rc, report, tmdb, template)
                logs.append(text).append("\n\n")
                runOnUiThread {
                    results.add(caseCard(text), 8)
                    status.text = "Selesai ${i + 1} dari $total"
                }
            }
            runOnUiThread {
                bar.visibility = View.GONE
                status.text = "Selesai. Tekan \"Salin log lengkap\" untuk menyalin semua."
            }
        }.start()
    }

    /** Kartu hasil per kasus. Verdict dan ringkasan diambil dari teks hasil (logika tidak berubah). */
    private fun caseCard(full: String): View {
        val lines = full.lines()
        val name = lines.firstOrNull { it.startsWith("== ") }?.removePrefix("== ")?.removeSuffix(" ==") ?: "Uji"
        val raw = lines.firstOrNull { it.startsWith("HASIL: ") }?.removePrefix("HASIL: ") ?: "?"
        val (badge, color) = when {
            raw.startsWith("PASS") -> "PASS" to COLOR_OK
            raw.startsWith("FAIL") -> "FAIL" to COLOR_BAD
            raw.startsWith("AMBIGU") -> "AMBIGU" to COLOR_WARN
            else -> "MANUAL" to COLOR_WARN
        }
        val summary = lines.filter {
            it.startsWith("MDL: ") || it.startsWith("KEPUTUSAN: ") || it.startsWith("LINK: ")
        }

        val c = card()
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        head.addView(TextView(this).apply {
            text = name
            textSize = 15f
            setTextColor(pal.text)
            typeface = Typeface.DEFAULT_BOLD
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        head.addView(TextView(this).apply {
            text = badge
            textSize = 12f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(px(8), px(3), px(8), px(3))
            background = rounded(color, 6)
        })
        c.add(head, 0)
        c.add(TextView(this).apply {
            text = summary.joinToString("\n")
            textSize = 13f
            setTextColor(pal.text)
        }, 8)
        val details = TextView(this).apply {
            text = full
            typeface = Typeface.MONOSPACE
            textSize = 11f
            setTextColor(pal.muted)
            setTextIsSelectable(true)
            visibility = View.GONE
        }
        c.add(details, 8)
        c.add(button("Lihat log", false) {
            details.visibility = if (details.visibility == View.GONE) View.VISIBLE else View.GONE
        }, 8)
        return c
    }

    // ---------- helper tampilan ----------

    private fun px(n: Int) = (n * dp).toInt()

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()

    private fun LinearLayout.add(v: View, topDp: Int = 8) {
        addView(v, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            .apply { topMargin = px(topDp) })
    }

    private fun card() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(px(14), px(14), px(14), px(14))
        background = rounded(pal.card, 12)
    }

    private fun rounded(color: Int, radiusDp: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = px(radiusDp).toFloat()
    }

    private fun label(t: String) = TextView(this).apply {
        text = t
        textSize = 13f
        setTextColor(pal.muted)
    }

    private fun section(t: String) = TextView(this).apply {
        text = t
        textSize = 12f
        setTextColor(pal.muted)
        typeface = Typeface.DEFAULT_BOLD
        letterSpacing = 0.08f
    }

    private fun button(label: String, primary: Boolean, onClick: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        setTextColor(if (primary) Color.WHITE else pal.text)
        background = rounded(if (primary) pal.primary else pal.second, 10)
        setOnClickListener { onClick() }
    }

    companion object {
        private val COLOR_OK = Color.parseColor("#2E7D32")
        private val COLOR_BAD = Color.parseColor("#C62828")
        private val COLOR_WARN = Color.parseColor("#EF6C00")
        const val SERIES_TEST = "nuvio://series/tt26471411"
        const val MOVIE_TEST = "nuvio://movie/tt23289160"
    }
}
