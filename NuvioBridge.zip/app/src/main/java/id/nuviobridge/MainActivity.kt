package id.nuviobridge

import android.app.Activity
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.Editable
import android.text.Spannable
import android.text.SpannableString
import android.text.style.ForegroundColorSpan
import android.text.InputType
import android.text.TextWatcher
import android.text.method.HideReturnsTransformationMethod
import android.text.method.PasswordTransformationMethod
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {

    private lateinit var pal: Pal
    private lateinit var root: LinearLayout
    private lateinit var key: EditText
    private lateinit var keyStatus: TextView
    private lateinit var saveBtn: Button
    private lateinit var modeRow: LinearLayout
    private var savedKey = ""
    private var keyVisible = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        pal = Ui.pal(this)

        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(px(16), px(20), px(16), px(24))
            setBackgroundColor(pal.bg)
        }

        // ---------- HEADER ----------
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        header.addView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(TextView(this@MainActivity).apply {
                text = "MDLvia"
                textSize = 24f
                setTextColor(pal.text)
                typeface = Typeface.DEFAULT_BOLD
            })
            addView(TextView(this@MainActivity).apply {
                text = "MyDramaList ke Nuvio & Semuanya"
                textSize = 14f
                setTextColor(pal.muted)
            })
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

        // Ikon gear: filled biru di atas lingkaran biru muda
        val gearBox = FrameLayout(this).apply {
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#D7E5FB"))
            }
            addView(gearIcon(), FrameLayout.LayoutParams(px(26), px(26), Gravity.CENTER))
            setOnClickListener { startActivity(Intent(this@MainActivity, GearActivity::class.java)) }
        }
        header.addView(gearBox, LinearLayout.LayoutParams(px(48), px(48)))
        root.add(header, 0)

        // ---------- PENGATURAN ----------
        root.add(sectionWithIcon("PENGATURAN"), 20)
        val settings = card()

        keyStatus = TextView(this).apply { textSize = 12f; setTextColor(pal.muted) }
        val keyLabelRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(TextView(this@MainActivity).apply {
                text = "TMDB API Key *"
                textSize = 13f
                setTextColor(pal.muted)
            })
            val info = InfoIconView(this@MainActivity, pal.muted)
            info.setOnClickListener {
                Ui.tooltip(info, "• Masukkan API Key atau Read Access Token.\n• Ambil di Akun TMDB : Profil > Pengaturan > API.\n• Kunci Api hanya disimpan di perangkat ini.", pal)
            }
            addView(info, LinearLayout.LayoutParams(px(16), px(16)).apply { leftMargin = px(6) })
            addView(View(this@MainActivity), LinearLayout.LayoutParams(0, 0, 1f))
            addView(keyStatus)
        }
        settings.add(keyLabelRow, 0)

        key = EditText(this).apply {
            hint = "Masukkan API Key atau Read Access Token"
            setHintTextColor(pal.muted)
            setTextColor(pal.text)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            transformationMethod = PasswordTransformationMethod.getInstance()
            typeface = Typeface.DEFAULT
            textSize = 16f
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun afterTextChanged(s: Editable?) { updateDirty() }
            })
        }
        val eye = EyeIconView(this, false, pal.muted)
        val eyeBox = FrameLayout(this).apply {
            addView(eye, FrameLayout.LayoutParams(px(24), px(24), Gravity.CENTER))
            setOnClickListener {
                keyVisible = !keyVisible
                key.transformationMethod = if (keyVisible) HideReturnsTransformationMethod.getInstance()
                                           else PasswordTransformationMethod.getInstance()
                eye.visible = keyVisible
                eye.invalidate()
                key.setSelection(key.text.length)
            }
        }
        val keyRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(key, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            addView(eyeBox, LinearLayout.LayoutParams(px(44), px(44)))
        }
        settings.add(keyRow, 4)
        settings.add(note("* wajib diisi"), 4)

        saveBtn = button("Simpan", true) {
            saveKey()
            toast("Tersimpan")
        }
        settings.add(saveBtn, 12)
        root.add(settings, 8)

        // ---------- OPEN IN MODE ACTIONS ----------
        root.add(sectionWithInfo("OPEN IN MODE ACTIONS",
            "• Nuvio: hanya membuka di Nuvio.\n• Google: hanya cari di Google.\n• All Actions: pilih dari daftar OPEN IN ACTIONS di Pengaturan.", 300), 20)
        val modeCard = card()
        modeRow = buildModeRow()
        modeCard.add(modeRow, 0)
        modeCard.add(note("Pilih mode saat share dari MDL."), 8)
        root.add(modeCard, 8)

        root.add(TextView(this).apply {
            text = "Versi ${appVersion()}"
            textSize = 12f
            setTextColor(pal.muted)
            gravity = Gravity.CENTER
        }, 24)

        setContentView(ScrollView(this).apply {
            setBackgroundColor(pal.bg)
            addView(root, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        })
        reloadFields()
        Ui.applyScale(root, Ui.scaleValue(this))
    }

    override fun onResume() {
        super.onResume()
        if (::root.isInitialized) {
            reloadFields()
            Ui.applyScale(root, Ui.scaleValue(this))
        }
    }

    private fun buildModeRow(): LinearLayout =
        Ui.segmentRow(this, pal, listOf("Nuvio", "Google", "All Actions"), { modeIndex() }) { i ->
            getSharedPreferences(Ui.PREFS, MODE_PRIVATE).edit().putString("mode", modeValues[i]).apply()
        }

    private fun modeIndex(): Int = modeValues.indexOf(Ui.mode(this)).coerceAtLeast(0)

    /** Muat ulang dari penyimpanan, misalnya setelah kembali dari halaman gear. */
    private fun reloadFields() {
        val p = getSharedPreferences(Ui.PREFS, MODE_PRIVATE)
        savedKey = p.getString("key", "") ?: ""
        key.setText(savedKey)
        updateDirty()
        if (::modeRow.isInitialized) {
            (modeRow.parent as? LinearLayout)?.let { parent ->
                val idx = parent.indexOfChild(modeRow)
                if (idx >= 0) {
                    parent.removeViewAt(idx)
                    modeRow = buildModeRow()
                    parent.addView(modeRow, idx, LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
                }
            }
        }
    }

    /** Tanda "Belum Disimpan" dan tombol Simpan hanya aktif saat kunci berubah. */
    private fun updateDirty() {
        val dirty = key.text.toString().trim() != savedKey
        keyStatus.text = when {
            dirty -> "Belum Disimpan"
            savedKey.isNotBlank() -> "Tersimpan"
            else -> ""
        }
        saveBtn.isEnabled = dirty
        saveBtn.alpha = if (dirty) 1f else 0.4f
    }

    private fun saveKey() {
        val value = key.text.toString().trim()
        getSharedPreferences(Ui.PREFS, MODE_PRIVATE).edit().putString("key", value).apply()
        savedKey = value
        updateDirty()
    }

    /** Ikon gear: roda bergigi (filled) dengan lubang di tengah, digambar langsung. */
    private fun gearIcon(): View = object : View(this) {
        private val gearPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = pal.primary
            style = Paint.Style.FILL
        }
        private val holePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#D7E5FB")
            style = Paint.Style.FILL
        }
        override fun onDraw(c: Canvas) {
            val size = Math.min(width, height).toFloat()
            val cx = width / 2f
            val cy = height / 2f
            val rOut = size * 0.46f
            val rIn = rOut * 0.80f
            val steps = 32
            val path = Path()
            for (i in 0 until steps) {
                val angle = 2 * Math.PI * i / steps - Math.PI / 2
                val r = if (i % 4 < 2) rOut else rIn
                val x = cx + r * Math.cos(angle).toFloat()
                val y = cy + r * Math.sin(angle).toFloat()
                if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            path.close()
            c.drawPath(path, gearPaint)
            c.drawCircle(cx, cy, rOut * 0.36f, holePaint)
        }
    }

    private fun appVersion(): String = try {
        packageManager.getPackageInfo(packageName, 0).versionName ?: ""
    } catch (e: Exception) {
        ""
    }

    // ---------- helper ----------
    private fun px(n: Int) = Ui.px(this, n)
    private fun card() = Ui.card(this, pal)
    private fun section(t: String) = Ui.section(this, pal, t)
    private fun sectionWithInfo(t: String, tip: String, widthDp: Int = 240) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        addView(section(t))
        val info = InfoIconView(this@MainActivity, pal.muted)
        info.setOnClickListener { Ui.tooltip(info, tip, pal, widthDp) }
        addView(info, LinearLayout.LayoutParams(px(16), px(16)).apply { leftMargin = px(6) })
    }
    private fun sectionWithIcon(t: String) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        addView(KeyIconView(this@MainActivity, pal.muted),
            LinearLayout.LayoutParams(px(16), px(16)).apply { rightMargin = px(8) })
        addView(section(t))
    }
    private fun note(t: String) = TextView(this).apply {
        text = t
        textSize = 12f
        setTextColor(pal.muted)
    }
    private fun button(caption: String, primary: Boolean, onClick: () -> Unit) =
        Ui.button(this, pal, caption, primary, onClick)
    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()
    private fun LinearLayout.add(v: View, topDp: Int = 8) = Ui.addTop(this, v, topDp)

    companion object {
        const val SERIES_TEST = "nuvio://series/tt26471411"
        const val MOVIE_TEST = "nuvio://movie/tt23289160"
        private val modeValues = listOf("nuvio", "google", "both")
    }
}
