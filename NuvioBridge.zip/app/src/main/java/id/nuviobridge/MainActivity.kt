package id.nuviobridge

import android.app.Activity
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Typeface
import android.os.Bundle
import android.text.InputType
import android.text.Editable
import android.text.TextWatcher
import android.text.method.HideReturnsTransformationMethod
import android.text.method.PasswordTransformationMethod
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {

    private lateinit var pal: Pal
    private lateinit var root: LinearLayout
    private lateinit var key: EditText
    private lateinit var keyStatus: TextView
    private lateinit var saveBtn: Button
    private lateinit var modeRow: LinearLayout
    private var savedKey = ""
    private var keyVisible = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        pal = Ui.pal(this)

        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(px(16), px(20), px(16), px(24))
            setBackgroundColor(pal.bg)
        }

        // ---------- HEADER ----------
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        header.addView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(TextView(this@MainActivity).apply {
                text = "MDLvia"
                textSize = 24f
                setTextColor(pal.text)
                typeface = Typeface.DEFAULT_BOLD
            })
            addView(TextView(this@MainActivity).apply {
                text = "Buka judul MDL di Nuvio atau Google."
                textSize = 14f
                setTextColor(pal.muted)
            })
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val gear = gearIcon().apply { background = Ui.rounded(this@MainActivity, pal.card, 10) }
        gear.setOnClickListener { startActivity(Intent(this, GearActivity::class.java)) }
        header.addView(gear, LinearLayout.LayoutParams(px(44), px(44)))
        root.add(header, 0)

        // ---------- PENGATURAN ----------
        root.add(section("PENGATURAN"), 20)
        val settings = card()

        keyStatus = TextView(this).apply { textSize = 12f; setTextColor(pal.muted) }
        settings.add(Ui.labelRow(this, pal, "TMDB API key", keyStatus), 0)

        key = EditText(this).apply {
            hint = "Masukkan TMDB API key (v3) atau token (v4)"
            setHintTextColor(pal.muted)
            setTextColor(pal.text)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            transformationMethod = PasswordTransformationMethod.getInstance()
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun afterTextChanged(s: Editable?) { updateDirty() }
            })
        }
        val eye = EyeIconView(this, false, pal.muted)
        val eyeBox = FrameLayout(this).apply {
            addView(eye, FrameLayout.LayoutParams(px(24), px(24), Gravity.CENTER))
            setOnClickListener {
                keyVisible = !keyVisible
                key.transformationMethod = if (keyVisible) HideReturnsTransformationMethod.getInstance()
                                           else PasswordTransformationMethod.getInstance()
                eye.visible = keyVisible
                eye.invalidate()
                key.setSelection(key.text.length)
            }
        }
        val keyRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(key, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            addView(eyeBox, LinearLayout.LayoutParams(px(44), px(44)))
        }
        settings.add(keyRow, 4)

        saveBtn = button("Simpan", true) {
            saveKey()
            toast("Tersimpan")
        }
        settings.add(saveBtn, 14)
        root.add(settings, 8)

        // ---------- TUJUAN SAAT SHARE ----------
        root.add(section("TUJUAN SAAT SHARE"), 20)
        val modeCard = card()
        modeRow = buildModeRow()
        modeCard.add(modeRow, 0)
        modeCard.add(note("Pilih tujuan saat share dari MDL."), 8)
        root.add(modeCard, 8)

        root.add(TextView(this).apply {
            text = "Versi ${appVersion()}"
            textSize = 12f
            setTextColor(pal.muted)
            gravity = Gravity.CENTER
        }, 24)

        setContentView(ScrollView(this).apply {
            setBackgroundColor(pal.bg)
            addView(root, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        })
        reloadFields()
        Ui.applyScale(root, Ui.scaleValue(this))
    }

    override fun onResume() {
        super.onResume()
        if (::root.isInitialized) {
            reloadFields()
            Ui.applyScale(root, Ui.scaleValue(this))
        }
    }

    private fun buildModeRow(): LinearLayout = Ui.segmentRow(this, pal, listOf("Nuvio", "Google", "All Actions"), { modeIndex() }) { i ->
        getSharedPreferences(Ui.PREFS, MODE_PRIVATE).edit().putString("mode", modeValues[i]).apply()
    }

    private fun modeIndex(): Int = modeValues.indexOf(Ui.mode(this)).coerceAtLeast(0)

    /** Muat ulang dari penyimpanan, misalnya setelah kembali dari halaman gear. */
    private fun reloadFields() {
        val p = getSharedPreferences(Ui.PREFS, MODE_PRIVATE)
        savedKey = p.getString("key", "") ?: ""
        key.setText(savedKey)
        updateDirty()
        if (::modeRow.isInitialized) {
            (modeRow.parent as? LinearLayout)?.let { parent ->
                val idx = parent.indexOfChild(modeRow)
                if (idx >= 0) {
                    parent.removeViewAt(idx)
                    modeRow = buildModeRow()
                    parent.addView(modeRow, idx, LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
                }
            }
        }
    }

    /** Tanda "Belum disimpan" dan tombol Simpan hanya aktif saat kunci berubah. */
    private fun updateDirty() {
        val dirty = key.text.toString().trim() != savedKey
        keyStatus.text = if (dirty) "Belum disimpan" else ""
        saveBtn.isEnabled = dirty
        saveBtn.alpha = if (dirty) 1f else 0.4f
    }

    private fun saveKey() {
        val value = key.text.toString().trim()
        getSharedPreferences(Ui.PREFS, MODE_PRIVATE).edit().putString("key", value).apply()
        savedKey = value
        updateDirty()
    }

    /** Ikon gear: roda bergigi dengan lubang di tengah, digambar langsung. */
    private fun gearIcon(): View = object : View(this) {
        private val gearPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = pal.text
            style = Paint.Style.FILL
        }
        private val holePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = pal.card
            style = Paint.Style.FILL
        }
        override fun onDraw(c: Canvas) {
            val size = Math.min(width, height).toFloat()
            val cx = width / 2f
            val cy = height / 2f
            val rOut = size * 0.42f
            val rIn = rOut * 0.80f
            val steps = 32
            val path = Path()
            for (i in 0 until steps) {
                val angle = 2 * Math.PI * i / steps - Math.PI / 2
                val r = if (i % 4 < 2) rOut else rIn
                val x = cx + r * Math.cos(angle).toFloat()
                val y = cy + r * Math.sin(angle).toFloat()
                if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            path.close()
            c.drawPath(path, gearPaint)
            c.drawCircle(cx, cy, rOut * 0.36f, holePaint)
        }
    }

    private fun appVersion(): String = try {
        packageManager.getPackageInfo(packageName, 0).versionName ?: ""
    } catch (e: Exception) {
        ""
    }

    // ---------- helper ----------
    private fun px(n: Int) = Ui.px(this, n)
    private fun card() = Ui.card(this, pal)
    private fun section(t: String) = Ui.section(this, pal, t)
    private fun note(t: String) = TextView(this).apply {
        text = t
        textSize = 12f
        setTextColor(pal.muted)
    }
    private fun button(caption: String, primary: Boolean, onClick: () -> Unit) =
        Ui.button(this, pal, caption, primary, onClick)
    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()
    private fun LinearLayout.add(v: View, topDp: Int = 8) = Ui.addTop(this, v, topDp)

    companion object {
        const val SERIES_TEST = "nuvio://series/tt26471411"
        const val MOVIE_TEST = "nuvio://movie/tt23289160"
        private val modeValues = listOf("nuvio", "google", "both")
    }
}
