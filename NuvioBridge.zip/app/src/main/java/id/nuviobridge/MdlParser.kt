package id.nuviobridge

import org.jsoup.Jsoup

object MdlParser {

    /** Ambil URL MDL dari teks share. Hanya mydramalist.com yang diterima. */
    fun extractUrl(text: String): String? {
        val m = Regex("https?://(?:www\\.)?mydramalist\\.com/\\d+[^\\s?#]*").find(text) ?: return null
        return m.value.trimEnd(')', ']', '.', ',')
    }

    fun parse(html: String, url: String): MdlMeta {
        val doc = Jsoup.parse(html, url)
        val notes = mutableListOf<String>()

        val og = doc.selectFirst("meta[property=og:title]")?.attr("content")?.trim()
        val h1 = doc.selectFirst("h1.film-title, h1")?.text()?.trim()
        val titleTag = doc.title().trim()

        fun stripSite(s: String?): String? =
            s?.replace(Regex("\\s*[-|–]\\s*MyDramaList\\s*$", RegexOption.IGNORE_CASE), "")?.trim()
        fun stripYear(s: String?): String? =
            s?.replace(Regex("\\s*\\(\\d{4}\\)\\s*$"), "")?.trim()
        fun yearOf(s: String?): Int? =
            s?.let { Regex("\\((\\d{4})\\)").findAll(it).lastOrNull()?.groupValues?.get(1)?.toIntOrNull() }

        val titleCandidates = listOf(stripYear(stripSite(og)), stripYear(h1), stripYear(stripSite(titleTag)))
            .filterNotNull().filter { it.isNotBlank() }
        val title = titleCandidates.firstOrNull()
        val extraTitles = titleCandidates.drop(1)

        // Kotak detail: <li><b>Label:</b> nilai</li>
        val labels = mutableListOf<String>()
        val fields = mutableMapOf<String, String>()
        val alts = mutableListOf<String>()
        for (li in doc.select("li")) {
            val b = li.selectFirst("b") ?: continue
            val label = b.text().trim().trimEnd(':').trim().lowercase()
            if (label.isEmpty() || label.length > 30) continue
            labels += label
            val value = li.text().removePrefix(b.text()).trim()
            if (label.startsWith("also known as")) {
                val links = li.select("a").map { it.text().trim() }.filter { it.isNotEmpty() }
                alts += if (links.isNotEmpty()) links
                        else value.split(",").map { it.trim() }.filter { it.isNotEmpty() }
            } else {
                fields.putIfAbsent(label, value)
            }
        }

        val nativeTitle = fields["native title"]?.takeIf { it.isNotBlank() }
        val country = fields["country"]?.takeIf { it.isNotBlank() }

        var year = yearOf(og) ?: yearOf(h1) ?: yearOf(titleTag)
        if (year == null) {
            for (k in listOf("aired", "release date", "released", "date")) {
                val v = fields[k] ?: continue
                val m = Regex("(19|20)\\d{2}").find(v)
                if (m != null) { year = m.value.toInt(); notes += "tahun dari field '$k'"; break }
            }
        }

        val typeRaw = fields["type"]?.lowercase()
        var type: String? = when {
            typeRaw == null -> null
            typeRaw.contains("movie") -> "movie"
            typeRaw.contains("drama") || typeRaw.contains("tv") || typeRaw.contains("special") ||
                typeRaw.contains("series") || typeRaw.contains("show") -> "tv"
            else -> null
        }
        if (type == null) {
            val eps = fields["episodes"]?.trim()?.toIntOrNull()
            type = when {
                eps != null && eps > 1 -> "tv"
                fields.containsKey("aired") -> "tv"
                fields.containsKey("release date") && !fields.containsKey("aired") -> "movie"
                else -> null
            }
            if (type != null) notes += "tipe diperkirakan dari field lain (bukan dari 'Type')"
        }

        val imdb = doc.select("a[href*=imdb.com/title/]").asSequence()
            .mapNotNull { Regex("tt\\d{6,}").find(it.attr("href"))?.value }
            .firstOrNull()

        return MdlMeta(
            url = url, title = title, nativeTitle = nativeTitle,
            altTitles = (extraTitles + alts).distinct(),
            year = year, type = type, country = country, imdbId = imdb,
            labelsSeen = labels.distinct(), rawOgTitle = og, notes = notes
        )
    }
}
