package id.nuviobridge

import java.text.Normalizer

object Text {
    fun norm(s: String): String {
        val d = Normalizer.normalize(s.lowercase(), Normalizer.Form.NFD).replace(Regex("\\p{M}+"), "")
        return d.replace(Regex("[^\\p{L}\\p{N}]+"), " ").trim()
    }
}

data class MdlMeta(
    val url: String,
    val title: String?,
    val nativeTitle: String?,
    val altTitles: List<String>,
    val year: Int?,
    val type: String?,        // "movie" | "tv" | null (tidak diketahui)
    val country: String?,
    val imdbId: String?,
    val labelsSeen: List<String>,
    val rawOgTitle: String?,
    val notes: List<String>
) {
    fun allTitles(): List<String> =
        (listOfNotNull(title, nativeTitle) + altTitles)
            .map { it.trim() }
            .filter { it.isNotEmpty() }
            .distinctBy { Text.norm(it) }
}

data class Candidate(
    val type: String,         // "movie" | "tv"
    val tmdbId: Int,
    val title: String,
    val originalTitle: String,
    val year: Int?,
    val lang: String?,
    val countries: List<String>,
    var score: Int = 0,
    var sim: Double = 0.0,
    var exactTitle: Boolean = false,
    var countryMismatch: Boolean = false,
    var why: String = "",
    val poster: String? = null
) {
    fun label(): String {
        val y = if (year != null) " ($year)" else ""
        val t = if (type == "tv") "Serial" else "Film"
        val o = if (originalTitle.isNotBlank() && originalTitle != title) " • $originalTitle" else ""
        return "$title$y • $t$o"
    }
}

sealed class Decision {
    data class Auto(val c: Candidate, val reason: String) : Decision()
    data class Choose(val list: List<Candidate>) : Decision()
    data class Fail(val reason: String) : Decision()
}

class Report(val meta: MdlMeta?, val decision: Decision, val log: List<String>)

object Deeplink {
    const val DEFAULT = "nuvio://{type}/{imdb}"
    fun build(tpl: String, c: Candidate, imdb: String): String =
        tpl.replace("{type}", if (c.type == "tv") "series" else "movie")
            .replace("{imdb}", imdb)
            .replace("{tmdb}", c.tmdbId.toString())
            .replace("{tmdbtype}", c.type)
}
