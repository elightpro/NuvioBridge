package id.nuviobridge

import android.app.Activity
import android.os.Handler
import android.os.Looper
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONTokener
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

/** Ambil HTML halaman MDL. HTTP biasa dulu; kalau diblokir, pakai WebView (mesin browser asli). */
class PageFetcher(private val activity: Activity) {

    fun get(url: String, log: MutableList<String>): String {
        try {
            val html = http(url)
            if (looksValid(html)) { log += "Halaman MDL diambil via HTTP"; return html }
            log += "HTTP berhasil tapi isi bukan halaman judul (kemungkinan tantangan Cloudflare); coba WebView"
        } catch (e: Exception) {
            log += "HTTP gagal: ${e.message}; coba WebView"
        }
        val html = webView(url)
        log += "Halaman MDL diambil via WebView"
        return html
    }

    private fun looksValid(h: String) = h.contains("og:title") || h.contains("film-title")

    private fun http(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.instanceFollowRedirects = true
        c.connectTimeout = 12000
        c.readTimeout = 15000
        c.setRequestProperty("User-Agent", UA)
        c.setRequestProperty("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
        c.setRequestProperty("Accept-Language", "en-US,en;q=0.9")
        val code = c.responseCode
        if (code !in 200..299) throw Exception("HTTP $code")
        return c.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
    }

    private fun webView(url: String): String {
        val latch = CountDownLatch(1)
        val holder = arrayOfNulls<String>(1)
        val done = AtomicBoolean(false)
        val main = Handler(Looper.getMainLooper())

        activity.runOnUiThread {
            val wv = WebView(activity.applicationContext)
            wv.settings.javaScriptEnabled = true
            wv.settings.domStorageEnabled = true
            wv.settings.userAgentString = UA
            wv.webViewClient = WebViewClient()
            var tries = 0

            fun complete(html: String?) {
                if (!done.compareAndSet(false, true)) return
                holder[0] = html
                try { wv.stopLoading(); wv.destroy() } catch (e: Exception) { }
                latch.countDown()
            }

            fun poll() {
                if (done.get()) return
                wv.evaluateJavascript("document.documentElement.outerHTML") { raw ->
                    val html = try { JSONTokener(raw ?: "null").nextValue() as? String } catch (e: Exception) { null }
                    if (html != null && looksValid(html)) complete(html)
                    else if (++tries >= 25) complete(null)
                    else main.postDelayed({ poll() }, 1000)
                }
            }

            wv.loadUrl(url)
            main.postDelayed({ poll() }, 2500)
        }

        latch.await(45, TimeUnit.SECONDS)
        done.set(true)
        return holder[0] ?: throw Exception("WebView tidak mendapat halaman judul (mungkin diblokir)")
    }

    companion object {
        const val UA = "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 " +
            "(KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"
    }
}
