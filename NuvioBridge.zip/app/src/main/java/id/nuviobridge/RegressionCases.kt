package id.nuviobridge

/** Tiga URL ini adalah kasus regresi PERMANEN. Jalankan lewat tombol "Uji regresi" setiap resolver diubah. */
data class RegressionCase(
    val name: String,
    val url: String,
    val expectTitle: String?,   // null = belum ada expected, hasil harus dinilai manual
    val expectYear: Int?,
    val expectType: String?,    // "tv" | "movie" | null
    val note: String
)

object RegressionCases {
    val ALL = listOf(
        RegressionCase(
            "TEST 1 - slug tidak sama dengan judul",
            "https://mydramalist.com/784486-honey-jar-part-time-project",
            "Dead-End Job", 2026, null,
            "Slug 'honey jar part time project' bukan judul; harus ke Dead-End Job (2026)"
        ),
        RegressionCase(
            "TEST 2 - validasi identitas judul",
            "https://mydramalist.com/35729-emergency-lands-of-love",
            null, null, null,
            "Isi expectTitle/expectYear/expectType setelah diverifikasi manual"
        ),
        RegressionCase(
            "TEST 3 - slug khusus",
            "https://mydramalist.com/797170-chodaisaku-kaiju-eiga",
            null, null, null,
            "Isi expectTitle/expectYear/expectType setelah diverifikasi manual"
        )
    )

    fun render(rc: RegressionCase, r: Report, tmdb: Tmdb, tpl: String): String {
        val sb = StringBuilder()
        sb.appendLine("== ${rc.name} ==")
        sb.appendLine(rc.url)
        val m = r.meta
        if (m != null) {
            sb.appendLine("MDL: judul=${m.title} | native=${m.nativeTitle} | tahun=${m.year} | tipe=${m.type} | negara=${m.country} | imdb=${m.imdbId}")
            sb.appendLine("MDL alt: ${m.altTitles.take(6)}")
            if (m.title == null || m.year == null || m.type == null)
                sb.appendLine("label ditemukan: ${m.labelsSeen} | og:title=${m.rawOgTitle}")
        }
        val verdict = when (val d = r.decision) {
            is Decision.Auto -> {
                sb.appendLine("KEPUTUSAN: BUKA OTOMATIS -> ${d.c.label()} [${d.c.type}/${d.c.tmdbId}] (${d.reason})")
                try {
                    val imdb = tmdb.imdbOf(d.c)
                    sb.appendLine("LINK: " + (if (imdb == null) "(TMDB tidak punya IMDb ID)" else Deeplink.build(tpl, d.c, imdb)))
                } catch (e: Exception) { sb.appendLine("LINK: gagal ambil IMDb ID (${e.message})") }
                judge(rc, listOf(d.c), true)
            }
            is Decision.Choose -> {
                sb.appendLine("KEPUTUSAN: AMBIGU, daftar pilihan akan tampil:")
                d.list.forEach { sb.appendLine("  - ${it.label()} [${it.type}/${it.tmdbId}] skor ${it.score}: ${it.why}") }
                judge(rc, d.list, false)
            }
            is Decision.Fail -> {
                sb.appendLine("KEPUTUSAN: GAGAL -> ${d.reason}")
                if (rc.expectTitle == null) "MANUAL (resolver gagal)" else "FAIL"
            }
        }
        sb.appendLine("HASIL: $verdict")
        sb.appendLine("LOG:")
        r.log.forEach { sb.appendLine("  $it") }
        return sb.toString()
    }

    private fun judge(rc: RegressionCase, list: List<Candidate>, auto: Boolean): String {
        val exp = rc.expectTitle ?: return "MANUAL - cocokkan sendiri dengan judul sebenarnya (belum ada expected)"
        val expN = Text.norm(exp)
        fun match(c: Candidate) =
            (Text.norm(c.title).contains(expN) || Text.norm(c.originalTitle).contains(expN)) &&
                (rc.expectYear == null || c.year == rc.expectYear) &&
                (rc.expectType == null || c.type == rc.expectType)
        return if (auto) {
            if (match(list[0])) "PASS" else "FAIL (membuka judul yang salah)"
        } else {
            if (list.any { match(it) }) "AMBIGU-OK (judul benar ada di daftar, tidak dibuka otomatis)"
            else "FAIL (judul benar tidak ada di daftar)"
        }
    }
}
