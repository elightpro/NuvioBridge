package id.nuviobridge

import kotlin.math.abs

/**
 * Alur (sesuai spesifikasi):
 * 1) baca metadata halaman MDL (bukan slug URL)
 * 2) IMDb ID dulu, divalidasi dengan tahun/tipe
 * 3) kalau tidak ada: cari di TMDB pakai judul asli + judul alternatif, nilai dengan tahun/tipe/negara
 * 4) satu kandidat sangat kuat -> otomatis; beberapa masuk akal -> daftar pilihan; tidak ada -> gagal
 */
class Resolver(private val tmdb: Tmdb, private val pages: PageFetcher) {

    fun resolve(url: String, log: MutableList<String>): Report {
        val html = try { pages.get(url, log) } catch (e: Exception) {
            log += "Gagal ambil halaman MDL: ${e.message}"
            return Report(null, Decision.Fail("Halaman MDL tidak bisa dibaca (${e.message})"), log)
        }
        val meta = MdlParser.parse(html, url)
        log += "Metadata: judul=${meta.title} | native=${meta.nativeTitle} | tahun=${meta.year} | " +
            "tipe=${meta.type} | negara=${meta.country} | imdb=${meta.imdbId}"
        meta.notes.forEach { log += "Catatan parser: $it" }
        if (meta.allTitles().isEmpty())
            return Report(meta, Decision.Fail("Judul tidak ditemukan di halaman MDL"), log)

        // --- Jalur IMDb ID ---
        if (meta.imdbId != null) {
            try {
                val found = tmdb.find(meta.imdbId)
                val ok = found.filter { consistent(it, meta) }
                if (ok.size == 1)
                    return Report(meta, Decision.Auto(ok[0], "IMDb ID ${meta.imdbId} dari MDL, cocok dengan tahun/tipe"), log)
                log += "IMDb ID ${meta.imdbId}: ${found.size} hasil TMDB, ${ok.size} konsisten; lanjut cari lewat judul"
            } catch (e: Exception) {
                log += "TMDB find gagal: ${e.message}"
            }
        } else {
            log += "Halaman MDL tidak menyertakan IMDb ID; cari lewat judul"
        }

        // --- Jalur judul ---
        val allNorm = meta.allTitles().map { Text.norm(it) }.filter { it.isNotEmpty() }.toSet()
        val queries = meta.allTitles().take(4)
        val pool = LinkedHashMap<String, Candidate>()
        var errors = 0
        var lastError: String? = null

        fun searchAll(types: List<String>) {
            for (q in queries) for (ty in types) {
                try {
                    for (c in tmdb.search(ty, q)) pool.putIfAbsent("${c.type}:${c.tmdbId}", c)
                } catch (e: Exception) {
                    errors++; lastError = e.message
                    log += "search gagal ($ty, \"$q\"): ${e.message}"
                }
            }
        }
        searchAll(if (meta.type != null) listOf(meta.type) else listOf("tv", "movie"))
        if (pool.isEmpty() && meta.type != null) {
            log += "Tidak ada hasil untuk tipe ${meta.type}; coba tipe lain"
            searchAll(listOf(if (meta.type == "tv") "movie" else "tv"))
        }
        if (pool.isEmpty()) {
            val why = if (errors > 0) "TMDB error: $lastError" else "Tidak ada hasil di TMDB untuk judul MDL"
            return Report(meta, Decision.Fail(why), log)
        }

        pool.values.forEach { score(it, meta, allNorm) }
        val ranked = pool.values
            .filter { it.exactTitle || it.sim >= 0.5 }
            .sortedByDescending { it.score }
        ranked.take(6).forEach { log += "Kandidat ${it.type}/${it.tmdbId} ${it.label()} skor=${it.score} [${it.why}]" }

        val best = ranked.firstOrNull()
        if (best == null || best.score < 35)
            return Report(meta, Decision.Fail("Tingkat kecocokan TMDB sangat rendah"), log)

        val rivals = ranked.drop(1).filter { it.score >= 35 && it.score >= best.score - 20 }
        return if (isStrong(best, meta) && rivals.isEmpty()) {
            Report(meta, Decision.Auto(best, "judul persis + tahun + tipe cocok, tanpa pesaing"), log)
        } else {
            Report(meta, Decision.Choose(ranked.filter { it.score >= 35 }.take(6)), log)
        }
    }

    private fun consistent(c: Candidate, m: MdlMeta): Boolean {
        val yearOk = m.year == null || c.year == null || abs(m.year - c.year) <= 1
        val typeOk = m.type == null || m.type == c.type
        return yearOk && typeOk
    }

    private fun isStrong(c: Candidate, m: MdlMeta): Boolean {
        val yearOk = m.year != null && c.year != null && abs(m.year - c.year) <= 1
        val typeOk = m.type == null || m.type == c.type
        return c.exactTitle && yearOk && typeOk && !c.countryMismatch
    }

    private val countries = mapOf(
        "south korea" to Pair("KR", setOf("ko")),
        "korea" to Pair("KR", setOf("ko")),
        "japan" to Pair("JP", setOf("ja")),
        "china" to Pair("CN", setOf("zh", "cn")),
        "taiwan" to Pair("TW", setOf("zh", "cn")),
        "hong kong" to Pair("HK", setOf("zh", "cn")),
        "thailand" to Pair("TH", setOf("th")),
        "philippines" to Pair("PH", setOf("tl", "en")),
        "indonesia" to Pair("ID", setOf("id"))
    )

    private fun score(c: Candidate, m: MdlMeta, allNorm: Set<String>) {
        var s = 0
        val why = mutableListOf<String>()

        val cn = listOf(c.title, c.originalTitle).map { Text.norm(it) }.filter { it.isNotEmpty() }
        c.exactTitle = cn.any { it in allNorm }
        c.sim = cn.maxOfOrNull { a -> allNorm.maxOfOrNull { b -> sim(a, b) } ?: 0.0 } ?: 0.0
        if (c.exactTitle) { s += 50; why += "judul persis" }
        else { s += (c.sim * 25).toInt(); why += "mirip ${(c.sim * 100).toInt()}%" }

        val my = m.year; val cy = c.year
        if (my != null && cy != null) {
            when (abs(my - cy)) {
                0 -> { s += 30; why += "tahun sama" }
                1 -> { s += 15; why += "tahun selisih 1" }
                else -> { s -= 30; why += "tahun beda ($my vs $cy)" }
            }
        }
        if (m.type != null) {
            if (m.type == c.type) { s += 15; why += "tipe cocok" } else { s -= 40; why += "tipe beda" }
        }
        val info = m.country?.lowercase()?.let { countries[it] }
        if (info != null) {
            val match = if (c.type == "tv" && c.countries.isNotEmpty()) info.first in c.countries
                        else (c.lang != null && c.lang in info.second)
            if (match) { s += 10; why += "negara cocok" }
            else { s -= 15; c.countryMismatch = true; why += "negara beda" }
        }
        c.score = s
        c.why = why.joinToString(", ")
    }

    private fun sim(a: String, b: String): Double {
        val x = a.split(" ").filter { it.isNotEmpty() }.toSet()
        val y = b.split(" ").filter { it.isNotEmpty() }.toSet()
        if (x.isEmpty() || y.isEmpty()) return 0.0
        return x.intersect(y).size.toDouble() / x.union(y).size
    }
}
