package id.nuviobridge

/** Deteksi nomor musim dari judul. Hanya kata "Season" atau "Musim" yang dianggap musim. */
object SeasonDetect {
    private val re = Regex("""\b(?:season|musim)\s*(\d{1,2})\b""", RegexOption.IGNORE_CASE)

    fun detect(titles: List<String>): Int? {
        for (t in titles) {
            val m = re.find(t)
            if (m != null) return m.groupValues[1].toIntOrNull()
        }
        return null
    }
}

data class SeasonCase(val url: String, val season: Int?, val note: String)

/** Daftar uji. season = null berarti judul bukan musim (termasuk Part dan remake). */
object SeasonCases {
    val ALL = listOf(
        SeasonCase("https://mydramalist.com/705589-taxi-driver-2", 2, "taxi-driver-2"),
        SeasonCase("https://mydramalist.com/51845-taxi-driver", null, "taxi-driver"),
        SeasonCase("https://mydramalist.com/10708-taxi-driver", null, "taxi-driver (remake)"),
        SeasonCase("https://mydramalist.com/750961-taxi-driver-season-3", 3, "taxi-driver-season-3"),
        SeasonCase("https://mydramalist.com/726955-the-witch", null, "the-witch"),
        SeasonCase("https://mydramalist.com/29367-the-witch", null, "the-witch (lain)"),
        SeasonCase("https://mydramalist.com/43843-the-witch-part-2", null, "the-witch-part-2"),
        SeasonCase("https://mydramalist.com/684373-imawa-no-kuni-no-alice-2", 2, "imawa-no-kuni-no-alice-2"),
        SeasonCase("https://mydramalist.com/757971-imawa-no-kuni-no-alice-season-3", 3, "imawa-no-kuni-no-alice-season-3"),
        SeasonCase("https://mydramalist.com/39537-imawa-no-kuni-no-arisu", 1, "imawa-no-kuni-no-arisu"),
        SeasonCase("https://mydramalist.com/54083-joy-of-life-season-2", 2, "joy-of-life-season-2"),
        SeasonCase("https://mydramalist.com/3661-legal-high", 1, "legal-high (3661)"),
        SeasonCase("https://mydramalist.com/7930-legal-high-2", 2, "legal-high-2"),
        SeasonCase("https://mydramalist.com/31464-legal-high", null, "legal-high (31464)"),
        SeasonCase("https://mydramalist.com/682545-hatsukoi", null, "hatsukoi"),
        SeasonCase("https://mydramalist.com/77477-first-time-love-you-its-not-too-late", null, "first-time-love-you"),
        SeasonCase("https://mydramalist.com/758379-family-plan", 1, "family-plan"),
        SeasonCase("https://mydramalist.com/83-i-give-my-first-love-to-you", null, "i-give-my-first-love"),
        SeasonCase("https://mydramalist.com/24623-doctor-x-5", 5, "doctor-x-5"),
        SeasonCase("https://mydramalist.com/787220-doctor-x-age-of-the-white-mafia", null, "doctor-x-age-of-the-white-mafia"),
        SeasonCase("https://mydramalist.com/5432-doctor-x", 1, "doctor-x (5432)"),
        SeasonCase("https://mydramalist.com/20360-i-want-to-eat-your-pancreas", null, "i-want-to-eat-your-pancreas"),
        SeasonCase("https://mydramalist.com/722171-first-frost", null, "first-frost"),
        SeasonCase("https://mydramalist.com/797154-strobe-edge-season-2", 2, "strobe-edge-season-2"),
        SeasonCase("https://mydramalist.com/11024-strobe-edge", null, "strobe-edge (11024)"),
        SeasonCase("https://mydramalist.com/797152-strobe-edge", 1, "strobe-edge (797152)"),
        SeasonCase("https://mydramalist.com/1589-love-letter", null, "love-letter")
    )
}
