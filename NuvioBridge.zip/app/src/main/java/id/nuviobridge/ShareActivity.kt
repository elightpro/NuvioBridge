package id.nuviobridge

import android.app.Activity
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import java.net.URL

class ShareActivity : Activity() {

    private var key = ""
    private var tpl = Deeplink.DEFAULT
    private var mode = "nuvio"
    @Volatile private var cancelled = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val text = (intent.getStringExtra(Intent.EXTRA_TEXT) ?: "") + " " +
            (intent.getStringExtra(Intent.EXTRA_SUBJECT) ?: "")
        Log.d(TAG, "shared=[$text]")

        val p = getSharedPreferences(Ui.PREFS, MODE_PRIVATE)
        key = (p.getString("key", "") ?: "").trim()
        tpl = (p.getString("tpl", "") ?: "").trim().ifEmpty { Deeplink.DEFAULT }
        mode = Ui.mode(this)

        val url = MdlParser.extractUrl(text)
        if (url == null) { toast("Tautan yang dibagikan bukan dari MyDramaList."); finish(); return }
        if (key.isEmpty()) { toast("Isi TMDB API key di app MDLvia dulu"); finish(); return }

        val busy = showBusy("Menunggu verifikasi MDL & TMDB")
        Thread {
            val log = mutableListOf<String>()
            val report = try {
                Resolver(Tmdb(key), PageFetcher(this)).resolve(url, log)
            } catch (e: Exception) {
                Report(null, Decision.Fail("Error: ${e.message}"), log)
            }
            Log.d(TAG, log.joinToString("\n"))
            if (!cancelled) {
                runOnUiThread {
                    busy.dismiss()
                    handle(report)
                }
            }
        }.start()
    }

    private fun handle(report: Report) {
        when (val d = report.decision) {
            is Decision.Auto -> act(d.c)
            is Decision.Choose -> chooser(d.list)
            is Decision.Fail -> failAct(report.meta, d.reason)
        }
    }

    /** Judul sudah dipastikan dari TMDB. */
    private fun act(c: Candidate) {
        when (mode) {
            "google" -> launchUrl(candidateUrl(c))
            "both" -> Thread {
                val t = targetFor(c)
                runOnUiThread { pickAction(t, c) }
            }.start()
            else -> openInNuvio(c)
        }
    }

    /** Judul tidak ditemukan di TMDB: hanya data dari MDL yang tersedia. */
    private fun failAct(meta: MdlMeta?, reason: String) {
        if (meta == null || meta.allTitles().isEmpty() || reason.startsWith("TMDB error")) {
            toast(reason)
            finish()
            return
        }
        when (mode) {
            "google" -> launchUrl(buildGoogleUrl(meta.allTitles(), meta.year, meta.type, meta.country, null))
            "both" -> pickAction(metaTarget(meta), null)
            else -> offerGoogle(
                buildGoogleUrl(meta.allTitles(), meta.year, meta.type, meta.country, null),
                "Judul tidak ditemukan di TMDB. Cari di Google?"
            )
        }
    }

    /** Daftar pilihan dengan poster, tahun, dan tipe. */
    private fun chooser(list: List<Candidate>) {
        val lv = ListView(this)
        lv.adapter = object : BaseAdapter() {
            override fun getCount() = list.size
            override fun getItem(position: Int): Any = list[position]
            override fun getItemId(position: Int) = position.toLong()
            override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
                val c = list[position]
                val row = LinearLayout(this@ShareActivity).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(dpi(12), dpi(10), dpi(12), dpi(10))
                }
                val img = ImageView(this@ShareActivity).apply {
                    layoutParams = LinearLayout.LayoutParams(dpi(60), dpi(90))
                    scaleType = ImageView.ScaleType.CENTER_CROP
                    setBackgroundColor(0xFFE3E8EF.toInt())
                }
                val txt = TextView(this@ShareActivity).apply {
                    text = c.label()
                    textSize = 16f
                    setPadding(dpi(14), 0, dpi(4), 0)
                }
                row.addView(img)
                row.addView(txt)
                c.poster?.let { loadPoster(img, it) }
                return row
            }
        }
        val dlg = AlertDialog.Builder(this)
            .setTitle("Konfirmasi Judul")
            .setView(lv)
            .setNegativeButton("Batal") { _, _ -> finish() }
            .setOnCancelListener { finish() }
            .create()
        lv.setOnItemClickListener { _, _, pos, _ ->
            dlg.dismiss()
            act(list[pos])
        }
        dlg.show()
    }

    /** Mode Keduanya: daftar aksi yang aktif dan tersedia untuk judul ini, dengan tombol Batal. */
    private fun pickAction(t: Target, c: Candidate?) {
        val options = Actions.load(this).filter { it.enabled && Actions.available(it, t) }
        if (options.isEmpty()) {
            toast("Tidak ada aksi yang tersedia untuk judul ini")
            finish()
            return
        }
        val textColor = Ui.pal(this).text
        val lv = ListView(this)
        lv.adapter = object : BaseAdapter() {
            override fun getCount() = options.size
            override fun getItem(position: Int): Any = options[position]
            override fun getItemId(position: Int) = position.toLong()
            override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
                val a = options[position]
                val row = LinearLayout(this@ShareActivity).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(dpi(16), dpi(14), dpi(16), dpi(14))
                }
                row.addView(ActionIconView(this@ShareActivity, a.icon, textColor),
                    LinearLayout.LayoutParams(dpi(26), dpi(26)))
                row.addView(TextView(this@ShareActivity).apply {
                    text = a.name
                    textSize = 16f
                    setTextColor(textColor)
                    setPadding(dpi(14), 0, 0, 0)
                })
                return row
            }
        }
        val dlg = AlertDialog.Builder(this)
            .setTitle("Buka dengan")
            .setView(lv)
            .setNegativeButton("Batal") { _, _ -> finish() }
            .setOnCancelListener { finish() }
            .create()
        lv.setOnItemClickListener { _, _, pos, _ ->
            dlg.dismiss()
            runAction(options[pos], t, c)
        }
        dlg.show()
    }

    private fun runAction(a: Action, t: Target, c: Candidate?) {
        val url: String? = when (a.builtin) {
            "nuvio" -> {
                val imdb = t.imdbId
                if (c != null && imdb != null) Deeplink.build(tpl, c, imdb) else null
            }
            "google" -> buildGoogleUrl(t.titles, t.year, t.type, t.country, t.tmdbId)
            else -> Actions.fill(a.template, t)
        }
        if (url == null) {
            toast("Aksi tidak tersedia untuk judul ini")
            finish()
            return
        }
        Log.d(TAG, "aksi=${a.name} url=$url")
        launchUrl(url)
    }

    /** Data judul dari TMDB, termasuk ID IMDb dan TVDB untuk placeholder custom. */
    private fun targetFor(c: Candidate): Target {
        var imdb: String? = null
        var tvdb: Int? = null
        try {
            val j = Tmdb(key).externalIds(c)
            imdb = j.optString("imdb_id").takeIf { it.startsWith("tt") }
            tvdb = j.optInt("tvdb_id", 0).takeIf { it > 0 }
        } catch (e: Exception) {
            Log.d(TAG, "external ids gagal: ${e.message}")
        }
        return Target(
            titles = listOf(c.title, c.originalTitle),
            year = c.year,
            type = c.type,
            country = c.countries.firstOrNull(),
            tmdbId = c.tmdbId,
            imdbId = imdb,
            tvdbId = tvdb
        )
    }

    private fun metaTarget(meta: MdlMeta) = Target(
        titles = meta.allTitles(),
        year = meta.year,
        type = meta.type,
        country = meta.country,
        tmdbId = null,
        imdbId = null,
        tvdbId = null
    )

    /** Mode Nuvio: buka deep link Nuvio; kalau IMDb ID tidak ada, tawarkan Google. */
    private fun openInNuvio(c: Candidate) {
        Thread {
            val lookup: Pair<String?, String?> = try {
                Pair(Tmdb(key).imdbOf(c), null)
            } catch (e: Exception) {
                Pair(null, e.message ?: e.toString())
            }
            val imdb = lookup.first
            val failure = lookup.second
            runOnUiThread {
                when {
                    failure != null -> { toast(failure); finish() }
                    imdb == null -> offerGoogle(
                        candidateUrl(c),
                        "IMDb ID tidak ditemukan. Cari di Google?"
                    )
                    else -> {
                        val link = Deeplink.build(tpl, c, imdb)
                        Log.d(TAG, "link=$link")
                        launchUrl(link)
                    }
                }
            }
        }.start()
    }

    /** Konfirmasi dengan dua tombol: Google dan Batal. */
    private fun offerGoogle(url: String, message: String) {
        AlertDialog.Builder(this)
            .setTitle("Cari di Google")
            .setMessage(message)
            .setPositiveButton("Google") { _, _ -> launchUrl(url) }
            .setNegativeButton("Batal") { _, _ -> finish() }
            .setOnCancelListener { finish() }
            .show()
    }

    private fun launchUrl(url: String) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (e: ActivityNotFoundException) {
            toast("Tidak ada aplikasi yang membuka tautan ini")
        }
        finish()
    }

    private fun candidateUrl(c: Candidate) =
        buildGoogleUrl(listOf(c.title, c.originalTitle), c.year, c.type, c.countries.firstOrNull(), c.tmdbId)

    /** Template Google bawaan (Ui.gtpl). Placeholder: {query} {title} {year} {type} {country} {tmdbId}. */
    private fun buildGoogleUrl(
        titles: List<String>,
        year: Int?,
        type: String?,
        country: String?,
        tmdbId: Int?
    ): String {
        val title = titles.map { it.trim() }.firstOrNull { it.isNotEmpty() }.orEmpty()
        val typeWord = when (type) {
            "tv" -> "drama"
            "movie" -> "film"
            else -> ""
        }
        val countryName = Actions.countryName(country)
        val yearText = year?.toString().orEmpty()
        val query = listOf(title, yearText, typeWord, countryName).filter { it.isNotEmpty() }.joinToString(" ")
        val raw = Ui.gtpl(this)
            .replace("{query}", Uri.encode(query))
            .replace("{title}", Uri.encode(title))
            .replace("{year}", Uri.encode(yearText))
            .replace("{type}", Uri.encode(typeWord))
            .replace("{country}", Uri.encode(countryName))
            .replace("{tmdbId}", Uri.encode(tmdbId?.toString().orEmpty()))
        return if (raw.contains("://")) raw else "https://$raw"
    }

    private fun loadPoster(img: ImageView, path: String) {
        Thread {
            try {
                val bmp = BitmapFactory.decodeStream(URL("https://image.tmdb.org/t/p/w185$path").openStream())
                runOnUiThread { img.setImageBitmap(bmp) }
            } catch (e: Exception) {
                Log.d(TAG, "poster gagal: ${e.message}")
            }
        }.start()
    }

    /** Dialog proses dengan tombol Batal. Batal membuang hasil pencarian tanpa membuka apa pun. */
    private fun showBusy(msg: String): AlertDialog {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dpi(24), dpi(20), dpi(24), dpi(20))
            addView(ProgressBar(this@ShareActivity))
            addView(TextView(this@ShareActivity).apply {
                text = msg
                textSize = 15f
                setPadding(dpi(16), 0, 0, 0)
            })
        }
        return AlertDialog.Builder(this)
            .setView(row)
            .setCancelable(false)
            .setNegativeButton("Batal") { _, _ ->
                cancelled = true
                finish()
            }
            .create()
            .also { it.show() }
    }

    private fun dpi(n: Int) = (n * resources.displayMetrics.density).toInt()

    private fun toast(m: String) =
        Toast.makeText(applicationContext, m, Toast.LENGTH_LONG).show()

    companion object {
        const val TAG = "Bridge"
    }
}
