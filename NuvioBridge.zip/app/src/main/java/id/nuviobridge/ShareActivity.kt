package id.nuviobridge

import android.app.Activity
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import java.net.URL

class ShareActivity : Activity() {

    private var key = ""
    private var tpl = Deeplink.DEFAULT
    private var mode = "nuvio"
    @Volatile private var cancelled = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val text = (intent.getStringExtra(Intent.EXTRA_TEXT) ?: "") + " " +
            (intent.getStringExtra(Intent.EXTRA_SUBJECT) ?: "")
        Log.d(TAG, "shared=[$text]")

        val p = getSharedPreferences(Ui.PREFS, MODE_PRIVATE)
        key = (p.getString("key", "") ?: "").trim()
        tpl = (p.getString("tpl", "") ?: "").trim().ifEmpty { Deeplink.DEFAULT }
        mode = Ui.mode(this)

        val url = MdlParser.extractUrl(text)
        if (url == null) { toast("Tautan yang dibagikan bukan dari MyDramaList."); finish(); return }
        if (key.isEmpty()) { toast("Isi TMDB API key di app MDLvia dulu"); finish(); return }

        val busy = showBusy("Menunggu verifikasi MDL & TMDB")
        Thread {
            val log = mutableListOf<String>()
            val report = try {
                Resolver(Tmdb(key), PageFetcher(this)).resolve(url, log)
            } catch (e: Exception) {
                Report(null, Decision.Fail("Error: ${e.message}"), log)
            }
            Log.d(TAG, log.joinToString("\n"))
            if (!cancelled) {
                runOnUiThread {
                    busy.dismiss()
                    handle(report)
                }
            }
        }.start()
    }

    private fun handle(report: Report) {
        when (val d = report.decision) {
            is Decision.Auto -> act(d.c)
            is Decision.Choose -> chooser(d.list)
            is Decision.Fail -> failAct(report.meta, d.reason)
        }
    }

    /** Tindakan untuk judul yang sudah dipastikan, sesuai tujuan yang dipilih. */
    private fun act(c: Candidate) {
        when (mode) {
            "google" -> launchGoogle(candidateUrl(c))
            "both" -> chooseDestination(c)
            else -> openInNuvio(c)
        }
    }

    /** Judul tidak ditemukan: Google memakai judul dari MDL. */
    private fun failAct(meta: MdlMeta?, reason: String) {
        if (meta == null || meta.allTitles().isEmpty() || reason.startsWith("TMDB error")) {
            toast(reason)
            finish()
            return
        }
        val url = buildGoogleUrl(meta.allTitles(), meta.year, meta.type, meta.country)
        if (mode == "google") {
            launchGoogle(url)
        } else {
            offerGoogle(url, "Judul tidak ditemukan di TMDB. Cari di Google?")
        }
    }

    /** Daftar pilihan dengan poster, tahun, dan tipe. Setelah dipilih, lanjut sesuai tujuan. */
    private fun chooser(list: List<Candidate>) {
        val lv = ListView(this)
        lv.adapter = object : BaseAdapter() {
            override fun getCount() = list.size
            override fun getItem(position: Int): Any = list[position]
            override fun getItemId(position: Int) = position.toLong()
            override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
                val c = list[position]
                val row = LinearLayout(this@ShareActivity).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(dpi(12), dpi(10), dpi(12), dpi(10))
                }
                val img = ImageView(this@ShareActivity).apply {
                    layoutParams = LinearLayout.LayoutParams(dpi(60), dpi(90))
                    scaleType = ImageView.ScaleType.CENTER_CROP
                    setBackgroundColor(0xFFE3E8EF.toInt())
                }
                val txt = TextView(this@ShareActivity).apply {
                    text = c.label()
                    textSize = 16f
                    setPadding(dpi(14), 0, dpi(4), 0)
                }
                row.addView(img)
                row.addView(txt)
                c.poster?.let { loadPoster(img, it) }
                return row
            }
        }
        val dlg = AlertDialog.Builder(this)
            .setTitle("Konfirmasi Judul")
            .setView(lv)
            .setNegativeButton("Batal") { _, _ -> finish() }
            .setOnCancelListener { finish() }
            .create()
        lv.setOnItemClickListener { _, _, pos, _ ->
            dlg.dismiss()
            act(list[pos])
        }
        dlg.show()
    }

    /** Mode Keduanya: pilih Nuvio, Google, atau Batal. */
    private fun chooseDestination(c: Candidate) {
        AlertDialog.Builder(this)
            .setTitle("Buka di")
            .setMessage(c.label())
            .setPositiveButton("Nuvio") { _, _ -> openInNuvio(c) }
            .setNeutralButton("Google") { _, _ -> launchGoogle(candidateUrl(c)) }
            .setNegativeButton("Batal") { _, _ -> finish() }
            .setOnCancelListener { finish() }
            .show()
    }

    private fun openInNuvio(c: Candidate) {
        Thread {
            val lookup: Pair<String?, String?> = try {
                Pair(Tmdb(key).imdbOf(c), null)
            } catch (e: Exception) {
                Pair(null, e.message ?: e.toString())
            }
            val imdb = lookup.first
            val failure = lookup.second
            runOnUiThread {
                when {
                    failure != null -> { toast(failure); finish() }
                    imdb == null -> offerGoogle(
                        candidateUrl(c),
                        "IMDb ID tidak ditemukan. Cari di Google?"
                    )
                    else -> {
                        val link = Deeplink.build(tpl, c, imdb)
                        Log.d(TAG, "link=$link")
                        try {
                            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(link)))
                        } catch (e: ActivityNotFoundException) {
                            toast("Tidak ada app yang membuka: $link")
                        }
                        finish()
                    }
                }
            }
        }.start()
    }

    /** Konfirmasi dengan dua tombol: Google dan Batal. */
    private fun offerGoogle(url: String, message: String) {
        AlertDialog.Builder(this)
            .setTitle("Cari di Google")
            .setMessage(message)
            .setPositiveButton("Google") { _, _ -> launchGoogle(url) }
            .setNegativeButton("Batal") { _, _ -> finish() }
            .setOnCancelListener { finish() }
            .show()
    }

    private fun launchGoogle(url: String) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (e: ActivityNotFoundException) {
            toast("Tidak ada browser")
        }
        finish()
    }

    private fun candidateUrl(c: Candidate) =
        buildGoogleUrl(listOf(c.title, c.originalTitle), c.year, c.type, c.countries.firstOrNull())

    /** Membuat URL Google dari template (Ui.gtpl). Semua nilai diurai agar aman dipakai di URL. */
    private fun buildGoogleUrl(titles: List<String>, year: Int?, type: String?, country: String?): String {
        val names = titles.map { it.trim() }.filter { it.isNotEmpty() }.distinct().take(3)
        val titlePart = names.joinToString(" OR ") { "\"$it\"" }
        val typeWord = when (type) {
            "tv" -> "drama"
            "movie" -> "film"
            else -> ""
        }
        val countryName = country?.let { COUNTRY_NAMES[it.uppercase()] ?: it }.orEmpty()
        val yearText = year?.toString().orEmpty()
        val query = listOf(
            if (titlePart.isNotEmpty()) "($titlePart)" else "",
            yearText,
            typeWord,
            countryName
        ).filter { it.isNotEmpty() }.joinToString(" ")
        return Ui.gtpl(this)
            .replace("{query}", Uri.encode(query))
            .replace("{title}", Uri.encode(names.firstOrNull().orEmpty()))
            .replace("{year}", Uri.encode(yearText))
            .replace("{type}", Uri.encode(typeWord))
            .replace("{country}", Uri.encode(countryName))
    }

    private fun loadPoster(img: ImageView, path: String) {
        Thread {
            try {
                val bmp = BitmapFactory.decodeStream(URL("https://image.tmdb.org/t/p/w185$path").openStream())
                runOnUiThread { img.setImageBitmap(bmp) }
            } catch (e: Exception) {
                Log.d(TAG, "poster gagal: ${e.message}")
            }
        }.start()
    }

    /** Dialog proses dengan tombol Batal. Batal membuang hasil pencarian tanpa membuka apa pun. */
    private fun showBusy(msg: String): AlertDialog {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dpi(24), dpi(20), dpi(24), dpi(20))
            addView(ProgressBar(this@ShareActivity))
            addView(TextView(this@ShareActivity).apply {
                text = msg
                textSize = 15f
                setPadding(dpi(16), 0, 0, 0)
            })
        }
        return AlertDialog.Builder(this)
            .setView(row)
            .setCancelable(false)
            .setNegativeButton("Batal") { _, _ ->
                cancelled = true
                finish()
            }
            .create()
            .also { it.show() }
    }

    private fun dpi(n: Int) = (n * resources.displayMetrics.density).toInt()

    private fun toast(m: String) =
        Toast.makeText(applicationContext, m, Toast.LENGTH_LONG).show()

    companion object {
        const val TAG = "Bridge"
        private val COUNTRY_NAMES = mapOf(
            "KR" to "South Korea", "JP" to "Japan", "CN" to "China", "TW" to "Taiwan",
            "HK" to "Hong Kong", "TH" to "Thailand", "PH" to "Philippines", "ID" to "Indonesia",
            "US" to "United States", "GB" to "United Kingdom"
        )
    }
}
