package id.nuviobridge

import android.app.Activity
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import java.net.URL

class ShareActivity : Activity() {

    private var key = ""
    private var tpl = Deeplink.DEFAULT
    @Volatile private var cancelled = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val text = (intent.getStringExtra(Intent.EXTRA_TEXT) ?: "") + " " +
            (intent.getStringExtra(Intent.EXTRA_SUBJECT) ?: "")
        Log.d(TAG, "shared=[$text]")

        val p = getSharedPreferences("cfg", MODE_PRIVATE)
        key = (p.getString("key", "") ?: "").trim()
        tpl = (p.getString("tpl", "") ?: "").trim().ifEmpty { Deeplink.DEFAULT }

        val url = MdlParser.extractUrl(text)
        if (url == null) { toast("Tautan yang dibagikan bukan dari MyDramaList."); finish(); return }
        if (key.isEmpty()) { toast("Isi TMDB API key di app MDLvia dulu"); finish(); return }

        val busy = showBusy("Menunggu verifikasi MDL & TMDB")
        Thread {
            val log = mutableListOf<String>()
            val report = try {
                Resolver(Tmdb(key), PageFetcher(this)).resolve(url, log)
            } catch (e: Exception) {
                Report(null, Decision.Fail("Error: ${e.message}"), log)
            }
            Log.d(TAG, log.joinToString("\n"))
            if (!cancelled) {
                runOnUiThread {
                    busy.dismiss()
                    handle(report)
                }
            }
        }.start()
    }

    private fun handle(report: Report) {
        when (val d = report.decision) {
            is Decision.Auto -> open(d.c)
            is Decision.Choose -> chooser(d.list)
            is Decision.Fail -> {
                val meta = report.meta
                if (meta != null && meta.allTitles().isNotEmpty() && !d.reason.startsWith("TMDB error")) {
                    offerGoogle(
                        googleQuery(meta.allTitles().take(3), meta.year, meta.type, meta.country),
                        "Judul tidak ditemukan di TMDB. Cari di Google?"
                    )
                } else {
                    toast(d.reason)
                    finish()
                }
            }
        }
    }

    /** Daftar pilihan dengan poster, tahun, dan tipe. */
    private fun chooser(list: List<Candidate>) {
        val lv = ListView(this)
        lv.adapter = object : BaseAdapter() {
            override fun getCount() = list.size
            override fun getItem(position: Int): Any = list[position]
            override fun getItemId(position: Int) = position.toLong()
            override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
                val c = list[position]
                val row = LinearLayout(this@ShareActivity).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(dpi(12), dpi(10), dpi(12), dpi(10))
                }
                val img = ImageView(this@ShareActivity).apply {
                    layoutParams = LinearLayout.LayoutParams(dpi(60), dpi(90))
                    scaleType = ImageView.ScaleType.CENTER_CROP
                    setBackgroundColor(0xFFE3E8EF.toInt())
                }
                val txt = TextView(this@ShareActivity).apply {
                    text = c.label()
                    textSize = 16f
                    setPadding(dpi(14), 0, dpi(4), 0)
                }
                row.addView(img)
                row.addView(txt)
                c.poster?.let { loadPoster(img, it) }
                return row
            }
        }
        val dlg = AlertDialog.Builder(this)
            .setTitle("Konfirmasi Judul")
            .setView(lv)
            .setNegativeButton("Batal") { _, _ -> finish() }
            .setOnCancelListener { finish() }
            .create()
        lv.setOnItemClickListener { _, _, pos, _ ->
            dlg.dismiss()
            open(list[pos])
        }
        dlg.show()
    }

    private fun loadPoster(img: ImageView, path: String) {
        Thread {
            try {
                val bmp = BitmapFactory.decodeStream(URL("https://image.tmdb.org/t/p/w185$path").openStream())
                runOnUiThread { img.setImageBitmap(bmp) }
            } catch (e: Exception) {
                Log.d(TAG, "poster gagal: ${e.message}")
            }
        }.start()
    }

    /** Dialog proses dengan tombol Batal. Batal membuang hasil pencarian tanpa membuka apa pun. */
    private fun showBusy(msg: String): AlertDialog {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dpi(24), dpi(20), dpi(24), dpi(20))
            addView(ProgressBar(this@ShareActivity))
            addView(TextView(this@ShareActivity).apply {
                text = msg
                textSize = 15f
                setPadding(dpi(16), 0, 0, 0)
            })
        }
        return AlertDialog.Builder(this)
            .setView(row)
            .setCancelable(false)
            .setNegativeButton("Batal") { _, _ ->
                cancelled = true
                finish()
            }
            .create()
            .also { it.show() }
    }

    private fun open(c: Candidate) {
        Thread {
            val lookup: Pair<String?, String?> = try {
                Pair(Tmdb(key).imdbOf(c), null)
            } catch (e: Exception) {
                Pair(null, e.message ?: e.toString())
            }
            val imdb = lookup.first
            val failure = lookup.second
            runOnUiThread {
                when {
                    failure != null -> { toast(failure); finish() }
                    imdb == null -> offerGoogle(
                        googleQuery(listOf(c.title, c.originalTitle), c.year, c.type, c.countries.firstOrNull()),
                        "IMDb ID tidak ditemukan. Cari di Google?"
                    )
                    else -> {
                        val link = Deeplink.build(tpl, c, imdb)
                        Log.d(TAG, "link=$link")
                        try {
                            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(link)))
                        } catch (e: ActivityNotFoundException) {
                            toast("Tidak ada app yang membuka: $link")
                        }
                        finish()
                    }
                }
            }
        }.start()
    }

    /** Dialog konfirmasi dengan dua tombol: Google dan Batal. Google hanya dibuka setelah dipilih. */
    private fun offerGoogle(query: String, message: String) {
        AlertDialog.Builder(this)
            .setTitle("Cari di Google")
            .setMessage(message)
            .setPositiveButton("Google") { _, _ ->
                val url = "https://www.google.com/search?q=" + Uri.encode(query)
                try {
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                } catch (e: ActivityNotFoundException) {
                    toast("Tidak ada browser")
                }
                finish()
            }
            .setNegativeButton("Batal") { _, _ -> finish() }
            .setOnCancelListener { finish() }
            .show()
    }

    /** Kueri pencarian: beberapa judul (OR), tahun, jenis, dan negara. Tanpa kata IMDb. */
    private fun googleQuery(titles: List<String>, year: Int?, type: String?, country: String?): String {
        val names = titles.map { it.trim() }.filter { it.isNotEmpty() }.distinct().take(3)
        val titlePart = names.joinToString(" OR ") { "\"$it\"" }
        val typeWord = when (type) {
            "tv" -> "drama"
            "movie" -> "film"
            else -> ""
        }
        val countryName = country?.let { COUNTRY_NAMES[it.uppercase()] ?: it } ?: ""
        val parts = listOf(
            if (titlePart.isNotEmpty()) "($titlePart)" else "",
            year?.toString() ?: "",
            typeWord,
            countryName
        )
        return parts.filter { it.isNotEmpty() }.joinToString(" ")
    }

    private fun dpi(n: Int) = (n * resources.displayMetrics.density).toInt()

    private fun toast(m: String) =
        Toast.makeText(applicationContext, m, Toast.LENGTH_LONG).show()

    companion object {
        const val TAG = "Bridge"
        private val COUNTRY_NAMES = mapOf(
            "KR" to "South Korea", "JP" to "Japan", "CN" to "China", "TW" to "Taiwan",
            "HK" to "Hong Kong", "TH" to "Thailand", "PH" to "Philippines", "ID" to "Indonesia",
            "US" to "United States", "GB" to "United Kingdom"
        )
    }
}
