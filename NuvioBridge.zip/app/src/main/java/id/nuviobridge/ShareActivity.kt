package id.nuviobridge

import android.app.Activity
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.widget.Toast

class ShareActivity : Activity() {

    private var key = ""
    private var tpl = Deeplink.DEFAULT

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val text = (intent.getStringExtra(Intent.EXTRA_TEXT) ?: "") + " " +
            (intent.getStringExtra(Intent.EXTRA_SUBJECT) ?: "")
        Log.d(TAG, "shared=[$text]")

        val p = getSharedPreferences("cfg", MODE_PRIVATE)
        key = (p.getString("key", "") ?: "").trim()
        tpl = (p.getString("tpl", "") ?: "").trim().ifEmpty { Deeplink.DEFAULT }

        val url = MdlParser.extractUrl(text)
        if (url == null) { toast("Hanya menerima link MyDramaList"); finish(); return }
        if (key.isEmpty()) { toast("Isi TMDB API key di app Nuvio Bridge dulu"); finish(); return }

        toast("Membaca halaman MDL...")
        Thread {
            val log = mutableListOf<String>()
            val report = try {
                Resolver(Tmdb(key), PageFetcher(this)).resolve(url, log)
            } catch (e: Exception) {
                Report(null, Decision.Fail("Error: ${e.message}"), log)
            }
            Log.d(TAG, log.joinToString("\n"))
            runOnUiThread { handle(report) }
        }.start()
    }

    private fun handle(report: Report) {
        when (val d = report.decision) {
            is Decision.Auto -> open(d.c)
            is Decision.Choose -> chooser(d.list)
            is Decision.Fail -> { toast(d.reason); finish() }
        }
    }

    private fun chooser(list: List<Candidate>) {
        val labels = list.map { it.label() }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Pilih judul yang benar")
            .setItems(labels) { _, i -> open(list[i]) }
            .setNegativeButton("Batal") { _, _ -> finish() }
            .setOnCancelListener { finish() }
            .show()
    }

    private fun open(c: Candidate) {
        Thread {
            var link: String? = null
            try {
                val imdb = Tmdb(key).imdbOf(c)
                    ?: throw Exception("TMDB tidak punya IMDb ID untuk ${c.title}")
                link = Deeplink.build(tpl, c, imdb)
            } catch (e: Exception) {
                runOnUiThread { toast(e.message ?: e.toString()) }
            }
            runOnUiThread {
                if (link != null) {
                    Log.d(TAG, "link=$link")
                    try {
                        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(link)))
                    } catch (e: ActivityNotFoundException) {
                        toast("Tidak ada app yang membuka: $link")
                    }
                }
                finish()
            }
        }.start()
    }

    private fun toast(m: String) =
        Toast.makeText(applicationContext, m, Toast.LENGTH_LONG).show()

    companion object { const val TAG = "Bridge" }
}
