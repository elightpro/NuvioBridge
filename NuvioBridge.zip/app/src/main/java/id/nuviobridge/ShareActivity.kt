package id.nuviobridge

import android.app.Activity
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import java.net.URL

class ShareActivity : Activity() {

    private var key = ""
    private var tpl = Deeplink.DEFAULT
    @Volatile private var cancelled = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val text = (intent.getStringExtra(Intent.EXTRA_TEXT) ?: "") + " " +
            (intent.getStringExtra(Intent.EXTRA_SUBJECT) ?: "")
        Log.d(TAG, "shared=[$text]")

        val p = getSharedPreferences("cfg", MODE_PRIVATE)
        key = (p.getString("key", "") ?: "").trim()
        tpl = (p.getString("tpl", "") ?: "").trim().ifEmpty { Deeplink.DEFAULT }

        val url = MdlParser.extractUrl(text)
        if (url == null) { toast("Tautan yang dibagikan bukan dari MyDramaList."); finish(); return }
        if (key.isEmpty()) { toast("Isi TMDB API key di app MDLvia dulu"); finish(); return }

        val busy = showBusy("Menunggu verifikasi MDL & TMDB")
        Thread {
            val log = mutableListOf<String>()
            val report = try {
                Resolver(Tmdb(key), PageFetcher(this)).resolve(url, log)
            } catch (e: Exception) {
                Report(null, Decision.Fail("Error: ${e.message}"), log)
            }
            Log.d(TAG, log.joinToString("\n"))
            if (!cancelled) {
                runOnUiThread {
                    busy.dismiss()
                    handle(report)
                }
            }
        }.start()
    }

    private fun handle(report: Report) {
        when (val d = report.decision) {
            is Decision.Auto -> open(d.c)
            is Decision.Choose -> chooser(d.list)
            is Decision.Fail -> { toast(d.reason); finish() }
        }
    }

    /** Daftar pilihan dengan poster, tahun, dan tipe. */
    private fun chooser(list: List<Candidate>) {
        val lv = ListView(this)
        lv.adapter = object : BaseAdapter() {
            override fun getCount() = list.size
            override fun getItem(position: Int): Any = list[position]
            override fun getItemId(position: Int) = position.toLong()
            override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
                val c = list[position]
                val row = LinearLayout(this@ShareActivity).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(dpi(12), dpi(10), dpi(12), dpi(10))
                }
                val img = ImageView(this@ShareActivity).apply {
                    layoutParams = LinearLayout.LayoutParams(dpi(60), dpi(90))
                    scaleType = ImageView.ScaleType.CENTER_CROP
                    setBackgroundColor(0xFFE3E8EF.toInt())
                }
                val txt = TextView(this@ShareActivity).apply {
                    text = c.label()
                    textSize = 16f
                    setPadding(dpi(14), 0, dpi(4), 0)
                }
                row.addView(img)
                row.addView(txt)
                c.poster?.let { loadPoster(img, it) }
                return row
            }
        }
        val dlg = AlertDialog.Builder(this)
            .setTitle("Konfirmasi Judul")
            .setView(lv)
            .setNegativeButton("Batal") { _, _ -> finish() }
            .setOnCancelListener { finish() }
            .create()
        lv.setOnItemClickListener { _, _, pos, _ ->
            dlg.dismiss()
            open(list[pos])
        }
        dlg.show()
    }

    private fun loadPoster(img: ImageView, path: String) {
        Thread {
            try {
                val bmp = BitmapFactory.decodeStream(URL("https://image.tmdb.org/t/p/w185$path").openStream())
                runOnUiThread { img.setImageBitmap(bmp) }
            } catch (e: Exception) {
                Log.d(TAG, "poster gagal: ${e.message}")
            }
        }.start()
    }

    /** Dialog proses dengan tombol Batal. Batal membuang hasil pencarian tanpa membuka apa pun. */
    private fun showBusy(msg: String): AlertDialog {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dpi(24), dpi(20), dpi(24), dpi(20))
            addView(ProgressBar(this@ShareActivity))
            addView(TextView(this@ShareActivity).apply {
                text = msg
                textSize = 15f
                setPadding(dpi(16), 0, 0, 0)
            })
        }
        return AlertDialog.Builder(this)
            .setView(row)
            .setCancelable(false)
            .setNegativeButton("Batal") { _, _ ->
                cancelled = true
                finish()
            }
            .create()
            .also { it.show() }
    }

    private fun open(c: Candidate) {
        Thread {
            var link: String? = null
            try {
                val imdb = Tmdb(key).imdbOf(c)
                    ?: throw Exception("Belum ada IMDb ID untuk ${c.title} di TMDB. Judul belum tayang / belum diperbarui.")
                link = Deeplink.build(tpl, c, imdb)
            } catch (e: Exception) {
                runOnUiThread { toast(e.message ?: e.toString()) }
            }
            runOnUiThread {
                if (link != null) {
                    Log.d(TAG, "link=$link")
                    try {
                        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(link)))
                    } catch (e: ActivityNotFoundException) {
                        toast("Tidak ada app yang membuka: $link")
                    }
                }
                finish()
            }
        }.start()
    }

    private fun dpi(n: Int) = (n * resources.displayMetrics.density).toInt()

    private fun toast(m: String) =
        Toast.makeText(applicationContext, m, Toast.LENGTH_LONG).show()

    companion object { const val TAG = "Bridge" }
}
