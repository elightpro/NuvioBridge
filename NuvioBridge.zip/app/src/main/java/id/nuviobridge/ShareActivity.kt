package id.nuviobridge

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

class ShareActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val text = (intent.getStringExtra(Intent.EXTRA_TEXT) ?: "") + " " +
            (intent.getStringExtra(Intent.EXTRA_SUBJECT) ?: "")
        Log.d(TAG, "shared=[$text]")

        val p = getSharedPreferences("cfg", MODE_PRIVATE)
        val key = (p.getString("key", "") ?: "").trim()
        val tpl = (p.getString("tpl", "") ?: "").trim()
        if (tpl.isEmpty()) {
            toast("Isi template deep link dulu di app Nuvio Bridge")
            finish(); return
        }

        Thread {
            var link: String? = null
            try {
                link = resolve(text, key, tpl)
            } catch (e: Exception) {
                Log.e(TAG, "resolve gagal", e)
                runOnUiThread { toast(e.message ?: e.toString()) }
            }
            runOnUiThread {
                if (link != null) {
                    Log.d(TAG, "link=$link")
                    try {
                        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(link)))
                    } catch (e: ActivityNotFoundException) {
                        toast("Tidak ada app yang membuka: $link")
                    }
                }
                finish()
            }
        }.start()
    }

    private fun resolve(text: String, key: String, tpl: String): String {
        var type: String? = null   // "movie" | "tv"
        var tmdb: Int? = null
        var imdb: String? = null

        val tmdbUrl = Regex("themoviedb\\.org/(movie|tv)/(\\d+)").find(text)
        val mdbl = Regex("mdblist\\.com/(movie|show)/(tt\\d+)").find(text)
        val mdl = Regex("mydramalist\\.com/\\d+-([a-z0-9-]+)").find(text)
        val tt = Regex("tt\\d{6,}").find(text)?.value

        when {
            tmdbUrl != null -> {
                type = tmdbUrl.groupValues[1]; tmdb = tmdbUrl.groupValues[2].toInt()
            }
            mdbl != null -> {
                type = if (mdbl.groupValues[1] == "show") "tv" else "movie"
                imdb = mdbl.groupValues[2]
            }
            mdl != null -> {
                if (key.isEmpty()) throw Exception("Link MDL butuh TMDB API key (isi di app)")
                val slug = mdl.groupValues[1]
                val hit = searchSmart(slug, key)
                    ?: throw Exception("Tidak ketemu di TMDB: ${slug.replace('-', ' ')}")
                type = hit.first; tmdb = hit.second
            }
            tt != null -> imdb = tt
            else -> throw Exception("Link tidak dikenali")
        }

        val needTmdb = tpl.contains("{tmdb}")
        val needImdb = tpl.contains("{imdb}")
        val needType = tpl.contains("{type}") || tpl.contains("{tmdbtype}")

        if (tmdb == null && (needTmdb || (type == null && needType))) {
            if (key.isEmpty()) throw Exception("Butuh TMDB API key untuk konversi ID")
            val f = tmdbGet("find/$imdb?external_source=imdb_id", key)
            val m = f.optJSONArray("movie_results")
            val t = f.optJSONArray("tv_results")
            when {
                m != null && m.length() > 0 -> { type = "movie"; tmdb = m.getJSONObject(0).getInt("id") }
                t != null && t.length() > 0 -> { type = "tv"; tmdb = t.getJSONObject(0).getInt("id") }
                else -> throw Exception("$imdb tidak ada di TMDB")
            }
        }
        if (imdb == null && needImdb) {
            if (key.isEmpty() || tmdb == null || type == null)
                throw Exception("Tidak bisa dapat ID IMDb (cek TMDB API key)")
            imdb = tmdbGet("$type/$tmdb/external_ids", key).optString("imdb_id")
            if (imdb.isNullOrEmpty()) throw Exception("TMDB tidak punya ID IMDb untuk judul ini")
        }

        val nuvioType = if (type == "tv") "series" else "movie"
        return tpl
            .replace("{tmdb}", tmdb?.toString() ?: "")
            .replace("{imdb}", imdb ?: "")
            .replace("{tmdbtype}", type ?: "")
            .replace("{type}", nuvioType)
    }

    private fun searchSmart(slug: String, key: String): Pair<String, Int>? {
        val w = slug.split('-').filter { it.isNotBlank() }
        val variants = listOf(
            w.joinToString(" "),
            w.dropLast(1).joinToString(" "),
            w.take(2).joinToString(" ")
        ).filter { it.isNotBlank() }.distinct()
        for (q in variants) {
            val r = tmdbGet("search/multi?query=${URLEncoder.encode(q, "UTF-8")}", key)
                .optJSONArray("results") ?: continue
            for (i in 0 until r.length()) {
                val o = r.getJSONObject(i)
                val t = o.optString("media_type")
                if (t == "tv" || t == "movie") return t to o.getInt("id")
            }
        }
        return null
    }

    private fun tmdbGet(path: String, key: String): JSONObject {
        val bearer = key.startsWith("eyJ")
        val sep = if (path.contains("?")) "&" else "?"
        val url = "https://api.themoviedb.org/3/$path" + if (bearer) "" else "${sep}api_key=$key"
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 10000
        c.readTimeout = 10000
        if (bearer) c.setRequestProperty("Authorization", "Bearer $key")
        if (c.responseCode !in 200..299) throw Exception("TMDB HTTP ${c.responseCode} (cek API key)")
        return JSONObject(c.inputStream.bufferedReader().use { it.readText() })
    }

    private fun toast(m: String) =
        Toast.makeText(applicationContext, m, Toast.LENGTH_LONG).show()

    companion object { const val TAG = "Bridge" }
}
