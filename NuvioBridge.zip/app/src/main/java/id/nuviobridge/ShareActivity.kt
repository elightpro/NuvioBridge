package id.nuviobridge

import android.app.Activity
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import java.net.URL

class ShareActivity : Activity() {

    private var key = ""
    private var tpl = Deeplink.DEFAULT
    private var mode = "nuvio"
    private var busy: AlertDialog? = null
    private var busyText: TextView? = null
    @Volatile private var cancelled = false

    // Dialog aksi yang dipertahankan (toggle "Pertahankan dialog aksi")
    private var resumeSheet = false
    private var sheetOptions: List<Action> = emptyList()
    private var sheetTarget: Target? = null
    private var sheetCandidate: Candidate? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val text = (intent.getStringExtra(Intent.EXTRA_TEXT) ?: "") + " " +
            (intent.getStringExtra(Intent.EXTRA_SUBJECT) ?: "")
        Log.d(TAG, "shared=[$text]")

        val p = getSharedPreferences(Ui.PREFS, MODE_PRIVATE)
        key = (p.getString("key", "") ?: "").trim()
        tpl = (p.getString("tpl", "") ?: "").trim().ifEmpty { Deeplink.DEFAULT }
        mode = Ui.mode(this)

        val url = MdlParser.extractUrl(text)
        if (url == null) { toast("Tautan yang dibagikan bukan dari MyDramaList."); finish(); return }
        if (key.isEmpty()) { toast("Isi TMDB API key di app MDLvia dulu"); finish(); return }

        // Cache: judul yang sudah dipastikan otomatis tidak perlu dicari ulang
        val mdlId = DecisionCache.mdlId(url)
        val cached = mdlId?.let { DecisionCache.getCandidate(this, it) }
        if (cached != null) {
            Log.d(TAG, "cache hit mdl:$mdlId")
            act(cached)
            return
        }

        currentUrl = url
        currentMdlId = mdlId
        resolveAgain()
    }

    private fun resolveAgain() {
        val url = currentUrl ?: return
        val mdlId = currentMdlId
        showBusy("Analisis MDL...")
        Thread {
            val log = mutableListOf<String>()
            val report = try {
                Resolver(Tmdb(key), PageFetcher(this)).resolve(url, log) { msg -> postStage(msg) }
            } catch (e: Exception) {
                Report(null, Decision.Fail("Error: ${e.message}"), log)
            }
            Log.d(TAG, log.joinToString("\n"))
            val d = report.decision
            if (d is Decision.Auto && mdlId != null) DecisionCache.putCandidate(this, mdlId, d.c)
            if (!cancelled && !isFinishing) runOnUiThread { handle(report) }
        }.start()
    }


    private var currentUrl: String? = null
    private var currentMdlId: String? = null

    /** Dialog aksi dibuka lagi setelah kembali dari tujuan (hanya kalau toggle aktif). */
    override fun onResume() {
        super.onResume()
        if (resumeSheet && !isFinishing) {
            resumeSheet = false
            val t = sheetTarget
            if (t == null) { finish(); return }
            showSheet(sheetOptions, t, sheetCandidate, again = true)
        }
    }

    private fun postStage(msg: String) {
        if (!cancelled && !isFinishing) runOnUiThread { busyText?.text = msg }
    }

    /** Dialog proses dengan tombol Batal. Batal membuang hasil tanpa membuka apa pun. */
    private fun showBusy(msg: String) {
        val tv = TextView(this).apply {
            text = msg
            textSize = 15f
            setTextColor(Ui.pal(context).text)
            setPadding(dpi(16), 0, 0, 0)
        }
        busyText = tv
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dpi(24), dpi(20), dpi(24), dpi(20))
            addView(ArcSpinnerView(this@ShareActivity, Ui.pal(this@ShareActivity).primary), LinearLayout.LayoutParams(dpi(28), dpi(28)))
            addView(tv)
        }
        busy = Ui.dialog(this)
            .setView(row)
            .setCancelable(false)
            .setNegativeButton("Batal") { _, _ ->
                cancelled = true
                finish()
            }
            .create()
            .also { it.show() }
    }

    private fun setBusy(msg: String) {
        if (busy == null) showBusy(msg) else busyText?.text = msg
    }

    private fun dismissBusy() {
        try { busy?.dismiss() } catch (e: Exception) { Log.d(TAG, "dismiss: ${e.message}") }
        busy = null
        busyText = null
    }

    private fun handle(report: Report) {
        when (val d = report.decision) {
            is Decision.Auto -> act(d.c)
            is Decision.Choose -> chooser(d.list)
            is Decision.Fail -> if (d.reason.startsWith("Halaman MDL tidak bisa dibaca")) pageFailDialog()
                                else failAct(report.meta, d.reason)
        }
    }

    private fun pageFailDialog() {
        dismissBusy()
        Ui.dialog(this)
            .setTitle("Halaman MDL Tidak Terbaca")
            .setPositiveButton("Coba Lagi") { _, _ -> resolveAgain() }
            .setOnCancelListener { finish() }
            .show()
    }

    /** Judul sudah dipastikan (dari TMDB atau cache). */
    private fun act(c: Candidate) {
        when (mode) {
            "google" -> {
                dismissBusy()
                launchUrl(candidateUrl(c))
            }
            "both" -> {
                setBusy("Mengambil data tambahan...")
                Thread {
                    val t = targetFor(c)
                    runOnUiThread { if (!cancelled) pickAction(t, c) }
                }.start()
            }
            else -> openInNuvio(c)
        }
    }

    /** Judul tidak ditemukan di TMDB: hanya data dari MDL yang tersedia. */
    private fun failAct(meta: MdlMeta?, reason: String) {
        dismissBusy()
        if (meta == null || meta.allTitles().isEmpty() || reason.startsWith("TMDB error")) {
            toast(reason)
            finish()
            return
        }
        when (mode) {
            "google" -> launchUrl(buildGoogleUrl(meta.allTitles(), meta.year, meta.type, meta.country, null))
            "both" -> pickAction(metaTarget(meta), null)
            else -> offerGoogle(
                buildGoogleUrl(meta.allTitles(), meta.year, meta.type, meta.country, null),
                "Judul tidak ditemukan di TMDB. Cari di Google?"
            )
        }
    }

    /** Daftar pilihan dengan poster, tahun, dan tipe. */
    private fun chooser(list: List<Candidate>) {
        dismissBusy()
        val lv = ListView(this)
        lv.adapter = object : BaseAdapter() {
            override fun getCount() = list.size
            override fun getItem(position: Int): Any = list[position]
            override fun getItemId(position: Int) = position.toLong()
            override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
                val c = list[position]
                val row = LinearLayout(this@ShareActivity).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(dpi(12), dpi(10), dpi(12), dpi(10))
                }
                val img = ImageView(this@ShareActivity).apply {
                    layoutParams = LinearLayout.LayoutParams(dpi(60), dpi(90))
                    scaleType = ImageView.ScaleType.CENTER_CROP
                    setBackgroundColor(0xFFE3E8EF.toInt())
                }
                val txt = TextView(this@ShareActivity).apply {
                    text = c.label()
                    textSize = 16f
                    setTextColor(Ui.pal(context).text)
                    setPadding(dpi(14), 0, dpi(4), 0)
                }
                row.addView(img)
                row.addView(txt)
                c.poster?.let { loadPoster(img, it) }
                return row
            }
        }
        val dlg = Ui.dialog(this)
            .setTitle("Konfirmasi Judul")
            .setView(lv)
            .setNegativeButton("Batal") { _, _ -> finish() }
            .setOnCancelListener { finish() }
            .create()
        lv.setOnItemClickListener { _, _, pos, _ ->
            dlg.dismiss()
            act(list[pos])
        }
        dlg.show()
    }

    /** Mode All Actions: daftar aksi yang aktif dan tersedia untuk judul ini. */
    private fun pickAction(t: Target, c: Candidate?) {
        dismissBusy()
        val all = Actions.load(this)
        val options = all.filter { it.enabled && Actions.available(it, t) }
        when {
            options.isEmpty() && all.none { it.enabled } -> {
                // 0 aksi aktif: arahkan ke Pengaturan
                Ui.dialog(this)
                    .setTitle("Tidak Ada Aksi Aktif. Aktifkan di Pengaturan.")
                    .setPositiveButton("Buka Pengaturan") { _, _ ->
                        startActivity(Intent(this, GearActivity::class.java))
                        finish()
                    }
                    .setNegativeButton("Batal") { _, _ -> finish() }
                    .setOnCancelListener { finish() }
                    .show()
            }
            options.isEmpty() -> {
                // ada aksi aktif, tetapi tidak ada yang cocok dengan judul ini
                val url = buildGoogleUrl(t.titles, t.year, t.type, t.country, t.tmdbId)
                Ui.dialog(this)
                    .setTitle("Tidak Ada Aksi yang Cocok")
                    .setPositiveButton("Cari di Google") { _, _ -> launchUrl(url) }
                    .setNegativeButton("Batal") { _, _ -> finish() }
                    .setOnCancelListener { finish() }
                    .show()
            }
            options.size == 1 && directSingle() -> {
                // 1 aksi: langsung dibuka tanpa dialog
                runAction(options[0], t, c, keep = false)
            }
            else -> {
                sheetOptions = options
                sheetTarget = t
                sheetCandidate = c
                showSheet(options, t, c, again = false)
            }
        }
    }

    /**
     * Menampilkan daftar aksi. again = true berarti dialog kedua (setelah kembali dari tujuan),
     * yang selalu menutup MDLvia setelah dipilih.
     */
    private fun showSheet(options: List<Action>, t: Target, c: Candidate?, again: Boolean) {
        val textColor = Ui.pal(this).text
        val lv = ListView(this)
        lv.adapter = object : BaseAdapter() {
            override fun getCount() = options.size
            override fun getItem(position: Int): Any = options[position]
            override fun getItemId(position: Int) = position.toLong()
            override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
                val a = options[position]
                val row = LinearLayout(this@ShareActivity).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(dpi(16), dpi(14), dpi(16), dpi(14))
                }
                row.addView(ActionIconView(this@ShareActivity, a.icon, textColor),
                    LinearLayout.LayoutParams(dpi(26), dpi(26)))
                row.addView(LinearLayout(this@ShareActivity).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(dpi(14), 0, 0, 0)
                    addView(TextView(this@ShareActivity).apply {
                        text = a.name
                        textSize = 16f
                        setTextColor(textColor)
                    })
                    addView(TextView(this@ShareActivity).apply {
                        text = if (a.builtin != null) "Default" else a.template
                        textSize = 11f
                        setTextColor(Ui.pal(this@ShareActivity).muted)
                        maxLines = 1
                        ellipsize = android.text.TextUtils.TruncateAt.END
                    })
                })
                return row
            }
        }
        val dlg = Ui.dialog(this)
            .setTitle("Buka Dengan")
            .setView(lv)
            .setNegativeButton("Batal") { _, _ -> finish() }
            .setOnCancelListener { finish() }
            .create()
        lv.setOnItemClickListener { _, _, pos, _ ->
            dlg.dismiss()
            val keep = !again && getSharedPreferences(Ui.PREFS, MODE_PRIVATE).getBoolean("keep_sheet", true)
            runAction(options[pos], t, c, keep)
        }
        dlg.show()
    }

    /** keep = true: tujuan dibuka tanpa menutup MDLvia, dialog akan muncul lagi saat kembali. */
    private fun runAction(a: Action, t: Target, c: Candidate?, keep: Boolean) {
        val url: String? = when (a.builtin) {
            "nuvio" -> {
                val imdb = t.imdbId
                if (c != null && imdb != null) Deeplink.build(tpl, c, imdb) else null
            }
            "google" -> buildGoogleUrl(t.titles, t.year, t.type, t.country, t.tmdbId)
            else -> Actions.fill(a.template, t)
        }
        if (url == null) {
            toast("Aksi tidak tersedia untuk judul ini")
            finish()
            return
        }
        Log.d(TAG, "aksi=${a.name} url=$url keep=$keep")
        if (keep) {
            resumeSheet = true
            launchWithoutClosing(url)
        } else {
            launchUrl(url)
        }
    }

    /** Membuka tujuan tanpa menutup MDLvia. */
    private fun launchWithoutClosing(url: String) {
        dismissBusy()
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (e: ActivityNotFoundException) {
            resumeSheet = false
            noAppToast(url)
            finish()
        }
    }

    /** IMDb dan TVDB dari cache atau TMDB. Hasil disimpan sesuai masa berlakunya. */
    private fun idsFor(c: Candidate): Pair<String?, Int?> {
        val k = "${c.type}:${c.tmdbId}"
        DecisionCache.getIds(this, k)?.let { return it }
        val j = Tmdb(key).externalIds(c)
        val imdb = j.optString("imdb_id").takeIf { it.startsWith("tt") }
        val tvdb = j.optInt("tvdb_id", 0).takeIf { it > 0 }
        DecisionCache.putIds(this, k, imdb, tvdb)
        return Pair(imdb, tvdb)
    }

    private fun targetFor(c: Candidate): Target {
        val ids: Pair<String?, Int?> = try {
            idsFor(c)
        } catch (e: Exception) {
            Log.d(TAG, "ids gagal: ${e.message}")
            Pair(null, null)
        }
        return Target(
            titles = listOf(c.title, c.originalTitle),
            year = c.year,
            type = c.type,
            country = c.countries.firstOrNull(),
            tmdbId = c.tmdbId,
            imdbId = ids.first,
            tvdbId = ids.second
        )
    }

    private fun metaTarget(meta: MdlMeta) = Target(
        titles = meta.allTitles(),
        year = meta.year,
        type = meta.type,
        country = meta.country,
        tmdbId = null,
        imdbId = null,
        tvdbId = null
    )

    /** Mode Nuvio: buka deep link Nuvio; kalau IMDb ID tidak ada, tawarkan Google. */
    private fun openInNuvio(c: Candidate) {
        setBusy("Mengambil data tambahan...")
        Thread {
            var imdb: String? = null
            var failure: String? = null
            try {
                imdb = idsFor(c).first
            } catch (e: Exception) {
                failure = e.message ?: e.toString()
            }
            val foundImdb = imdb
            val foundFailure = failure
            runOnUiThread {
                if (cancelled) return@runOnUiThread
                dismissBusy()
                when {
                    foundFailure != null -> { toast(foundFailure); finish() }
                    foundImdb == null -> offerGoogle(
                        candidateUrl(c),
                        "IMDb ID tidak ditemukan. Cari di Google?"
                    )
                    else -> {
                        val link = Deeplink.build(tpl, c, foundImdb)
                        Log.d(TAG, "link=$link")
                        launchUrl(link)
                    }
                }
            }
        }.start()
    }

    /** Konfirmasi dengan dua tombol: Google dan Batal. */
    private fun offerGoogle(url: String, message: String) {
        dismissBusy()
        Ui.dialog(this)
            .setTitle("Cari di Google")
            .setMessage(message)
            .setPositiveButton("Google") { _, _ -> launchUrl(url) }
            .setNegativeButton("Batal") { _, _ -> finish() }
            .setOnCancelListener { finish() }
            .show()
    }

    private fun directSingle(): Boolean =
        getSharedPreferences(Ui.PREFS, MODE_PRIVATE).getBoolean("direct_single", true)

    private fun noAppToast(url: String) =
        toast(if (url.startsWith("nuvio://")) "Nuvio Belum Terpasang." else "Tidak ada aplikasi yang membuka tautan ini")

    private fun launchUrl(url: String) {
        dismissBusy()
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (e: ActivityNotFoundException) {
            noAppToast(url)
        }
        finish()
    }

    private fun candidateUrl(c: Candidate) =
        buildGoogleUrl(listOf(c.title, c.originalTitle), c.year, c.type, c.countries.firstOrNull(), c.tmdbId)

    /** Template Google (Ui.gtpl). Placeholder: {query} {title} {year} {type} {country} {tmdbId}. */
    private fun buildGoogleUrl(
        titles: List<String>,
        year: Int?,
        type: String?,
        country: String?,
        tmdbId: Int?
    ): String {
        val title = titles.map { it.trim() }.firstOrNull { it.isNotEmpty() }.orEmpty()
        val typeWord = when (type) {
            "tv" -> "drama"
            "movie" -> "film"
            else -> ""
        }
        val countryName = Actions.countryName(country)
        val yearText = year?.toString().orEmpty()
        val query = listOf(title, yearText, typeWord, countryName).filter { it.isNotEmpty() }.joinToString(" ")
        val raw = Ui.gtpl(this)
            .replace("{query}", Uri.encode(query))
            .replace("{title}", Uri.encode(title))
            .replace("{year}", Uri.encode(yearText))
            .replace("{type}", Uri.encode(typeWord))
            .replace("{country}", Uri.encode(countryName))
            .replace("{tmdbId}", Uri.encode(tmdbId?.toString().orEmpty()))
        return if (raw.contains("://")) raw else "https://$raw"
    }

    private fun loadPoster(img: ImageView, path: String) {
        Thread {
            try {
                val bmp = BitmapFactory.decodeStream(URL("https://image.tmdb.org/t/p/w185$path").openStream())
                runOnUiThread { img.setImageBitmap(bmp) }
            } catch (e: Exception) {
                Log.d(TAG, "poster gagal: ${e.message}")
            }
        }.start()
    }

    private fun dpi(n: Int) = (n * resources.displayMetrics.density).toInt()

    private fun toast(m: String) =
        Toast.makeText(applicationContext, m, Toast.LENGTH_LONG).show()

    companion object {
        const val TAG = "Bridge"
    }
}
