package id.nuviobridge

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

class Tmdb(private val key: String) {

    fun find(imdb: String): List<Candidate> {
        val j = get("find/$imdb?external_source=imdb_id&language=en-US")
        val out = ArrayList<Candidate>()
        out.addAll(parse(j.optJSONArray("movie_results"), "movie"))
        out.addAll(parse(j.optJSONArray("tv_results"), "tv"))
        return out
    }

    fun search(type: String, q: String): List<Candidate> {
        val j = get("search/$type?query=${URLEncoder.encode(q, "UTF-8")}&include_adult=false&language=en-US&page=1")
        return parse(j.optJSONArray("results"), type).take(6)
    }

    fun imdbOf(c: Candidate): String? {
        val j = get("${c.type}/${c.tmdbId}/external_ids")
        val id = j.optString("imdb_id")
        return if (id.startsWith("tt")) id else null
    }

    private fun parse(arr: JSONArray?, type: String): List<Candidate> {
        if (arr == null) return emptyList()
        val out = ArrayList<Candidate>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val tv = type == "tv"
            val title = if (tv) o.optString("name") else o.optString("title")
            val orig = if (tv) o.optString("original_name") else o.optString("original_title")
            val date = if (tv) o.optString("first_air_date") else o.optString("release_date")
            val cs = ArrayList<String>()
            val a = o.optJSONArray("origin_country")
            if (a != null) for (j in 0 until a.length()) cs.add(a.getString(j))
            val lang = o.optString("original_language")
            out.add(
                Candidate(
                    type = type, tmdbId = o.getInt("id"), title = title, originalTitle = orig,
                    year = date.take(4).toIntOrNull(),
                    lang = if (lang.isEmpty()) null else lang, countries = cs,
                    poster = o.optString("poster_path").takeIf { it.isNotEmpty() && it != "null" }
                )
            )
        }
        return out
    }

    private fun get(path: String): JSONObject {
        val bearer = key.startsWith("eyJ")
        val sep = if (path.contains("?")) "&" else "?"
        val url = "https://api.themoviedb.org/3/$path" + if (bearer) "" else "${sep}api_key=$key"
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 10000
        c.readTimeout = 10000
        if (bearer) c.setRequestProperty("Authorization", "Bearer $key")
        if (c.responseCode !in 200..299) throw Exception("TMDB HTTP ${c.responseCode} (cek API key)")
        return JSONObject(c.inputStream.bufferedReader().use { it.readText() })
    }
}
