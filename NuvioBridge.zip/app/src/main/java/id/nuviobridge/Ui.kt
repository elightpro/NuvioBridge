package id.nuviobridge

import android.app.AlertDialog
import android.content.Context
import android.view.Gravity
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.drawable.GradientDrawable
import android.util.TypedValue
import android.view.View
import android.view.ViewGroup
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class Pal(val bg: Int, val card: Int, val text: Int, val muted: Int, val primary: Int, val second: Int,
               val nuvio: Int, val mdl: Int)

object Ui {
    const val PREFS = "cfg"
    val COLOR_OK = Color.parseColor("#2E7D32")
    val COLOR_BAD = Color.parseColor("#C62828")
    val COLOR_WARN = Color.parseColor("#EF6C00")

    /** Aplikasi selalu memakai tampilan terang, tidak mengikuti mode gelap sistem. */
    fun pal(ctx: Context): Pal = Pal(
        bg = Color.parseColor("#F5F6F8"), card = Color.parseColor("#FFFFFF"),
        text = Color.parseColor("#1B1F24"), muted = Color.parseColor("#5F6B7A"),
        primary = Color.parseColor("#1565C0"), second = Color.parseColor("#E3E8EF"),
        nuvio = Color.parseColor("#4A2A7A"), mdl = Color.parseColor("#1565C0")
    )

    fun px(ctx: Context, n: Int): Int = (n * ctx.resources.displayMetrics.density).toInt()

    fun rounded(ctx: Context, color: Int, radiusDp: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = px(ctx, radiusDp).toFloat()
    }

    fun card(ctx: Context, pal: Pal): LinearLayout = LinearLayout(ctx).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(px(ctx, 14), px(ctx, 14), px(ctx, 14), px(ctx, 14))
        background = rounded(ctx, pal.card, 12)
    }

    fun addTop(parent: LinearLayout, v: View, topDp: Int = 8) {
        val ctx = parent.context
        parent.addView(v, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            .apply { topMargin = px(ctx, topDp) })
    }

    fun section(ctx: Context, pal: Pal, t: String): TextView = TextView(ctx).apply {
        text = t
        textSize = 12f
        setTextColor(pal.muted)
        typeface = Typeface.DEFAULT_BOLD
        letterSpacing = 0.08f
    }

    fun label(ctx: Context, pal: Pal, t: String): TextView = TextView(ctx).apply {
        text = t
        textSize = 13f
        setTextColor(pal.muted)
    }

    fun button(ctx: Context, pal: Pal, caption: String, primary: Boolean, onClick: () -> Unit): Button = Button(ctx).apply {
        text = caption
        isAllCaps = false
        setTextColor(if (primary) Color.WHITE else pal.text)
        background = rounded(ctx, if (primary) pal.primary else pal.second, 10)
        setOnClickListener { onClick() }
    }

    // ---------- ukuran teks: nilai dasar disimpan sekali, lalu dikalikan faktor ----------
    fun scaleValue(ctx: Context): Float =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("scale", "1.0")?.toFloatOrNull() ?: 1f

    fun applyScale(v: View, factor: Float) {
        if (v is TextView) {
            if (v.tag !is Float) v.tag = v.textSize / v.resources.displayMetrics.scaledDensity
            v.setTextSize(TypedValue.COMPLEX_UNIT_SP, (v.tag as Float) * factor)
        }
        if (v is ViewGroup) for (i in 0 until v.childCount) applyScale(v.getChildAt(i), factor)
    }

    // ---------- tujuan share & template Google ----------
    const val DEFAULT_GTPL = "https://www.google.com/search?q={query}"

    /** nuvio | google | both */
    fun mode(ctx: Context): String =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("mode", "nuvio") ?: "nuvio"

    fun gtpl(ctx: Context): String {
        val t = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("gtpl", DEFAULT_GTPL)
            ?.trim().orEmpty()
        return if (t.isNotEmpty()) t else DEFAULT_GTPL
    }

    // ---------- komponen tampilan (rapi & konsisten) ----------

    /** Dialog yang mengikuti palet mode gelap/terang. */
    fun dialog(ctx: Context): AlertDialog.Builder =
        AlertDialog.Builder(ctx, R.style.MdlDialogLight)

    /** Tombol berbahaya (merah): reset dan hapus. */
    fun dangerButton(ctx: Context, caption: String, onClick: () -> Unit): Button = Button(ctx).apply {
        text = caption
        isAllCaps = false
        setTextColor(Color.WHITE)
        background = rounded(ctx, COLOR_BAD, 10)
        setOnClickListener { onClick() }
    }

    /** Tombol kecil persegi, untuk ▲ ▼ ✎ di daftar aksi. */
    fun miniButton(ctx: Context, pal: Pal, caption: String, onClick: () -> Unit): TextView = TextView(ctx).apply {
        text = caption
        textSize = 15f
        setTextColor(pal.text)
        gravity = Gravity.CENTER
        background = rounded(ctx, pal.second, 8)
        minWidth = px(ctx, 36)
        minHeight = px(ctx, 36)
        setOnClickListener { onClick() }
    }

    /** Baris label di kiri dan status kecil di kanan. */
    fun labelRow(ctx: Context, pal: Pal, label: String, right: TextView): LinearLayout = LinearLayout(ctx).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        addView(TextView(ctx).apply {
            text = label
            textSize = 13f
            setTextColor(pal.muted)
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        addView(right, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
    }

    /** Pilihan berbentuk segmen: satu baris tombol, yang aktif diberi ✓. */
    fun segmentRow(ctx: Context, pal: Pal, labels: List<String>, selected: () -> Int, onPick: (Int) -> Unit): LinearLayout {
        val row = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        val buttons = mutableListOf<Button>()
        fun refresh() {
            val cur = selected()
            buttons.forEachIndexed { i, b ->
                val on = i == cur
                b.text = (if (on) "✓ " else "") + labels[i]
                b.background = rounded(ctx, if (on) pal.primary else pal.second, 10)
                b.setTextColor(if (on) Color.WHITE else pal.text)
            }
        }
        labels.forEachIndexed { i, label ->
            val b = Button(ctx).apply {
                textSize = 13f
                isAllCaps = false
                text = label
                setOnClickListener {
                    onPick(i)
                    refresh()
                }
            }
            buttons.add(b)
            row.addView(b, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                if (i > 0) leftMargin = px(ctx, 4)
            })
        }
        refresh()
        return row
    }

    /** Bagian yang bisa dilipat: judul dengan chevron, isi disembunyikan saat tertutup. */
    fun collapsible(ctx: Context, pal: Pal, title: String, open: Boolean, body: View): LinearLayout {
        val wrap = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        body.visibility = if (open) View.VISIBLE else View.GONE
        val chevron = ChevronView(ctx, open, pal.muted)
        val label = TextView(ctx).apply {
            text = title
            textSize = 12f
            setTextColor(pal.muted)
            typeface = Typeface.DEFAULT_BOLD
            letterSpacing = 0.08f
        }
        val header = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, px(ctx, 20), 0, 0)
            addView(chevron, LinearLayout.LayoutParams(px(ctx, 16), px(ctx, 16)).apply { rightMargin = px(ctx, 6) })
            addView(label)
        }
        header.setOnClickListener {
            val nowOpen = body.visibility != View.VISIBLE
            body.visibility = if (nowOpen) View.VISIBLE else View.GONE
            chevron.open = nowOpen
            chevron.invalidate()
        }
        wrap.addView(header)
        wrap.addView(body, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = px(ctx, 8)
        })
        return wrap
    }
}

/** Chevron: ⌄ saat terbuka, › saat tertutup. Digambar langsung. */
class ChevronView(ctx: Context, var open: Boolean, private val color: Int) : View(ctx) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        this.color = this@ChevronView.color
        style = Paint.Style.STROKE
        strokeWidth = ctx.resources.displayMetrics.density * 2.2f
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val p = Path()
        if (open) {
            p.moveTo(w * 0.2f, h * 0.35f)
            p.lineTo(w * 0.5f, h * 0.65f)
            p.lineTo(w * 0.8f, h * 0.35f)
        } else {
            p.moveTo(w * 0.35f, h * 0.2f)
            p.lineTo(w * 0.65f, h * 0.5f)
            p.lineTo(w * 0.35f, h * 0.8f)
        }
        c.drawPath(p, paint)
    }
}
