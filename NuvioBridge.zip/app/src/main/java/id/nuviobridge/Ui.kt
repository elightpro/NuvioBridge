package id.nuviobridge

import android.app.AlertDialog
import android.content.Context
import android.view.Gravity
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.drawable.GradientDrawable
import android.util.TypedValue
import android.view.View
import android.view.ViewGroup
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class Pal(val bg: Int, val card: Int, val text: Int, val muted: Int, val primary: Int, val second: Int,
               val nuvio: Int, val mdl: Int)

object Ui {
    const val PREFS = "cfg"
    val COLOR_OK = Color.parseColor("#2E7D32")
    val COLOR_BAD = Color.parseColor("#C62828")
    val COLOR_WARN = Color.parseColor("#EF6C00")

    /** Aplikasi selalu memakai tampilan terang, tidak mengikuti mode gelap sistem. */
    fun pal(ctx: Context): Pal = Pal(
        bg = Color.parseColor("#F5F6F8"), card = Color.parseColor("#FFFFFF"),
        text = Color.parseColor("#1B1F24"), muted = Color.parseColor("#5F6B7A"),
        primary = Color.parseColor("#1565C0"), second = Color.parseColor("#E3E8EF"),
        nuvio = Color.parseColor("#4A2A7A"), mdl = Color.parseColor("#1565C0")
    )

    fun px(ctx: Context, n: Int): Int = (n * ctx.resources.displayMetrics.density).toInt()

    fun rounded(ctx: Context, color: Int, radiusDp: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = px(ctx, radiusDp).toFloat()
    }

    fun card(ctx: Context, pal: Pal): LinearLayout = LinearLayout(ctx).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(px(ctx, 14), px(ctx, 14), px(ctx, 14), px(ctx, 14))
        background = rounded(ctx, pal.card, 12)
    }

    fun addTop(parent: LinearLayout, v: View, topDp: Int = 8) {
        val ctx = parent.context
        parent.addView(v, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            .apply { topMargin = px(ctx, topDp) })
    }

    fun section(ctx: Context, pal: Pal, t: String): TextView = TextView(ctx).apply {
        text = t
        textSize = 12f
        setTextColor(pal.muted)
        typeface = Typeface.DEFAULT_BOLD
        letterSpacing = 0.08f
    }

    fun label(ctx: Context, pal: Pal, t: String): TextView = TextView(ctx).apply {
        text = t
        textSize = 13f
        setTextColor(pal.muted)
    }

    fun button(ctx: Context, pal: Pal, caption: String, primary: Boolean, onClick: () -> Unit): Button = Button(ctx).apply {
        text = caption
        isAllCaps = false
        setTextColor(if (primary) Color.WHITE else pal.text)
        background = rounded(ctx, if (primary) pal.primary else pal.second, 10)
        setOnClickListener { onClick() }
    }

    // ---------- ukuran teks: nilai dasar disimpan sekali, lalu dikalikan faktor ----------
    fun scaleValue(ctx: Context): Float =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("scale", "1.0")?.toFloatOrNull() ?: 1f

    fun applyScale(v: View, factor: Float) {
        if (v is TextView) {
            if (v.tag !is Float) v.tag = v.textSize / v.resources.displayMetrics.scaledDensity
            v.setTextSize(TypedValue.COMPLEX_UNIT_SP, (v.tag as Float) * factor)
        }
        if (v is ViewGroup) for (i in 0 until v.childCount) applyScale(v.getChildAt(i), factor)
    }

    // ---------- tujuan share & template Google ----------
    const val DEFAULT_GTPL = "https://www.google.com/search?q={query}"

    /** nuvio | google | both */
    fun mode(ctx: Context): String =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("mode", "both") ?: "both"

    fun nuvioTpl(ctx: Context): String =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("tpl", DEFAULT_TPL)
            ?.takeIf { it.isNotBlank() } ?: DEFAULT_TPL

    const val DEFAULT_TPL = "nuvio://{type}/{imdb}"

    fun gtpl(ctx: Context): String {
        val t = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("gtpl", DEFAULT_GTPL)
            ?.trim().orEmpty()
        return if (t.isNotEmpty()) t else DEFAULT_GTPL
    }

    // ---------- komponen tampilan (rapi & konsisten) ----------

    /** Dialog yang mengikuti palet mode gelap/terang. */
    fun dialog(ctx: Context): AlertDialog.Builder =
        AlertDialog.Builder(ctx, R.style.MdlDialogLight)

    /** Tombol berbahaya (merah): reset dan hapus. */
    fun dangerButton(ctx: Context, caption: String, onClick: () -> Unit): Button = Button(ctx).apply {
        text = caption
        isAllCaps = false
        setTextColor(Color.WHITE)
        background = rounded(ctx, COLOR_BAD, 10)
        setOnClickListener { onClick() }
    }

    /** Tombol kecil persegi, untuk ▲ ▼ ✎ di daftar aksi. */
    fun miniButton(ctx: Context, pal: Pal, caption: String, onClick: () -> Unit): TextView = TextView(ctx).apply {
        text = caption
        textSize = 15f
        setTextColor(pal.text)
        gravity = Gravity.CENTER
        background = rounded(ctx, pal.second, 8)
        minWidth = px(ctx, 36)
        minHeight = px(ctx, 36)
        setOnClickListener { onClick() }
    }

    /** Baris label di kiri dan status kecil di kanan. */
    fun labelRow(ctx: Context, pal: Pal, label: String, right: TextView): LinearLayout = LinearLayout(ctx).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        addView(TextView(ctx).apply {
            text = label
            textSize = 13f
            setTextColor(pal.muted)
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        addView(right, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
    }

    /** Pilihan berbentuk segmen: satu baris tombol, yang aktif diberi ✓. */
    fun segmentRow(ctx: Context, pal: Pal, labels: List<String>, selected: () -> Int, onPick: (Int) -> Unit): LinearLayout {
        val row = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        val buttons = mutableListOf<Button>()
        fun refresh() {
            val cur = selected()
            buttons.forEachIndexed { i, b ->
                val on = i == cur
                b.text = if (on) labels[i] + " •" else labels[i]
                b.background = rounded(ctx, if (on) pal.primary else pal.second, 10)
                b.setTextColor(if (on) Color.WHITE else pal.text)
            }
        }
        labels.forEachIndexed { i, label ->
            val b = Button(ctx).apply {
                textSize = 13f
                isAllCaps = false
                text = label
                setOnClickListener {
                    onPick(i)
                    refresh()
                }
            }
            buttons.add(b)
            row.addView(b, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                if (i > 0) leftMargin = px(ctx, 4)
            })
        }
        refresh()
        return row
    }

    /** Tombol ikon: ketuk untuk membuka grid pemilih ikon. */
    fun iconButton(ctx: Context, pal: Pal, icon: Int, onClick: () -> Unit): FrameLayout = FrameLayout(ctx).apply {
        background = rounded(ctx, pal.second, 10)
        addView(ActionIconView(ctx, icon, pal.text), FrameLayout.LayoutParams(px(ctx, 24), px(ctx, 24), Gravity.CENTER))
        setOnClickListener { onClick() }
    }

    /** Dialog grid ikon (6 kolom, bisa digulir), ikon terpilih diberi latar biru muda. */
    fun iconPicker(ctx: Context, pal: Pal, selected: Int, onPick: (Int) -> Unit): AlertDialog {
        val grid = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(px(ctx, 12), px(ctx, 8), px(ctx, 12), px(ctx, 8))
        }
        var dlgRef: AlertDialog? = null
        val perRow = 6
        for (r in 0 until (Actions.ICON_COUNT + perRow - 1) / perRow) {
            val rowView = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
            for (k in 0 until perRow) {
                val i = r * perRow + k
                if (i >= Actions.ICON_COUNT) break
                val on = i == selected
                val tile = FrameLayout(ctx).apply {
                    background = rounded(ctx, if (on) Color.parseColor("#D7E5FB") else pal.second, 10)
                    addView(ActionIconView(ctx, i, if (on) pal.primary else pal.text),
                        FrameLayout.LayoutParams(px(ctx, 26), px(ctx, 26), Gravity.CENTER))
                    setOnClickListener {
                        dlgRef?.dismiss()
                        onPick(i)
                    }
                }
                rowView.addView(tile, LinearLayout.LayoutParams(0, px(ctx, 48), 1f).apply {
                    if (k > 0) leftMargin = px(ctx, 4)
                    topMargin = px(ctx, 4)
                })
            }
            grid.addView(rowView)
        }
        val dlg = dialog(ctx)
            .setTitle("Pilih Ikon")
            .setView(ScrollView(ctx).apply { addView(grid) })
            .setNegativeButton("Batal", null)
            .create()
        dlgRef = dlg
        return dlg
    }

    /** Tombol panah atas/bawah untuk mengatur urutan (chevron, bukan segitiga). */
    fun chevronButton(ctx: Context, pal: Pal, up: Boolean, onClick: () -> Unit): FrameLayout = FrameLayout(ctx).apply {
        background = rounded(ctx, pal.second, 8)
        addView(ChevronView(ctx, true, pal.text).apply { rotation = if (up) 180f else 0f },
            FrameLayout.LayoutParams(px(ctx, 14), px(ctx, 14), Gravity.CENTER))
        setOnClickListener { onClick() }
    }

    /** Balon kecil di bawah ikon. Tertutup saat diketuk di luar balon. */
    fun tooltip(anchor: View, text: String, pal: Pal) {
        val ctx = anchor.context
        val tv = TextView(ctx).apply {
            this.text = text
            textSize = 12f
            setTextColor(pal.text)
            setPadding(px(ctx, 10), px(ctx, 6), px(ctx, 10), px(ctx, 6))
            background = rounded(ctx, Color.WHITE, 10)
            elevation = px(ctx, 4).toFloat()
            maxWidth = px(ctx, 200)
        }
        val pw = PopupWindow(tv, ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, true)
        pw.setBackgroundDrawable(android.graphics.drawable.ColorDrawable(Color.TRANSPARENT))
        pw.isOutsideTouchable = true
        pw.showAsDropDown(anchor, 0, px(ctx, 4))
    }

    /** Bagian yang bisa dilipat: judul dengan chevron, isi disembunyikan saat tertutup. */
    fun collapsible(ctx: Context, pal: Pal, title: String, open: Boolean, body: View): LinearLayout {
        val wrap = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        body.visibility = if (open) View.VISIBLE else View.GONE
        val chevron = ChevronView(ctx, open, pal.muted)
        val label = TextView(ctx).apply {
            text = title
            textSize = 12f
            setTextColor(pal.muted)
            typeface = Typeface.DEFAULT_BOLD
            letterSpacing = 0.08f
        }
        val header = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, px(ctx, 20), 0, 0)
            addView(chevron, LinearLayout.LayoutParams(px(ctx, 16), px(ctx, 16)).apply { rightMargin = px(ctx, 6) })
            addView(label)
        }
        header.setOnClickListener {
            val nowOpen = body.visibility != View.VISIBLE
            body.visibility = if (nowOpen) View.VISIBLE else View.GONE
            chevron.open = nowOpen
            chevron.invalidate()
        }
        wrap.addView(header)
        wrap.addView(body, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = px(ctx, 8)
        })
        return wrap
    }
}

/** Chevron: ⌄ saat terbuka, › saat tertutup. Digambar langsung. */
class ChevronView(ctx: Context, var open: Boolean, private val color: Int) : View(ctx) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        this.color = this@ChevronView.color
        style = Paint.Style.STROKE
        strokeWidth = ctx.resources.displayMetrics.density * 2.2f
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val p = Path()
        if (open) {
            p.moveTo(w * 0.2f, h * 0.35f)
            p.lineTo(w * 0.5f, h * 0.65f)
            p.lineTo(w * 0.8f, h * 0.35f)
        } else {
            p.moveTo(w * 0.35f, h * 0.2f)
            p.lineTo(w * 0.65f, h * 0.5f)
            p.lineTo(w * 0.35f, h * 0.8f)
        }
        c.drawPath(p, paint)
    }
}

/** Ikon mata untuk menampilkan/menyembunyikan kunci. Dicoret saat tersembunyi. */
class EyeIconView(ctx: Context, var visible: Boolean, private val color: Int) : View(ctx) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        this.color = this@EyeIconView.color
        style = Paint.Style.STROKE
        strokeWidth = ctx.resources.displayMetrics.density * 1.8f
        strokeCap = Paint.Cap.ROUND
    }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        this.color = this@EyeIconView.color
        style = Paint.Style.FILL
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        c.drawOval(RectF(w * 0.08f, h * 0.3f, w * 0.92f, h * 0.7f), paint)
        c.drawCircle(w * 0.5f, h * 0.5f, h * 0.12f, fill)
        if (!visible) c.drawLine(w * 0.15f, h * 0.85f, w * 0.85f, h * 0.15f, paint)
    }
}

/** Ikon kunci kecil untuk judul bagian PENGATURAN. */
class KeyIconView(ctx: Context, private val color: Int) : View(ctx) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        this.color = this@KeyIconView.color
        style = Paint.Style.STROKE
        strokeWidth = ctx.resources.displayMetrics.density * 2f
        strokeCap = Paint.Cap.ROUND
    }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        this.color = this@KeyIconView.color
        style = Paint.Style.FILL
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        c.drawCircle(w * 0.25f, h * 0.5f, h * 0.2f, paint)
        c.drawLine(w * 0.43f, h * 0.5f, w * 0.92f, h * 0.5f, paint)
        c.drawLine(w * 0.78f, h * 0.5f, w * 0.78f, h * 0.7f, paint)
        c.drawLine(w * 0.9f, h * 0.5f, w * 0.9f, h * 0.65f, paint)
        c.drawCircle(w * 0.25f, h * 0.5f, h * 0.06f, fill)
    }
}

/** Ikon info kecil (lingkaran dengan huruf i). */
class InfoIconView(ctx: Context, private val color: Int) : View(ctx) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        this.color = this@InfoIconView.color
        style = Paint.Style.STROKE
        strokeWidth = ctx.resources.displayMetrics.density * 1.6f
        strokeCap = Paint.Cap.ROUND
    }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        this.color = this@InfoIconView.color
        style = Paint.Style.FILL
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val s = Math.min(w, h)
        c.drawCircle(w / 2f, h / 2f, s * 0.44f, paint)
        c.drawCircle(w / 2f, h * 0.3f, s * 0.07f, fill)
        c.drawLine(w / 2f, h * 0.45f, w / 2f, h * 0.74f, paint)
    }
}

/** Tiga titik berdenyut sebagai penanda proses (pengganti spinner). */
class PulseDotsView(ctx: Context, private val color: Int) : View(ctx) {
    private var phase = 0f
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        this.color = this@PulseDotsView.color
        style = Paint.Style.FILL
    }
    private val animator = android.animation.ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 900
        repeatCount = android.animation.ValueAnimator.INFINITE
        addUpdateListener {
            phase = it.animatedValue as Float
            invalidate()
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        animator.start()
    }

    override fun onDetachedFromWindow() {
        animator.cancel()
        super.onDetachedFromWindow()
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val r = h * 0.16f
        for (i in 0..2) {
            val t = (phase - i * 0.2f + 1f) % 1f
            val k = Math.sin(t * Math.PI).toFloat()
            paint.alpha = (90 + 165 * k).toInt().coerceIn(0, 255)
            c.drawCircle(w * (0.18f + i * 0.32f), h / 2f, r * (0.7f + 0.5f * k), paint)
        }
    }
}

/** Penanda proses: busur tipis yang berputar. */
class ArcSpinnerView(ctx: Context, private val color: Int) : View(ctx) {
    private var angle = 0f
    private val density = ctx.resources.displayMetrics.density
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        this.color = this@ArcSpinnerView.color
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeWidth = density * 2.5f
    }
    private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        this.color = this@ArcSpinnerView.color
        alpha = 40
        style = Paint.Style.STROKE
        strokeWidth = density * 2.5f
    }
    private val animator = android.animation.ValueAnimator.ofFloat(0f, 360f).apply {
        duration = 900
        repeatCount = android.animation.ValueAnimator.INFINITE
        interpolator = android.view.animation.LinearInterpolator()
        addUpdateListener {
            angle = it.animatedValue as Float
            invalidate()
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        animator.start()
    }

    override fun onDetachedFromWindow() {
        animator.cancel()
        super.onDetachedFromWindow()
    }

    override fun onDraw(c: Canvas) {
        val pad = paint.strokeWidth
        val rect = RectF(pad, pad, width - pad, height - pad)
        c.drawOval(rect, track)
        c.drawArc(rect, angle, 110f, false, paint)
    }
}

