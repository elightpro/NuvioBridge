package id.nuviobridge

import android.content.Context
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.util.TypedValue
import android.view.View
import android.view.ViewGroup
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class Pal(val bg: Int, val card: Int, val text: Int, val muted: Int, val primary: Int, val second: Int,
               val nuvio: Int, val mdl: Int)

object Ui {
    const val PREFS = "cfg"
    val COLOR_OK = Color.parseColor("#2E7D32")
    val COLOR_BAD = Color.parseColor("#C62828")
    val COLOR_WARN = Color.parseColor("#EF6C00")

    fun pal(ctx: Context): Pal {
        val night = (ctx.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
            Configuration.UI_MODE_NIGHT_YES
        return if (night) Pal(
            bg = Color.parseColor("#0F1115"), card = Color.parseColor("#1A1D23"),
            text = Color.parseColor("#E8EAED"), muted = Color.parseColor("#9AA3AE"),
            primary = Color.parseColor("#2F6FD6"), second = Color.parseColor("#2A2F38"),
            nuvio = Color.parseColor("#7E57C2"), mdl = Color.parseColor("#2F6FD6")
        ) else Pal(
            bg = Color.parseColor("#F5F6F8"), card = Color.parseColor("#FFFFFF"),
            text = Color.parseColor("#1B1F24"), muted = Color.parseColor("#5F6B7A"),
            primary = Color.parseColor("#1565C0"), second = Color.parseColor("#E3E8EF"),
            nuvio = Color.parseColor("#4A2A7A"), mdl = Color.parseColor("#1565C0")
        )
    }

    fun px(ctx: Context, n: Int): Int = (n * ctx.resources.displayMetrics.density).toInt()

    fun rounded(ctx: Context, color: Int, radiusDp: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = px(ctx, radiusDp).toFloat()
    }

    fun card(ctx: Context, pal: Pal): LinearLayout = LinearLayout(ctx).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(px(ctx, 14), px(ctx, 14), px(ctx, 14), px(ctx, 14))
        background = rounded(ctx, pal.card, 12)
    }

    fun addTop(parent: LinearLayout, v: View, topDp: Int = 8) {
        val ctx = parent.context
        parent.addView(v, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            .apply { topMargin = px(ctx, topDp) })
    }

    fun section(ctx: Context, pal: Pal, t: String): TextView = TextView(ctx).apply {
        text = t
        textSize = 12f
        setTextColor(pal.muted)
        typeface = Typeface.DEFAULT_BOLD
        letterSpacing = 0.08f
    }

    fun label(ctx: Context, pal: Pal, t: String): TextView = TextView(ctx).apply {
        text = t
        textSize = 13f
        setTextColor(pal.muted)
    }

    fun button(ctx: Context, pal: Pal, caption: String, primary: Boolean, onClick: () -> Unit): Button = Button(ctx).apply {
        text = caption
        isAllCaps = false
        setTextColor(if (primary) Color.WHITE else pal.text)
        background = rounded(ctx, if (primary) pal.primary else pal.second, 10)
        setOnClickListener { onClick() }
    }

    // ---------- ukuran teks: nilai dasar disimpan sekali, lalu dikalikan faktor ----------
    fun scaleValue(ctx: Context): Float =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("scale", "1.0")?.toFloatOrNull() ?: 1f

    fun applyScale(v: View, factor: Float) {
        if (v is TextView) {
            if (v.tag !is Float) v.tag = v.textSize / v.resources.displayMetrics.scaledDensity
            v.setTextSize(TypedValue.COMPLEX_UNIT_SP, (v.tag as Float) * factor)
        }
        if (v is ViewGroup) for (i in 0 until v.childCount) applyScale(v.getChildAt(i), factor)
    }

    // ---------- riwayat judul (5 terakhir) ----------
    fun recordHistory(ctx: Context, entry: String) {
        val p = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val old = (p.getString("history", "") ?: "").lines().filter { it.isNotBlank() }
        val stamp = SimpleDateFormat("dd MMM yyyy HH:mm", Locale("id", "ID")).format(Date())
        p.edit().putString("history", (listOf("$stamp|$entry") + old).take(5).joinToString("\n")).apply()
    }

    fun history(ctx: Context): List<String> =
        (ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("history", "") ?: "")
            .lines().filter { it.isNotBlank() }
}
